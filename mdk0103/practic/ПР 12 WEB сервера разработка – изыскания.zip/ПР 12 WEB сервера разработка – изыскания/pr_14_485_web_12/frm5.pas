unit frm5;
{$mode ObjFPC}{$H+}
interface
uses HTTP_SERVER,   // БИБЛИОТЕКА  процедур СЕРВЕРА
    fphttpserver, fphtml,  // БИБЛИОТЕКА  СЕРВЕРА
         RegexPr,
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, ExtCtrls, StdCtrls;
type
  { TForm5 }
  TForm5 = class(TForm)
    Image1: TImage;
    Memo1: TMemo;
    Splitter1: TSplitter;
    procedure FormCreate(Sender: TObject);
    procedure OnServerRequest(Sender: TObject;
                        var ARequest: TFPHTTPConnectionRequest;
                       var AResponse: TFPHTTPConnectionResponse);
    function start(Sender: TObject;
                         var ARequest: TFPHTTPConnectionRequest;
                        var AResponse: TFPHTTPConnectionResponse):boolean;
    function load_file(Sender: TObject;
                          var ARequest: TFPHTTPConnectionRequest;
                         var AResponse: TFPHTTPConnectionResponse):boolean;
   function org_get_inp(i:integer;ARequest: TFPHTTPConnectionRequest ):boolean;
  private
  public
  end;
var
  Form5: TForm5;

implementation
{$R *.lfm}
function make_html():boolean;
var s,FN:String; ad,sd,ld:tstringlist; g,e:integer;
begin result:=false;  // если всё ок
                  fn:=GetCurrentDir()+'\http\body_scen.ini';
if not FileExists(FN) then  exit;  //сценария нет и  всё!!
  ld:=tstringlist.create;  sd:=tstringlist.create; ad:=tstringlist.create;
  ld.LoadFromFile(fn);   // загрузили сценарий
for e:=0 to ld.Count-1do  //перебор сценария
    if pos('.ini',ld.Strings[e])>0 then    //если  есть ссылка наподсценарий
      begin  ad.Clear;  fn:=GetCurrentDir()+'\http\'+ld.Strings[e];
      if not FileExists(FN) then continue;
                  ad.LoadFromFile(fn);s:='';
      for g:=0 to ad.Count-1do
         if length(s)<50  then s:=s+ad.Strings[g] else
                    begin s:=s+ad.Strings[g]; sd.Add(s); s:=''; end;
      if length(s)>0 then  sd.Add(s);  s:='';
      end  else   sd.Add(ld.Strings[e]);
  fn:=GetCurrentDir()+'\http\body.ini'; sd.SaveToFile(fn);
  ld.free; sd.Free;   ad.Free;
  result:=true;  // если не всё ок
end;

function tform5.org_get_inp(i:integer;ARequest:TFPHTTPConnectionRequest ):boolean;
var fn,n,v:string;  sd,ld:tstringlist;  k, e:integer;
begin v:=ARequest.QueryFields.ValueFromIndex[i];  // получили значение
      n:=ARequest.QueryFields.Names[i];          // имя значения
     fn:=GetCurrentDir()+'\http\get\'+n+'.org'; result:=false; // пока всё не ок
if not FileExists(FN) then exit;  // если сценария нет
         ld:=tstringlist.create;  ld.LoadFromFile(fn);  // загрузили сценарий
k:=-1;if Ld.count=0  then begin   ld.free; exit;end; // если файл пустой
if (pos('Radio',ld.Strings[0])>0)then k:=1 else  // контроль тип ввода
if (pos('RADIO',ld.Strings[0])>0)then k:=1 else  // контроль тип ввода
if (pos('radi',ld.Strings[0])>0)then k:=1 else // контроль тип ввода
if (pos('TEXT', ld.Strings[0])>0)then k:=0 else // контроль тип ввода
if (pos('text', ld.Strings[0])>0)then k:=0 else // контроль тип ввода
if (pos('Text', ld.Strings[0])>0)then k:=0 ;  if k<0 then exit; // не нашли
sd:=tstringlist.create;  //создали результат сченарий
    for e:=0 to Ld.count-1 do  //цикл формирования подсченария
       case k of
       0: begin if pos('value=',ld.Strings[e])>0 then sd.Add('value="'+v+'"')
                                                 else sd.Add(ld.Strings[e]);end;
       1:  begin if pos('value="'+v+'"',ld.Strings[e])>0 then
                 sd.Add('value="'+v+'" checked')
                 else sd.Add(ld.Strings[e]);  end;
       end;   fn:=GetCurrentDir()+'\http\get\'+n+'.ini';
sd.SaveToFile(fn);  sd.free; ld.free;// подсценарий сформировали
       result:=true; // всё ок
end;
function tform5.load_file(Sender: TObject;
                       var ARequest: TFPHTTPConnectionRequest;
                      var AResponse: TFPHTTPConnectionResponse):boolean;
var st0:tstringlist; fn:string;  i:integer;
begin  result:=false;  // пока всё не ок
AResponse.Contents.Clear; st0:=tstringlist.Create; // чистка создали
fn:=GetCurrentDir()+'\http\Html_head.txt';  st0.LoadFromFile(fn);   //загрузили
for i:=0 to st0.count-1 do AResponse.Contents.Add(st0.Strings[i]); // передали
fn:=GetCurrentDir()+'\http\meta_meta.txt';  st0.LoadFromFile(fn); //загрузили
for i:=0 to st0.count-1 do AResponse.Contents.Add(st0.Strings[i]); // передали
fn:=GetCurrentDir()+'\http\stile_stile.txt';st0.LoadFromFile(fn);   //загрузили
for i:=0 to st0.count-1 do AResponse.Contents.Add(st0.Strings[i]); // передали
fn:=GetCurrentDir()+'\http\head_body.txt';  st0.LoadFromFile(fn);   //загрузили
for i:=0 to st0.count-1 do AResponse.Contents.Add(st0.Strings[i]);  // передали
fn:=GetCurrentDir()+'\http\body.ini';  st0.LoadFromFile(fn);   //загрузили
for i:=0 to st0.count-1 do AResponse.Contents.Add(st0.Strings[i]);  // передали
fn:=GetCurrentDir()+'\http\script_script.txt';  st0.LoadFromFile(fn); //загрузили
for i:=0 to st0.count-1 do AResponse.Contents.Add(st0.Strings[i]);  // передали
fn:=GetCurrentDir()+'\http\body_html.txt';  st0.LoadFromFile(fn);   //загрузили
for i:=0 to st0.count-1 do AResponse.Contents.Add(st0.Strings[i]); // передали
for i:=0 to  AResponse.Contents.Count-1 do
    memo1.Lines.Add(AResponse.Contents.Strings[i]);
AResponse.SendContent;       result:=true;  // всё  ок
st0.Free;  //освободили
end;

function tform5.start(Sender: TObject;
                    var ARequest: TFPHTTPConnectionRequest;
                   var AResponse: TFPHTTPConnectionResponse):boolean;
var  qq1,qq2,  i:integer;
begin     result:=false;  // пока всё не ок
                 qq1:=ARequest.QueryFields.Count -1;
                 qq2:=ARequest.ContentFields.Count -1 ;
   memo1.lines.Add('---URL->'+ARequest.URL);
   memo1.lines.Add('metod->'+ARequest.Method);
   memo1.lines.Add('commad->'+ARequest.Command);
   memo1.lines.Add('host->'+ARequest.Host);
   memo1.lines.Add('server->'+ARequest.Server);
   memo1.lines.Add('query->'+ARequest.Query);
   memo1.lines.Add('query.text->'+ARequest.QueryFields.Text);
   memo1.lines.Add('files.count->'+inttostr(ARequest.Files.Count));
   memo1.lines.Add('age->'+AResponse.Age);
   memo1.lines.Add('cod->'+AResponse.CodeText);
   memo1.lines.Add('dat->'+AResponse.Date);
for i := 0 to qq1 do  begin  //цикл просмотра get сообщений
    memo1.lines.Add(' <get> '+ inttostr(i) + ' '+ ARequest.QueryFields[i]);
    if not (ARequest.QueryFields.ValueFromIndex[i]=EmptyStr) then
   if  org_get_inp(i,ARequest) then continue;
    memo1.lines.Add(' <get> '+ inttostr(i)+ ' '+
    ARequest.QueryFields.ValueFromIndex[i]+ ' '+
    ARequest.QueryFields.Names[i]   );
    end;
for i := 0 to qq2 do  //цикл просмотра post сообщений
    memo1.lines.Add(' <post> '+ inttostr(i) + ' '+ ARequest.ContentFields[i]);
  if  (qq2>0) or (qq1>0) then exit;
            result:=true;  // если всё ок
end;
procedure TForm5.OnServerRequest( Sender: TObject;
      var ARequest: TFPHTTPConnectionRequest;
     var AResponse: TFPHTTPConnectionResponse  ) ;
var ur: String;  LName,   Nom ,     FN : String;
begin
         start(Sender,ARequest, AResponse); //создаём сценарии
         make_html();   //создаём страницу из сценариев
  if load_file(Sender,ARequest, AResponse) then //страницу кидаем
    exit  //блокируем всё что ниже - выход из процедуры
 else  begin  AResponse.Code:=404;  AResponse.SendContent;  exit; end;

                   fn:=GetCurrentDir()+'\http\index.html';
 if not FileExists(FN) then
     begin  AResponse.Code:=404;  AResponse.SendContent;  exit; end;
    try  AResponse.Contents.LoadFromFile(fn);
         AResponse.SendContent;
     finally
     end;
end;
procedure TForm5.FormCreate(Sender: TObject);
VAR S:STRING;
begin  // RegisterRoutes;
          s:=ExtractFilePath(ParamStr(0))+'\HTTP\S.png';
          Image1.Picture.LoadFromFile(S);
   TThreadServer.Create(8080, @OnServerRequest);
end;
end.

