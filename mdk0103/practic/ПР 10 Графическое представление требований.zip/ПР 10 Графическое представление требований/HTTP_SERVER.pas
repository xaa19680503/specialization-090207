unit HTTP_SERVER;
{$mode objfpc}{$H+}
interface
uses
  Classes, SysUtils, fphttpserver, fphttpclient, RegexPr;
type
  //======================================
  // Server
  TThreadServer = class(TThread)
  protected
    procedure Execute; override;
  public
    FPHttpServer1: TFPHttpServer;
    constructor Create(Port: Integer; OnQuery: THTTPServerRequestHandler);
    destructor Destroy; override;
  end;

  //======================================
  // Client
  TThreadClient = class(TThread)
    type
      TClientResponseFunction = procedure (ThreadClient: TThreadClient) of object;Register;
      TClientErrorFunction = procedure (ThreadClient: TThreadClient; E: Exception) of object;Register;
    var
      url:String;
      isResponse:Boolean;
      isError:Boolean;
      Response: String;
      Error: Exception;
      PClientResponseFunction: TClientResponseFunction;
      PClientErrorFunction: TClientErrorFunction;
      PThreadMethod: TThreadMethod;
  protected
    procedure Execute; override;
    procedure OnClientResponse;
    procedure OnClientError;
  public
    constructor Create(link: String; PClient: TClientResponseFunction; PError: TClientErrorFunction);
    function get(http_url:String):String;
  end;




implementation
// =========== Server ===========

constructor TThreadServer.Create(Port: Integer; OnQuery: THTTPServerRequestHandler);
begin
  Self.FreeOnTerminate := true;
  FPHttpServer1 := TFPHttpServer.Create(nil);
  FPHttpServer1.Port := Port;
  FPHttpServer1.OnRequest := OnQuery;
  FPHttpServer1.LookupHostNames:=False;
  inherited Create(False);
end;

destructor TThreadServer.Destroy;
begin
  FPHttpServer1.Free;
end;

procedure TThreadServer.Execute;
begin
  try
    FPHttpServer1.Active := True;
  except
    on E: Exception do
    begin
      Exit;
    end;
  end;
end;




// =========== Client ===========

constructor TThreadClient.Create(link: String; PClient: TClientResponseFunction; PError: TClientErrorFunction);
begin
  PClientResponseFunction := PClient;
  PClientErrorFunction := PError;
  isResponse := False;
  isError := False;
  url := link;
  FreeOnTerminate := True;
  inherited Create(False);
end;


procedure TThreadClient.Execute;
begin //while not Application.Terminated do begin
  Response := get(url);
  Synchronize(@OnClientResponse);
  DoTerminate;
end;



procedure TThreadClient.OnClientResponse;
begin
  if Assigned(PClientResponseFunction) then
     PClientResponseFunction(Self);
end;


procedure TThreadClient.OnClientError;
begin
  if Assigned(PClientErrorFunction) then
     PClientErrorFunction(Self, Error);
end;


function TThreadClient.get(http_url:String):String;
var
  Client: TFPHTTPClient;
begin
  result := '';
  try
    Client := TFPHTTPClient.Create(nil);
    try
      result := Client.Get(http_url);
      //.Trim;
      isResponse := result <> '';
    except
      on E: Exception do
      begin
        isError := True;
        Error := E;
        Synchronize(@OnClientError);
        //result := E.Message;
      end;
    end;
  finally
    Client.Free;
  end;
end;
end.

TThreadServer.Create(8080, @OnServerRequest);


procedure OnClientResponse(ThreadClient: TThreadClient);
 procedure OnClientError(ThreadClient: TThreadClient; E: Exception);
 procedure OnServerRequest(Sender: TObject;var ARequest: TFPHTTPConnectionRequest;var AResponse: TFPHTTPConnectionResponse);
private
FCount:integer;
public

 /////////////////////////////////////////////////////////////////////////////////
procedure TForm1.OnServerRequest(Sender: TObject;var ARequest: TFPHTTPConnectionRequest;var AResponse: TFPHTTPConnectionResponse);
var ur: String;        F : TFileStream;    FN : String;    mm:tmemo; i:integer; nom, LName: String;
begin
  ///url := 'http://'+ARequest.Host+'/'+ARequest.GetNextPathInfo+'?myvariable='+ARequest.QueryFields.Values['myvariable'];
  fn:=GetCurrentDir()+'\http\index.html';
//  AResponse.Content := fn+' '+inttostr(memo1.Lines.Count)+' OnServerRequest from='+ARequest.RemoteAddr+' -> to='+url;
 // AResponse.Contents.Add('<form>> send </form>');
  //AResponse.SendContent;
  ur:=ARequest.URI;
  if memo1.Lines.Count>20 then memo1.clear;     memo1.lines.Add(ur);
  if memo2.Lines.Count>40 then memo1.clear;
  if not FileExists(FN) then
       begin
       AResponse.Code:=404;  AResponse.SendContent;  exit;
       end;
    try
    AResponse.Contents.Clear;
            Nom := ARequest.QueryFields.Values['foo'];
    if not (nom = EmptyStr) then   BEGIN
                    AResponse.Content := 'Hello, ' + Nom + '!';
                    AResponse.SendContent;
                    END
    ELSE
    BEGIN
       LName := ARequest.QueryFields.Values['Name'];
    if LName = EmptyStr then begin
                    AResponse.Contents.LoadFromFile(fn);
    for i:=1 to     AResponse.Contents.Count-1 do
    memo2.lines.Add(AResponse.Contents.Strings[i]);
                    AResponse.SendContent;end
               else AResponse.Content := 'Hello, ' + LName + '!';
     END;
     finally
     end;
end;
