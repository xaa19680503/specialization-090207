unit dbf_proc;
{$mode ObjFPC}{$H+}
interface
uses
  StdCtrls,  //0  здесь  tcombobox описан
  Classes, SysUtils, dbf, DB, DBCtrls, DBExtCtrls;
procedure create_dbf(nm:string);
function CMB(VAR CMBX:TCOMBOBOX; NM:STRING):tstringlist;
PROCEDURE arh_dbf(var db_arh:tdbf;nm:string);
function key_load(
                  nm:string;    //где хранятся ключи
                  d_dat:tdbf    //где хранятся данные
                  ):boolean;
function DTOS(D:string):string; // => дата в формате dBase
implementation
function DTOS(D:string):string; // => дата в формате dBase
begin
 Result:= Copy(D, 7,4) + Copy(D, 4, 2) + Copy(D, 1, 2);
end;


function key_load(
                  nm:string;    //где хранятся ключи
                  d_dat:tdbf     //где хранятся данные
                  ):boolean;
var d,s:string; i:integer; d_key:tdbf;
BEGIN    d:='';      d_dat.first;
                     d_key:=tdbf.Create(nil);
                     d_key.TableName:=nm;
                     d_key.Active:=true;;
                     d_key.open; result:=false;
WHILE NOT d_dat.EOF DO BEGIN  D_key.First; // цикл по базе
      s:=d_dat.FieldByName('id').AsString; //с записи  передали значение
   if (d=s                    ) or   //если нашли, то не судьба!
      (d_key.Locate('id',s,[])) then  begin d:=s;  d_dat.Next; continue; end;
   d_key.Append;  //добавить запись!
   for i:=0 to   d_key.Fields.Count-1 do    //цикл по полям перемящает данные.
   d_key.Fields.Fields[i]:=d_dat.Fields.Fields[i];
   d_key.post; result:=true; d_dat.FieldByName('key').AsString:='1';
   d_dat.Next;   // следующая запись
 end;
  d_key.close;  d_key.free;
END;

procedure arh_dbf(var db_arh:tdbf;nm:string);
 Var Info : TSearchRec; s:string;
 begin  s:=ExtractFilePath(ParamStr(0))+nm;
    Db_arh:=tdbf.Create(nil);
    Db_arh.Active:=false;
    Db_arH.FilePath:='';
    Db_arh.FilePathFull:='';
   if findfirst(s,   faAnyFile,  Info )=0 then
   begin Db_arh.TableName:=s;
         Db_arh.Active:=true;;
         Db_arh.open;
   end;
   s:=ExtractFilePath(ParamStr(0))+'arh.mdx';
   if findfirst(s,   faAnyFile,  Info )=0 then
      EXIT;
 DB_ARH.AddIndex('ID','ID',[]);
 DB_ARH.AddIndex('SDAT','SDAT',[]);
 end;

function CMB(VAR CMBX:TCOMBOBOX; //cомбобох //3
                   NM:STRING  // имя файла
                   ):tstringlist;  //3
var  NewDBF: TDBF; Info : TSearchRec; s:string;  //3
                     rz:tstringlist;
BEGIN  s:=ExtractFilePath(ParamStr(0))+NM;
 if findfirst(s, faAnyFile, Info )=0 then
   ELSE exit; //3 если неть фацла  то вышли с процедуры
   CMBX.Items.Clear; CMBX.Items.Add('-ALL-');
   rz:=tstringlist.Create;  rz.Add('-ALL-');
   NewDBF := TDBF.Create(nil);         //создали обьект
try   //контроль на ошибку
   NewDBF.TableName := nm;            //указали имя
   NewDBF.Open;                      //3   открыли базу
WHILE NOT NewDBF.EOF DO BEGIN    //3  цикл по базе
 s:=NEWDBF.FieldByName('NAME').AsString; //с записи  передали значение
 if length(s)>0 then begin
    CMBX.Items.Add(s); //3
    s:=NEWDBF.FieldByName('ID').AsString; //с записи  передали значение
    rz.Add(s); end;
 NEWDBF.Next;                 //3 следующая запись
 end; CMBX.Text:='-ALL-';     //3
finally           // при завершении
   NewDBF.Close; //закрыли базу
   NewDBF.Free; //освободить обьект
end;  cmb:=rz;
END;    //3

procedure create_dbf(nm:string);
var  NewDBF: TDBF; Info : TSearchRec; s:string;
begin  s:=ExtractFilePath(ParamStr(0))+NM; //'my.dbf';
  if findfirst(s, faAnyFile, Info )=0 then exit;
//  showmessage('file find ok');
  NewDBF := TDBF.Create(nil);  //создаи обьект
  try //контроль на ошибку
      NewDBF.TableName := nm; //'my.dbf';  //указали имя
      NewDBF.FieldDefs.Add('id'    ,ftString, 20); //указали поле
      NewDBF.FieldDefs.Add('name'  ,ftString, 25); //указали поле
      NewDBF.FieldDefs.Add('iN_out',ftString,5);   // указали другое поле
      NewDBF.FieldDefs.Add('type',ftstring,20);     // указали другое поле
      NewDBF.FieldDefs.Add('host',ftstring,15);    // указали другое поле
      NewDBF.FieldDefs.Add('ip1',ftstring,3);    // указали другое поле
      NewDBF.FieldDefs.Add('ip2',ftstring,3);    // указали другое поле
      NewDBF.FieldDefs.Add('ip3',ftstring,3);    // указали другое поле
      NewDBF.FieldDefs.Add('ip4',ftstring,3);    // указали другое поле
      NewDBF.FieldDefs.Add('port',ftword);       // указали другое поле
      NewDBF.FieldDefs.Add('adress',ftword);     // указали другое полеv
      NewDBF.FieldDefs.Add('adr',ftstring,3);    // указали другое поле
      NewDBF.FieldDefs.Add('prim',ftstring,100);  // указали другое поле
      NewDBF.FieldDefs.Add('coment',ftstring,100); // указали другое поле
      NewDBF.FieldDefs.Add('dat_in',ftstring,20);  // указали другое поле
      NewDBF.FieldDefs.Add('dat_ou',ftstring,20);  // указали другое поле
      NewDBF.FieldDefs.Add('key',ftstring,10);    // указали для пароля
      NewDBF.FieldDefs.Add('key_id',ftstring,10);  //для архива id
      NewDBF.FieldDefs.Add('sdat',ftstring,10);  //для архива id
      NewDBF.FieldDefs.Add('ddat',ftdate);   //для архива id
      NewDBF.CreateTable; //сохранить базу
  finally           // при завершении
      NewDBF.Free; //освободить обьект
  end;
end;

function DTOS(D:string):string; // => дата в формате dBase
begin
 Result:= Copy(D, 7,4) + Copy(D, 4, 2) + Copy(D, 1, 2);
end;

end.

