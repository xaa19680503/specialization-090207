unit frm3;
{$mode ObjFPC}{$H+}
interface
uses
  dbf_proc, Classes, SysUtils, DB, dbf, Forms, Controls, Graphics, Dialogs,
  DBGrids, StdCtrls, DBCtrls;
type
  { TForm3 }
  TForm3 = class(TForm)
    ComboBox1: TComboBox;
    DataSource1: TDataSource;
    DBEdit1: TDBEdit;
    DBEdit2: TDBEdit;
    Dbf1: TDbf;
    DBGrid1: TDBGrid;
    DBNavigator1: TDBNavigator;
    Label1: TLabel;
    Label2: TLabel;
    Label3: TLabel;
    Label4: TLabel;
    procedure ComboBox1Change(Sender: TObject);
    procedure ComboBox2Change(Sender: TObject);
    procedure Dbf1AfterEdit(DataSet: TDataSet);
    procedure Dbf1AfterScroll(DataSet: TDataSet);
    procedure Dbf1BeforeEdit(DataSet: TDataSet);
    procedure Dbf1BeforeScroll(DataSet: TDataSet);
    procedure FormCreate(Sender: TObject);
    procedure FormDestroy(Sender: TObject);
  private
  id_key:tstringlist;
  public
  end;
var
  Form3: TForm3;
     DB11: TDBF;
implementation
{$R *.lfm}
{ TForm3 }
procedure TForm3.FormCreate(Sender: TObject);
var  Info : TSearchRec; s:string;
begin
  id_key:=tstringlist.Create;
  id_key:=CMB(combobox1,'OPPONENT.DBF');
  s:=ExtractFilePath(ParamStr(0))+'OPPONENT.DBF' ;
  if findfirst(s, faAnyFile, Info )=0 then
     ELSE close;//3 если нет файла  то вышли с процедуры
     DB11:= TDBF.Create(nil);         //создали обьект11
     DB11.TableName := 'OPPONENT.DBF'; //указали имя
     DB11.Open;                      //3   открыли базу

     s:=ExtractFilePath(ParamStr(0))+'dat.DBF' ;
     if findfirst(s, faAnyFile, Info )=0 then
        ELSE close;//3 если нет файла  то вышли с процедуры
     DBf1.TableName:='dat.dbf';
     DBf1.FilePathFull:='';
     DBf1.FilePath:=''   ;
     dbf1.Active:=true;
     dbf1.Open;
end;

procedure TForm3.ComboBox1Change(Sender: TObject);
var s:string;
begin  dbf1.Filtered:=false;
                       if combobox1.ItemIndex<0 then exit;
dbf1.Filtered:=false;  if combobox1.ItemIndex<1 then exit;

    Label1.caption:=id_key.Strings[combobox1.ItemIndex];
                       db11.RecNo:=combobox1.ItemIndex;
       Label2.caption:=db11.FieldByName('name').AsString;
    s:=Label1.caption;
       dbf1.Filter:='(ID="'+s+'")'+'OR(ID="")';
       dbf1.Filtered:=true;
end;

procedure TForm3.ComboBox2Change(Sender: TObject);
begin

end;

procedure TForm3.Dbf1AfterEdit(DataSet: TDataSet);
var s:string; d,i:integer;
begin s:=dbf1.FieldByName('ID').AsString;
     d:=dbf1.RecNo;
  if s=''  then else exit; i:=combobox1.ItemIndex;
  if i<1   then  exit;;
      dbf1.FieldByName('HOSt').AsString:=db11.FieldByName('HOSt').AsString;
      dbf1.FieldByName('Port').AsString:=db11.FieldByName('PORT').AsString;
      dbf1.FieldByName('name').AsString:=db11.FieldByName('name').AsString;
      dbf1.FieldByName('ID'  ).AsString:=db11.FieldByName('ID'  ).AsString;
      dbf1.FieldByName('IP1').AsString:=db11.FieldByName('IP1').AsString;
      dbf1.FieldByName('IP2').AsString:=db11.FieldByName('IP2').AsString;
      dbf1.FieldByName('IP3').AsString:=db11.FieldByName('IP3').AsString;
      dbf1.FieldByName('IP4').AsString:=db11.FieldByName('IP4').AsString;
      dbf1.FieldByName('adr').AsString:=db11.FieldByName('adr').AsString;
      dbf1.FieldByName('prim').AsString:=db11.FieldByName('prim').AsString;
      dbf1.FieldByName('key').AsString:=db11.FieldByName('key').AsString;
end;

procedure TForm3.Dbf1AfterScroll(DataSet: TDataSet);
begin
  label3.caption:=inttostr(dbf1.RecNo);
end;

procedure TForm3.Dbf1BeforeEdit(DataSet: TDataSet);
begin
//  dbf1.Post;
end;

procedure TForm3.Dbf1BeforeScroll(DataSet: TDataSet);
begin
  label4.caption:=inttostr(dbf1.RecNo);
end;


procedure TForm3.FormDestroy(Sender: TObject);
begin
  id_key.Free;
  DB11.Close; //закрыли базу
  DB11.Free; //освободить обьект
end;

end.

