unit Unit2;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils;

  function CRC16(buf:pointer;size:word):word;
  function crc16string(msg:string):string;
  function crc16_ansi(const a: AnsiString): Word;
  function ansi_CRC16(Data: AnsiString): AnsiString;
  function CRC16_uint16(Data: AnsiString): UInt16;

implementation

const P_16=$A001;

var crc_tab16:array[0..255] of word;

procedure init_crc16_tab;
var i,j,crc,c:word;
begin
for i:=0 to 255 do
begin
crc:=0;
c:=i;
for j:=0 to 7 do begin
if (crc xor c) and 1=1
then crc:=(crc shr 1) xor P_16
else crc:=crc shr 1;
c:=c shr 1;
end;
crc_tab16[i]:=crc;
end;
end;

function update_crc_16(crc,c:word):word;
var tmp, short_c:word;
begin
tmp:=crc xor c;
crc:=(crc shr 8) xor crc_tab16[tmp and $ff];
Result:=crc;
end;

function CRC16(buf:pointer;size:word):word;
var i,crc_16_modbus:word;
begin
init_crc16_tab;
crc_16_modbus:=$ffff;
for i:=0 to size-1 do
crc_16_modbus:=update_crc_16(crc_16_modbus,pbytearray(buf)^[i]);
Result:=crc_16_modbus;
end;


function crc16string(msg:string):string;
var crc: word;
n,i: integer;
b:byte;
begin
crc := $FFFF;
for i:=1 to length (msg) do begin
b:=ord(msg[i]);
crc := crc xor b;
for n:=1 to 8 do begin
if (crc and 1)<>0
then crc:=(crc shr 1) xor $A001
else crc:=crc shr 1;
end;
end;
result:=chr(crc and $ff)+chr(crc shr 8);
end;

function crc16_ansi(const a: AnsiString): Word;
var
CRC: Word;
i, j: integer;
b:array of byte absolute a;
begin
crc := $FFFF;
  for i := 1 to length(a)  do
  begin
crc := crc xor b[i] shl 8;
    for j := 1 to 8 do
      if ((crc and $8000) <> 0) then
crc := ((crc shl 1) xor $1021)
      else
crc := (crc shl 1)
  end;
result := (crc and $FFFF);
end;

  function ansi_CRC16(Data: AnsiString): AnsiString;
var
i,j,iSum,f : Integer;
begin
iSum := $FFFF;
 for i := 1 to Length(Data) do
 begin
iSum := iSum xor Ord(Data[i]);
  for j := 1 to 8 do
  begin
f := iSum and $0001;
iSum := iSum shr 1;
   if f = 1 then iSum := iSum xor $A001;
  end;
 end;
Result := AnsiChar(Lo(iSum)) + AnsiChar(Hi(iSum));
end;

  function CRC16_uint16(Data: AnsiString): UInt16;
  var
  i,j,iSum,f : Integer;
  begin
  iSum := $FFFF;
   for i := 1 to Length(Data) do
   begin
  iSum := iSum xor Ord(Data[i]);
    for j := 1 to 8 do
    begin
  f := iSum and $0001;
  iSum := iSum shr 1;
     if f = 1 then iSum := iSum xor $A001;
    end;
   end;
  Result := UInt16(iSum);
  end;
end.

