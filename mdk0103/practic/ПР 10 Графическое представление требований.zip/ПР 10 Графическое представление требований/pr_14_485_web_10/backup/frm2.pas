unit frm2;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, DB, dbf, Forms, Controls, Graphics, Dialogs, DBGrids,
  ExtCtrls, DBCtrls, StdCtrls;

type

  { TForm2 }

  TForm2 = class(TForm)
    DataSource1: TDataSource;
    DBEdit1: TDBEdit;
    DBEdit2: TDBEdit;
    DBEdit3: TDBEdit;
    DBEdit4: TDBEdit;
    DBEdit5: TDBEdit;
    DBEdit6: TDBEdit;
    DBEdit7: TDBEdit;
    DBEdit8: TDBEdit;
    DBEdit9: TDBEdit;
    Dbf1: TDbf;
    DBGrid1: TDBGrid;
    DBNavigator1: TDBNavigator;
    Label1: TLabel;
    Label2: TLabel;
    Label3: TLabel;
    Label4: TLabel;
    Label5: TLabel;
    Panel1: TPanel;
    Panel2: TPanel;
    Panel3: TPanel;
    procedure DBEdit6Change(Sender: TObject);
    procedure Dbf1AfterEdit(DataSet: TDataSet);
    procedure Dbf1AfterScroll(DataSet: TDataSet);
  private

  public

  end;

var
  Form2: TForm2;

implementation

{$R *.lfm}

{ TForm2 }

procedure TForm2.DBEdit6Change(Sender: TObject);
begin

end;

procedure TForm2.Dbf1AfterEdit(DataSet: TDataSet);
var d,s:string; k,i:integer;
begin //индивидуальный ключ из даты + времени + номер записи
if length(dbf1.FieldByName('ID').AsString)>0
   then exit; //если ранее ввели , то менять нельзя!
   d:=datetostr(date); i:=pos('.',d);
   while i>0 do begin  //убираем точие  в цикле
       delete(d,i,1);i:=pos('.',d); end; s:=d;;
   d:=timetostr(time); i:=pos(':',d);
   while i>0 do begin  //убираем двоеточие  в цикле
       delete(d,i,1);i:=pos(':',d); end;
s:=s+d+inttostr(dbf1.RecNo); //получили занесли
     dbf1.FieldByName('ID').AsString:=s;
end;

procedure TForm2.Dbf1AfterScroll(DataSet: TDataSet);
var s:string;
begin  s:=dbf1.FieldByName('type').AsString;
label1.caption:=inttostr(dbf1.RecNo);
if s='' then   begin
     panel1.Visible:=false;
     panel2.Visible:=false;   end;
if s='TCP' then   begin
     panel1.Visible:=true;
     panel2.Visible:=false;   end;
if s='RTU' then   begin
     panel1.Visible:=false;
     panel2.Visible:=true;   end;
end;
end.

