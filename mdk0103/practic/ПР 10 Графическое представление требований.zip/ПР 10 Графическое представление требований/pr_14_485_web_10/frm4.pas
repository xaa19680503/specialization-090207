unit frm4;

{$mode ObjFPC}{$H+}

interface

uses
  DBF_PROC,
  Classes, SysUtils, DB, dbf, SQLDB, Forms, Controls, Graphics, Dialogs,
  DBGrids, ExtCtrls, StdCtrls, DBCtrls, ExtDlgs, EditBtn, TADbSource;

type

  { TForm4 }

  TForm4 = class(TForm)
    CheckBox1: TCheckBox;
    CheckBox2: TCheckBox;
    CheckBox3: TCheckBox;
    DataSource1: TDataSource;
    DataSource2: TDataSource;
    DateEdit1: TDateEdit;
    DateEdit2: TDateEdit;
    Dbf1: TDbf;
    Dbf2: TDbf;
    DBGrid1: TDBGrid;
    DBGrid2: TDBGrid;
    Panel1: TPanel;
    Splitter1: TSplitter;
    Splitter2: TSplitter;
    procedure Button1Click(Sender: TObject);
    procedure CheckBox1Change(Sender: TObject);
    procedure CheckBox2Change(Sender: TObject);
    procedure CheckBox3Change(Sender: TObject);
    procedure DateEdit1Change(Sender: TObject);
    procedure DateEdit1Click(Sender: TObject);
    procedure DateEdit2Change(Sender: TObject);
    procedure Dbf2AfterScroll(DataSet: TDataSet);
    procedure FormClose(Sender: TObject; var CloseAction: TCloseAction);
    procedure FormCreate(Sender: TObject);
    procedure Panel1Click(Sender: TObject);
  private

  public

  end;

var
  Form4: TForm4;

implementation

{$R *.lfm}

{ TForm4 }

procedure TForm4.FormCreate(Sender: TObject);
begin

end;

procedure TForm4.Panel1Click(Sender: TObject);
begin

end;

procedure TForm4.Button1Click(Sender: TObject);
begin

end;

procedure TForm4.CheckBox1Change(Sender: TObject);
begin
CheckBox2Change(Sender);
end;

procedure TForm4.CheckBox2Change(Sender: TObject);
var Q,W, Z,s:string;  D:TDATE; I:WORD;
begin   I:=0; W:=''; Q:='';
  dbf1.Filtered:=false;
  D:=DateEdit1.Date;  S:=DTOS(DATETOSTR(D));
  D:=DateEdit2.Date;  Z:=DTOS(DATETOSTR(D));
if  CheckBox2.Checked then W:='(SDaT>="'+S+'")';
if  CheckBox3.Checked then W:='(SDaT<="'+Z+'")';
if (CheckBox3.Checked) AND
   (CheckBox3.Checked) then W:='(SDaT>="'+S+'")AND(SDaT<="'+Z+'")';
if CheckBox1.Checked then
   Q:='(ID="'+dbf2.FieldByName('id').AsString+
      '")OR(ID="")';
IF (LENGTH(Q)>0) AND
   (LENGTH(W)>0) THEN W:=W+'AND'+Q ELSE  W:=W+Q;
    dbf1.Filter:=W;
    dbf1.Filtered:=true;
end;

procedure TForm4.CheckBox3Change(Sender: TObject);
begin
  CheckBox2Change(Sender);
end;

procedure TForm4.DateEdit1Change(Sender: TObject);
begin
CheckBox2Change(Sender);
end;

procedure TForm4.DateEdit1Click(Sender: TObject);
begin

end;

procedure TForm4.DateEdit2Change(Sender: TObject);
begin
  CheckBox2Change(Sender);
end;

procedure TForm4.Dbf2AfterScroll(DataSet: TDataSet);
var s:string;
begin
  CheckBox2Change(self);
end;

procedure TForm4.FormClose(Sender: TObject; var CloseAction: TCloseAction);
begin
  form4.Dbf1.Active:=FALSE;
  form4.Dbf2.Active:=FALSE;
end;

end.

