unit Unit1;
{$mode objfpc}{$H+}
interface
uses
  DBF_PROC,frm2,  frm3 , frm4 ,
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, ExtCtrls, ComCtrls,
  StdCtrls, Grids, Menus, Buttons, Spin, DBGrids, LazSerial, Registry, dbf, DB,
  StrUtils, LazUTF8, LConvEncoding, crc_16, LCLType, DBCtrls, DBExtCtrls, Types;
type
  { TForm1 }
  TForm1 = class(TForm)
    BitBtn1: TBitBtn; Button1: TButton;    Button2: TButton;
    Button3: TButton; Button4: TButton;    Button5: TButton;
    Button6: TButton; Button7: TButton;    Button8: TButton;   Button9: TButton;
    CheckBox1: TCheckBox;    CheckBox2: TCheckBox;
    CheckBox3: TCheckBox;    CheckBox4: TCheckBox;    CheckBox5: TCheckBox;
    ComboBox1: TComboBox;    ComboBox2: TComboBox;
    ComboBox3: TComboBox;    ComboBox4: TComboBox;
    ComboBox5: TComboBox;
    DataSource1: TDataSource;
    DBEdit1: TDBEdit;
    DBEdit10: TDBEdit;
    DBEdit11: TDBEdit;
    DBEdit12: TDBEdit;
    DBEdit13: TDBEdit;
    DBEdit14: TDBEdit;
    DBEdit2: TDBEdit;
    DBEdit3: TDBEdit;
    DBEdit4: TDBEdit;
    DBEdit5: TDBEdit;
    DBEdit6: TDBEdit;
    DBEdit7: TDBEdit;
    DBEdit8: TDBEdit;
    DBEdit9: TDBEdit;
    Dbf1: TDbf;
    DBGrid1: TDBGrid;
    DBNavigator1: TDBNavigator;
    Edit1: TEdit;            Edit2: TEdit;
    GroupBox1: TGroupBox;    GroupBox2: TGroupBox;
    GroupBox3: TGroupBox;
    GroupBox4: TGroupBox;
    Label1: TLabel;
    Label10: TLabel;
    Label11: TLabel;
    Label12: TLabel;
    Label13: TLabel;
    Label14: TLabel;
    Label15: TLabel;
    Label16: TLabel;
    Label2: TLabel;    Label3: TLabel;
    Label4: TLabel;    Label5: TLabel;    Label6: TLabel;
    Label7: TLabel;
    Label8: TLabel;
    Label9: TLabel;
    LazSerial1: TLazSerial;    LazSerial2: TLazSerial;
    MainMenu1: TMainMenu;
    Memo1: TMemo;    Memo2: TMemo;    Memo3: TMemo;
    MenuItem1: TMenuItem;
    MenuItem10: TMenuItem;
    MenuItem2: TMenuItem;    MenuItem3: TMenuItem;
    MenuItem4: TMenuItem;    MenuItem5: TMenuItem;    MenuItem6: TMenuItem;
    MenuItem7: TMenuItem;
    MenuItem8: TMenuItem;
    MenuItem9: TMenuItem;
    PageControl1: TPageControl;    PageControl2: TPageControl;
    PageControl3: TPageControl;    Panel1: TPanel;
    PopupMenu1: TPopupMenu;    PopupMenu2: TPopupMenu;    PopupMenu3: TPopupMenu;
    SpinEdit1: TSpinEdit;
    StringGrid1: TStringGrid;    StringGrid2: TStringGrid;
    StringGrid3: TStringGrid;    StringGrid4: TStringGrid;
    TabSheet1: TTabSheet;    TabSheet2: TTabSheet;    TabSheet3: TTabSheet;
    TabSheet4: TTabSheet;    TabSheet5: TTabSheet;    TabSheet6: TTabSheet;
    TabSheet7: TTabSheet;
    Timer1: TTimer;
    procedure BitBtn1Click(Sender: TObject);
    procedure Button1Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure Button3Click(Sender: TObject);
    procedure Button4Click(Sender: TObject);
    procedure Button5Click(Sender: TObject);
    procedure Button6Click(Sender: TObject);
    procedure Button7Click(Sender: TObject);
    procedure Button8Click(Sender: TObject);
    procedure Button9Click(Sender: TObject);
    procedure CheckBox1Change(Sender: TObject);
    procedure CheckBox2Change(Sender: TObject);
    procedure CheckBox3Change(Sender: TObject);
    procedure CheckBox4Change(Sender: TObject);
    procedure CheckBox5Change(Sender: TObject);

    procedure ComboBox1EditingDone(Sender: TObject);
    procedure ComboBox2EditingDone(Sender: TObject);
    procedure ComboBox3EditingDone(Sender: TObject);
    procedure ComboBox4EditingDone(Sender: TObject);
    procedure ComboBox5EditingDone(Sender: TObject);
    procedure DBEdit13Change(Sender: TObject);
    procedure DBEdit13EditingDone(Sender: TObject);
    procedure DBEdit14Change(Sender: TObject);
    procedure Dbf1AfterEdit(DataSet: TDataSet);
    procedure Dbf1BeforeEdit(DataSet: TDataSet);
    procedure DBGrid1DrawColumnCell(Sender: TObject; const Rect: TRect;
      DataCol: Integer; Column: TColumn; State: TGridDrawState);
    procedure DBGrid1Enter(Sender: TObject);
    procedure DBGrid1Exit(Sender: TObject);
    procedure DBGrid1FieldEditMask(Sender: TObject; const Field: TField;
      var Value: string);
    procedure FormCreate(Sender: TObject);
    procedure FormDestroy(Sender: TObject);
    procedure LazSerial1RxData(Sender: TObject);
    procedure LazSerial2RxData(Sender: TObject);
    procedure MenuItem10Click(Sender: TObject);
    procedure MenuItem1Click(Sender: TObject);
    procedure MenuItem2Click(Sender: TObject);
    procedure MenuItem3Click(Sender: TObject);
    procedure MenuItem4Click(Sender: TObject);
    procedure MenuItem5Click(Sender: TObject);
    procedure MenuItem6Click(Sender: TObject);
    procedure MenuItem8Click(Sender: TObject);
    procedure MenuItem9Click(Sender: TObject);
    procedure SpinEdit1Change(Sender: TObject);
    procedure SpinEdit2Change(Sender: TObject);

    procedure StringGrid1DblClick(Sender: TObject);
    procedure StringGrid1Selection(Sender: TObject; aCol, aRow: Integer);
    procedure StringGrid3Click(Sender: TObject);
    procedure StringGrid3ColRowMoved(Sender: TObject; IsColumn: Boolean;
      sIndex, tIndex: Integer);
    procedure StringGrid3CompareCells(Sender: TObject; ACol, ARow, BCol,
      BRow: Integer; var Result: integer);
    procedure StringGrid3DblClick(Sender: TObject);

    procedure StringGrid3Selection(Sender: TObject; aCol, aRow: Integer);
    procedure StringGrid4AfterSelection(Sender: TObject; aCol, aRow: Integer);
    procedure StringGrid4Click(Sender: TObject);
    procedure TabSheet7ContextPopup(Sender: TObject; MousePos: TPoint;
      var Handled: Boolean);
    procedure Timer1Timer(Sender: TObject);
    PROCEDURE IF_INP(S:STRING);
    procedure Menu_Item_Click(nm:string);
  private
     key_id:tstringlist;
         DT:TTIME;
     db_arh:tdbf;
  public
  end;
var
   Form1: TForm1;
implementation
{$R *.lfm}
{ TForm1 }
procedure TForm1.Menu_Item_Click(nm:string);
Var Info : TSearchRec; s:string;
begin  s:=ExtractFilePath(ParamStr(0))+nm; //'my.dbf';
   Dbf1.Active:=false;
   Dbf1.FilePath:='';
   Dbf1.FilePathFull:='';
  if findfirst(s,   faAnyFile,  Info )=0 then
  begin Dbf1.TableName:=s;
        Dbf1.Active:=true;;
  end;
end;

PROCEDURE TFORM1.IF_INP(S:STRING);
VAR I:byte;
BEGIN

END;

function clear_str(s:string):string;
    var  d:string;      n:byte;
  begin  n:=1;      d:=s;
   while n<=length(d) do
      begin
      if d[n] in ['+','-','1','2','3','4','5','6','7','8','9','0','.',','] then
         begin
         if d[n]='.' then  d[n]:=',';
         if d[n]=',' then //-заменим на запятую точку
         if   n =1   then
             begin               d:='0'+d;
             if length(d)=2 then d:=d+'0';
             inc(n); continue;
             end else
          if   n =length(d)   then
              begin d:=d+'0';
              inc(n); continue;
              end ;
         if d[n]='-' then
         if   n >1   then
             begin  delete(d,n,1); continue; end;
         inc(n);  continue;
         end ;      delete(d,n,1);
      end;
  if length(d)<2 then       d:='0'+d;
     clear_str:=d;
 end;

function GetSerialPortsList: TStringList;
 // Получить список существующих в систиеме Com-портов (uses Registry)
var reg: TRegistry;
   lstSerialCommValues : TStringList;
   i: Integer;
begin
   reg:= TRegistry.Create;
   lstSerialCommValues:= TStringList.Create;
   Result := TStringList.Create;
   try
       reg.RootKey:= HKEY_LOCAL_MACHINE;
       reg.OpenKeyReadOnly('HARDWARE\DEVICEMAP\SERIALCOMM');
          // Заполняем список параметрами из указанного выше раздела
       reg.GetValueNames(lstSerialCommValues);
      for i:=0 to lstSerialCommValues.Count-1 do
      begin        // Выбираем из этого списка подходящие значения параметров
           if AnsiStartsStr('COM', reg.ReadString(lstSerialCommValues[i])) then
           begin // Добавляем отобранное в результирующий список
           Result.Add(reg.ReadString(lstSerialCommValues[i]));
           end;
       end;
   finally
       lstSerialCommValues.Free;
       reg.CloseKey;
       reg.Free;
   end;
end;

procedure TForm1.CheckBox1Change(Sender: TObject);
begin
  LazSerial1.Active:=not CheckBox1.Checked;
   GroupBox1.Enabled:=CheckBox1.Checked;
end;

procedure TForm1.CheckBox2Change(Sender: TObject);
begin
 LazSerial2.Active:=not CheckBox2.Checked;
  GroupBox2.Enabled:=CheckBox2.Checked;
end;

procedure TForm1.CheckBox3Change(Sender: TObject);
begin
timer1.Enabled:=CheckBox3.Checked;
CheckBox4.Enabled:=CheckBox3.Checked;
CheckBox5.Enabled:=CheckBox3.Checked;
end;

procedure TForm1.CheckBox4Change(Sender: TObject);
begin
LazSerial1.Active:=CheckBox4.Checked;
end;

procedure TForm1.CheckBox5Change(Sender: TObject);
begin
 LazSerial2.Active:=CheckBox5.Checked;
end;



procedure TForm1.Button1Click(Sender: TObject);
var s:ansistring;
begin
    s:=UTF8ToCP1251(edit1.Text);
if   LazSerial1.Active then
if   pos(LazSerial1.Device,combobox1.Text)>=0 then
   LazSerial1.WriteData(s);
end;


procedure TForm1.BitBtn1Click(Sender: TObject);
var g,w,j,i:integer; s5,s6:string;
begin
   stringgrid3.RowCount:=1001;
   stringgrid3.loadfromfile('potoc_rtu');
   for i:=1 to 1000 do
      if length(stringgrid3.Cells[1,i])>0 then j:=i;
   stringgrid3.RowCount:=j+1;

   for i:=1 to stringgrid3.RowCount-1 do begin
    s5:=stringgrid3.Cells[5,i];
    s6:=stringgrid3.Cells[6,i];  // memo1.Lines.Add(inttostr(arow));
    if length(s5)=0 then ;   if length(s6)=0 then exit;
     w:=strtoint(s5)*255+strtoint(s6);
    if '01'=stringgrid3.Cells[2,i] then g:=round(w/8+0.5);
    if '02'=stringgrid3.Cells[2,i] then g:=round(w/8+0.5);
    if '03'=stringgrid3.Cells[2,i] then g:=round(w*2);
    if '04'=stringgrid3.Cells[2,i] then g:=round(w*2);
    if '05'=stringgrid3.Cells[2,i] then g:=4;
    if '06'=stringgrid3.Cells[2,i] then g:=4;
            stringgrid3.Cells[9,i]:=inttostr(g);
   end;
   StringGrid3Click(Sender);
end;



procedure TForm1.Button2Click(Sender: TObject);
var s:ansistring;
begin
     s:=UTF8ToCP1251(edit2.Text);
if   LazSerial2.Active then
if   pos(LazSerial2.Device,combobox3.Text)>=0 then
   LazSerial2.WriteData(s);
end;

procedure TForm1.Button3Click(Sender: TObject);
var z,s:string; r:integer; i:word;
begin
    s:='';
for i:=1 to stringgrid1.RowCount-3 do
    begin                    z:=stringgrid1.Cells[1,i];
    if length(z)=0 then z:='0'; stringgrid1.Cells[1,i]:=z;
                  r:=strtoint(z);
    if r>255 then r:=255; s:=s+chr(r);
    end;  z:=crc16string(s);
StringGrid1.Cells[2,StringGrid1.rowcount-2]:=inttohex(ORD(Z[1]));
StringGrid1.Cells[2,StringGrid1.rowcount-1]:=inttohex(ORD(Z[2]));
stringgrid1.Cells[1,stringgrid1.rowcount-2]:=inttostr(ORD(Z[1]));
stringgrid1.Cells[1,stringgrid1.rowcount-1]:=inttostr(ORD(Z[2]));
memo2.Lines.Add('-'+inttostr(ORD(Z[1]) )+'-'+inttostr(ORD(Z[2])));
end;

procedure TForm1.Button4Click(Sender: TObject);
var i,j:integer;
begin  i:=stringgrid2.row;
       Button3Click(Sender); // пересчитаем контрольнуюсумму--
for j:=1 to 8 do
   stringgrid2.Cells[j,i]:=stringgrid1.Cells[1,j];
end;

procedure TForm1.Button5Click(Sender: TObject);
var i,j:integer;
begin  i:=stringgrid2.row;
for j:=1 to 8 do
   stringgrid1.Cells[1,j]:=stringgrid2.Cells[j,i];
end;

procedure TForm1.Button6Click(Sender: TObject);
begin
if stringgrid2.RowCount>1 then
  stringgrid2.DeleteRow(stringgrid2.Row);
end;

procedure TForm1.Button7Click(Sender: TObject);
begin
StringGrid2.Rowcount:=StringGrid2.Rowcount+1;
end;

procedure TForm1.Button8Click(Sender: TObject);
var j,i:integer;
begin
               stringgrid3.RowCount:=stringgrid2.RowCount;
               stringgrid3.colCount:=stringgrid2.colCount+2;
   for j:=1 to stringgrid2.colCount-1 do
   for i:=1 to stringgrid2.RowCount-1 do
               stringgrid3.Cells[j,i]:=stringgrid2.Cells[j,i];
end;

procedure TForm1.Button9Click(Sender: TObject);
var z,s:string; i:integer;
begin s:='';
   s:=chr(strtoint(stringgrid3.Cells[1,stringgrid3.row]))+
      chr(strtoint(stringgrid3.Cells[2,stringgrid3.row]))+
      chr(strtoint(stringgrid3.Cells[9,stringgrid3.row]));
      for i:=1 to stringgrid4.RowCount-3 do
    begin z:=stringgrid4.Cells[1,i]; if z='' then z:='00';
          s:=s+chr(strtoint(z));
    end;  z:=crc16string(s);
    memo2.Lines.Add('-'+inttostr(ORD(Z[1]) )+'-'+inttostr(ORD(Z[2])));
end;

procedure TForm1.ComboBox1EditingDone(Sender: TObject);
begin
  LazSerial1.Device:=ComboBox1.Text;
  memo1.Lines.Add( LazSerial1.Device);
end;

procedure TForm1.ComboBox2EditingDone(Sender: TObject);
begin
   case ComboBox2.ItemIndex of
   0:LazSerial1.BaudRate:=br__9600;
   1:LazSerial1.BaudRate:=br_19200;
   2:LazSerial1.BaudRate:=br115200;
   end;
end;

procedure TForm1.ComboBox3EditingDone(Sender: TObject);
begin
    LazSerial2.Device:=ComboBox3.Text;
  memo1.Lines.Add( LazSerial2.Device);
end;

procedure TForm1.ComboBox4EditingDone(Sender: TObject);
begin
   case ComboBox4.ItemIndex of
   0:LazSerial2.BaudRate:=br__9600;
   1:LazSerial2.BaudRate:=br_19200;
   2:LazSerial2.BaudRate:=br115200;
   end;
end;

procedure TForm1.ComboBox5EditingDone(Sender: TObject);
var s:string;
begin
memo1.Lines.add(combobox5.Text);
             s:=combobox5.Text;
             Label16.caption:=key_id.Strings[combobox5.ItemIndex];
                           s:=key_id.Strings[combobox5.ItemIndex];
             dbf1.Filtered:=false;
if combobox5.Text='-ALL-' then exit;
             dbf1.Filter:='ID="'+s+'"';
             dbf1.Filtered:=true;
end;

procedure TForm1.DBEdit13Change(Sender: TObject);
begin

end;



procedure TForm1.DBEdit13EditingDone(Sender: TObject);
var s:string;
begin
IF COMBOBOX5.ItemIndex<1 THEN EXIT;
IF dbf1.RecordCount<1 THEN EXIT;
IF DT=TIME THEN EXIT;
     EXIT;
    db_arh.Append;
    db_arh.FieldByName('id'    ).asString:=dbf1.FieldByName('id'  ).AsString;
    db_arh.FieldByName('name'  ).asString:=dbf1.FieldByName('name').AsString;
    db_arh.FieldByName('iN_out').asString:=dbf1.FieldByName('in_out').AsString;
    db_arh.FieldByName('type'  ).asstring:=dbf1.FieldByName('type').AsString;
    db_arh.FieldByName('host'  ).asstring:=dbf1.FieldByName('host').AsString;
    db_arh.FieldByName('ip1'   ).asstring:=dbf1.FieldByName('ip1' ).AsString;
    db_arh.FieldByName('ip2'   ).asstring:=dbf1.FieldByName('ip2' ).AsString;
    db_arh.FieldByName('ip3'   ).asstring:=dbf1.FieldByName('ip3' ).AsString;
    db_arh.FieldByName('ip4'   ).asstring:=dbf1.FieldByName('ip4' ).AsString;
    db_arh.FieldByName('port'  ).AsInteger:=dbf1.FieldByName('port').asinteger;
    db_arh.FieldByName('adress').asinteger:=dbf1.FieldByName('port').asinteger;
    db_arh.FieldByName('adr'   ).asstring:=dbf1.FieldByName('adr'    ).AsString;
    db_arh.FieldByName('prim'  ).asstring:=dbf1.FieldByName('prim'   ).AsString;
    db_arh.FieldByName('coment').asstring:=dbf1.FieldByName('coment' ).AsString;
    db_arh.FieldByName('dat_in').asstring:=dbf1.FieldByName('dat_in').AsString;
    db_arh.FieldByName('dat_ou').asstring:=dbf1.FieldByName('dat_ou' ).AsString;
    db_arh.FieldByName('key'   ).asstring:=dbf1.FieldByName('key'    ).AsString;
    db_arh.FieldByName('key_id').asstring:=dbf1.FieldByName('key_id' ).AsString;
    db_arh.FieldByName('ddat' ).AsDatetime:=date;
    db_arh.FieldByName('sdat'  ).asstring:=DateToStr(date);
   db_arh.Post;
   DT:=TIME;
end;

procedure TForm1.DBEdit14Change(Sender: TObject);
begin

end;


procedure TForm1.Dbf1AfterEdit(DataSet: TDataSet);
begin
IF COMBOBOX5.ItemIndex<1 THEN EXIT;  IF dbf1.RecordCount<1 THEN EXIT;
//IF DT=TIME THEN EXIT;
db_arh.Append;
    db_arh.FieldByName('id'    ).asString:=dbf1.FieldByName('id'  ).AsString;
    db_arh.FieldByName('name'  ).asString:=dbf1.FieldByName('name').AsString;
    db_arh.FieldByName('iN_out').asString:=dbf1.FieldByName('in_out').AsString;
    db_arh.FieldByName('type'  ).asstring:=dbf1.FieldByName('type').AsString;
    db_arh.FieldByName('host'  ).asstring:=dbf1.FieldByName('host').AsString;
    db_arh.FieldByName('ip1'   ).asstring:=dbf1.FieldByName('ip1' ).AsString;
    db_arh.FieldByName('ip2'   ).asstring:=dbf1.FieldByName('ip2' ).AsString;
    db_arh.FieldByName('ip3'   ).asstring:=dbf1.FieldByName('ip3' ).AsString;
    db_arh.FieldByName('ip4'   ).asstring:=dbf1.FieldByName('ip4' ).AsString;
    db_arh.FieldByName('port'  ).AsInteger:=dbf1.FieldByName('port').asinteger;
    db_arh.FieldByName('adress').asinteger:=dbf1.FieldByName('port').asinteger;
    db_arh.FieldByName('adr'   ).asstring:=dbf1.FieldByName('adr'    ).AsString;
    db_arh.FieldByName('prim'  ).asstring:=dbf1.FieldByName('prim'   ).AsString;
    db_arh.FieldByName('coment').asstring:=dbf1.FieldByName('coment' ).AsString;
    db_arh.FieldByName('dat_in').asstring:=dbf1.FieldByName('dat_in').AsString;
    db_arh.FieldByName('dat_ou').asstring:=dbf1.FieldByName('dat_ou' ).AsString;
    db_arh.FieldByName('key'   ).asstring:=dbf1.FieldByName('key'    ).AsString;
    db_arh.FieldByName('key_id').asstring:=dbf1.FieldByName('key_id' ).AsString;
    db_arh.FieldByName('ddat' ).AsDatetime:=date;
    db_arh.FieldByName('sdat'  ).asstring:=DTOS(DateToStr(date));  db_arh.Post;
//    DT:=TIME;
end;

procedure TForm1.Dbf1BeforeEdit(DataSet: TDataSet);
BEGIN
IF COMBOBOX5.ItemIndex<1 THEN EXIT;
IF dbf1.RecordCount<1 THEN EXIT;
IF DT=TIME THEN EXIT;
   db_arh.Append;
   db_arh.FieldByName('id'    ).asString:=dbf1.FieldByName('id'  ).AsString;
   db_arh.FieldByName('name'  ).asString:=dbf1.FieldByName('name').AsString;
   db_arh.FieldByName('iN_out').asString:=dbf1.FieldByName('in_out').AsString;
   db_arh.FieldByName('type'  ).asstring:=dbf1.FieldByName('type').AsString;
   db_arh.FieldByName('host'  ).asstring:=dbf1.FieldByName('host').AsString;
   db_arh.FieldByName('ip1'   ).asstring:=dbf1.FieldByName('ip1' ).AsString;
   db_arh.FieldByName('ip2'   ).asstring:=dbf1.FieldByName('ip2' ).AsString;
   db_arh.FieldByName('ip3'   ).asstring:=dbf1.FieldByName('ip3' ).AsString;
   db_arh.FieldByName('ip4'   ).asstring:=dbf1.FieldByName('ip4' ).AsString;
   db_arh.FieldByName('port'  ).AsInteger:=dbf1.FieldByName('port').asinteger;
   db_arh.FieldByName('adress').asinteger:=dbf1.FieldByName('port').asinteger;
   db_arh.FieldByName('adr'   ).asstring:=dbf1.FieldByName('adr'    ).AsString;
   db_arh.FieldByName('prim'  ).asstring:=dbf1.FieldByName('prim'   ).AsString;
   db_arh.FieldByName('coment').asstring:=dbf1.FieldByName('coment' ).AsString;
   db_arh.FieldByName('dat_in').asstring:=dbf1.FieldByName('dat_in').AsString;
   db_arh.FieldByName('dat_ou').asstring:=dbf1.FieldByName('dat_ou' ).AsString;
   db_arh.FieldByName('key'   ).asstring:=dbf1.FieldByName('key'    ).AsString;
   db_arh.FieldByName('key_id').asstring:=dbf1.FieldByName('key_id' ).AsString;
   db_arh.FieldByName('ddat' ).AsDatetime:=date;
   db_arh.FieldByName('sdat'  ).asstring:=DateToStr(date);
  db_arh.Post;
  DT:=TIME;
END;


procedure TForm1.DBGrid1DrawColumnCell(Sender: TObject; const Rect: TRect;
  DataCol: Integer; Column: TColumn; State: TGridDrawState);
begin
  if Column.FieldName = 'OU' then
    begin
      TDBGrid(Sender).Canvas.FillRect(Rect);
      // фон
      TDBGrid(Sender).Canvas.Brush.Color := clgreen;
      // цвет
      TDBGrid(Sender).Canvas.Font.Color := clred;
      // а можно еще и написать заместо выводимого
      if Column.Field.asInteger = 1 then
        TDBGrid(Sender).Canvas.TextOut(Rect.Left, Rect.Top, 'Люблю бисквитные торты и ...');
   end;
end;

procedure TForm1.DBGrid1Enter(Sender: TObject);
begin
  memo1.Lines.Add('eee');
end;

procedure TForm1.DBGrid1Exit(Sender: TObject);
begin
memo1.Lines.Add('exit');
end;

procedure TForm1.DBGrid1FieldEditMask(Sender: TObject; const Field: TField;
  var Value: string);
begin
memo1.Lines.Add(Value);
end;

procedure TForm1.FormCreate(Sender: TObject);
var lstCom: TStringList;
begin create_DBF('OPPONENT.DBF');
      create_DBF('DAT.DBF');
      create_DBF('arh.DBF');
      create_DBF('key.DBF');
      arh_dbf(db_arh,'arh.DBF');
     key_load('key.DBF',db_arh);
      KEY_ID:=TSTRINGLIST.Create;
      KEY_ID:=CMB( ComboBox5,'OPPONENT.DBF');
      Menu_Item_Click('DAT.DBF');
  lstCom:= GetSerialPortsList;
  ComboBox1.Items.Assign(lstCom);
  ComboBox3.Items.Assign(lstCom); lstCom.Free;
  ComboBox4.Items.Add('9600');
  ComboBox4.Items.Add('19200');
  ComboBox4.Items.Add('115200');
  lazserial1.BaudRate:=br__9600;
  lazserial2.BaudRate:=br__9600;
  MenuItem4Click(Sender);   //load potok
  MenuItem6Click(Sender);  //load slave
                   DT:=TIME;
//   form4.Dbf1.Active:=FALSE;
end;

procedure TForm1.FormDestroy(Sender: TObject);
begin
  key_id.free;
  db_arh.close;
  db_arh.free;
end;

procedure TForm1.LazSerial1RxData(Sender: TObject);
var  z,e,s:string;
begin  z:=''; // прием пакета.
 s:=LazSerial1.ReadData; e:=copy(s,1,length(s)-2);
 z:=crc16string(e); e:=e+z;
 if e=s then  memo2.Lines.Add('ok--'+s)
 else exit; // проверка иначе выход
end;

procedure TForm1.LazSerial2RxData(Sender: TObject);
  var U,z,e,s:string; R,n,ln,i:integer; b1,b2:byte;
begin  z:=''; // прием пакета.
  s:=LazSerial2.ReadData;  e:=copy(s,1,length(s)-2); z:=crc16string(e); e:=e+z;
  if e=s then  memo3.Lines.Add('--ok'+s)
  else exit; // проверка иначе выход
  if not LazSerial2.Active then exit;
    b1:=ord(z[1]); //контрольную сумму на обработку
    b2:=ord(z[2]); ln:=stringgrid3.RowCount-1; i:=1; n:=0;
    while i<ln do   begin //цикл  на поиск готового ответа
       if stringgrid3.Cells[7,i]='' then exit;
       if b1=strtoint(stringgrid3.Cells[7,i]) then // поиск по сравнению
       if b2=strtoint(stringgrid3.Cells[8,i]) then // одигаковости сумм
          begin ln:=i; n:=i; continue; end;   inc(i);
       end;  if ln<>n then BEGIN ///IF_INP(S);  // не нашли- выход!!!
              exit;END;      stringgrid3.row:=n;
             s:=chr(strtoint(stringgrid3.Cells[1,n]))+  //формируем пакет
                chr(strtoint(stringgrid3.Cells[2,n]))+  //формируем пакет
                chr(strtoint(stringgrid3.Cells[9,n]));  //формируем пакет
             i:=1; Z:=stringgrid3.Cells[10,n];          //формируем пакет
             while length(z)>0 do  begin r:=pos('/',z); //формируем пакет
                if r<=0 then begin z:=''; continue; end;//формируем пакет
                U:=copy(z,0,r-1); delete(z,1,r);  S:=S+chr(strtoint(U));
                inc(i); IF I>255 THEN Z:='';             //формируем пакет
                end; Z:=''; z:=crc16string(s); s:=s+z;   //формируем пакет
        MEMO1.Lines.Add(INTTOHEX(ORD(Z[1]))+' '+INTTOHEX(ORD(Z[2])));
        LazSerial2.WriteData(s);  //посылвем готовый ответ
end;

procedure TForm1.MenuItem10Click(Sender: TObject);
begin
form4.Dbf1.Active:=TRUE;
//form4.Dbf2.AddIndex('IDX1','ID',[]);
form4.Dbf2.Active:=TRUE;

  form4.Show;
end;

procedure TForm1.MenuItem1Click(Sender: TObject);
begin
    stringgrid1.SaveToFile('master_rtu');
end;

procedure TForm1.MenuItem2Click(Sender: TObject);
begin
   stringgrid1.loadfromFile('master_rtu');
end;

procedure TForm1.MenuItem3Click(Sender: TObject);
begin
     stringgrid2.SaveToFile('potoc_rtu');
end;

procedure TForm1.MenuItem4Click(Sender: TObject);
var j,i:integer;
begin
   stringgrid2.RowCount:=1001;
   stringgrid2.loadfromfile('potoc_rtu');
   for i:=1 to 1000 do
      if length(stringgrid2.Cells[1,i])>0 then j:=i;
   stringgrid2.RowCount:=j+1;
end;

procedure TForm1.MenuItem5Click(Sender: TObject);
begin
   stringgrid3.SaveToFile('slave_rtu');
end;

procedure TForm1.MenuItem6Click(Sender: TObject);
var j,i:integer;
begin stringgrid3.RowCount:=1001;
      stringgrid3.loadfromfile('slave_rtu');
for i:=1 to 1000 do if length(stringgrid3.Cells[1,i])>0 then j:=i;
      stringgrid3.RowCount:=j+1;
end;

procedure TForm1.MenuItem8Click(Sender: TObject);
begin
form2.Show;
end;

procedure TForm1.MenuItem9Click(Sender: TObject);
begin
    form3.Show;
end;

procedure TForm1.SpinEdit1Change(Sender: TObject);
begin
  timer1.Interval:=SpinEdit1.Value;
end;

procedure TForm1.SpinEdit2Change(Sender: TObject);
begin

end;


procedure TForm1.StringGrid1DblClick(Sender: TObject);
  VAR s,R:STRING; j,i:integer;
  begin
if   StringGrid1.Col=1 then else exit;
if   StringGrid1.row in [1,4,3,2,5,6] then else exit; s:='не больше 255!';
 if   StringGrid1.row =2 then s:='не больше 255!'+#13+
      '01 Чтение DO'+#13 +
      '02 Чтение DI'+#13 +
      '03 Чтение AO'+#13 +
      '04 Чтение AI'+#13 +
      '05 Запись D0'+#13 +
      '06 Запись A0'+#13 ;
    r:= InputBox('байт ввести',s,
    StringGrid1.Cells[StringGrid1.Col,
                      StringGrid1.row]);
  if r='' then r:='0';
    StringGrid1.Cells[StringGrid1.Col,
                      StringGrid1.row]:=clear_str(r);
  s:=inttohex(strtoint(r));
  StringGrid1.Cells[StringGrid1.Col+1,
                    StringGrid1.row]:=s ;
  Button3Click(Sender);
  end;

procedure TForm1.StringGrid1Selection(Sender: TObject; aCol, aRow: Integer);
begin
   if (StringGrid1.Cells[1,2]='06') or
      (StringGrid1.Cells[1,2]='05') then begin
      StringGrid1.Cells[3,5]:='Значение byte HI';
      StringGrid1.Cells[3,6]:='Значение byte LO'; end else
      begin
            StringGrid1.Cells[3,5]:='кол. регисров HI';
            StringGrid1.Cells[3,6]:='кол. регистров LO'; end

end;
procedure TForm1.StringGrid3Click(Sender: TObject);
var q,r,i:word; e:boolean;
begin  e:=false;
  memo1.Lines.Add('click'+inttostr(StringGrid3.row));
if stringgrid3.Cells[9,stringgrid3.row]='' then exit;
  stringgrid4.RowCount:=strtoint( stringgrid3.Cells[9,stringgrid3.row])+3;
  r:=stringgrid4.RowCount; q:=stringgrid4.colCount;
for i:=1 to r-3  do
   begin stringgrid4.Cells[q-1,i]:='--';
   if (stringgrid3.Cells[2,stringgrid3.row]='01' )or
      (stringgrid3.Cells[2,stringgrid3.row]='02' )or
      (stringgrid3.Cells[2,stringgrid3.row]='' )
      then continue;
   if (stringgrid3.Cells[2,stringgrid3.row]='06' )or
      (stringgrid3.Cells[2,stringgrid3.row]='05' )or
      (stringgrid3.Cells[2,stringgrid3.row]='' )
      then begin
      if i=1 then stringgrid4.Cells[q-1,i]:='adress HI';
      if i=1 then stringgrid4.Cells[  1,i]:=stringgrid3.Cells[3,stringgrid3.row];
      if i=2 then stringgrid4.Cells[q-1,i]:='adress LO';
      if i=2 then stringgrid4.Cells[  1,i]:=stringgrid3.Cells[4,stringgrid3.row];
      if i=3 then stringgrid4.Cells[q-1,i]:='значение HI';
      if i=3 then stringgrid4.Cells[  1,i]:=stringgrid3.Cells[5,stringgrid3.row];
      if i=4 then stringgrid4.Cells[q-1,i]:='значение LO';
      if i=4 then stringgrid4.Cells[  1,i]:=stringgrid3.Cells[6,stringgrid3.row];
      end;
   if (stringgrid3.Cells[2,stringgrid3.row]='03' )or
      (stringgrid3.Cells[2,stringgrid3.row]='04' )
        then
   if not e then stringgrid4.Cells[q-1,i]:='byte HI'
            else stringgrid4.Cells[q-1,i]:='byte LO';
    e:= not e;
   end;
  stringgrid4.Cells[q-1,R-2]:='CRC HI';
  stringgrid4.Cells[q-1,R-1]:='CRC LO';
end;

procedure TForm1.StringGrid3ColRowMoved(Sender: TObject; IsColumn: Boolean;
  sIndex, tIndex: Integer);
begin
  memo1.Lines.Add('colrow'+inttostr(StringGrid3.row));
end;

procedure TForm1.StringGrid3CompareCells(Sender: TObject; ACol, ARow, BCol,
  BRow: Integer; var Result: integer);
begin
  memo1.Lines.Add('compare'+inttostr(StringGrid3.row));
end;

procedure TForm1.StringGrid3DblClick(Sender: TObject);
    VAR s,R:STRING; j,i:integer;
begin
  if   StringGrid3.Col=9 then else exit;       s:='не больше 255!';
    r:=StringGrid3.Cells[9,StringGrid3.row]; if r='' then r:='0';
    r:= InputBox('ввести длину данных',s,r);
      StringGrid3.Cells[9, StringGrid3.row]:=clear_str(r);
      StringGrid3Click(Sender);
end;


procedure TForm1.StringGrid3Selection(Sender: TObject; aCol, aRow: Integer);
var g,w:word;s5,s6:string; r,i:integer; n,z,s:string;
begin   StringGrid3Click(Sender); //УКАЖЕМ ДЛИНУ
   g:=AROW; //StringGrid3.row; // memo1.Lines.add('<>'+inttostr(StringGrid4.row));
   s:=stringgrid3.Cells[10,G]; z:=s;
   for i:=1 to  StringGrid4.rowcount-1 do stringgrid4.Cells[1,i]:='';
   for i:=1 to  StringGrid4.rowcount-1 do stringgrid4.Cells[2,i]:='';
//   for i:=1 to  length(s)  do begin
///       z:=inttostr(ord(s[i]));
//       if i>stringgrid4.RowCount-3 then continue;
///       stringgrid4.Cells[1,i]:=z;
///       stringgrid4.Cells[2,i]:=inttohex(strtoint(z));
//   end;
   i:=1;
   while length(z)>0 do
      begin r:=pos('/',z);
      if r<=0 then begin z:=''; continue; end;
      if i>stringgrid4.RowCount-3 then begin z:=''; continue; end;
      n:=copy(z,0,r-1); delete(z,1,r);;
      stringgrid4.Cells[1,i]:=n;
      stringgrid4.Cells[2,i]:=inttohex(strtoint(n));
      inc(i);
      end;
   stringgrid3.Cells[10,g]:=s;
if stringgrid3.Cells[9,arow]='' then    else exit;
 s5:=stringgrid3.Cells[5,arow];
 s6:=stringgrid3.Cells[6,arow];  // memo1.Lines.Add(inttostr(arow));
 if length(s5)=0 then exit;   if length(s6)=0 then exit;
  w:=strtoint(s5)*255+strtoint(s6);
 if '01'=stringgrid3.Cells[2,arow] then g:=round(w/8+0.5);
 if '02'=stringgrid3.Cells[2,arow] then g:=round(w/8+0.5);
 if '03'=stringgrid3.Cells[2,arow] then g:=round(w*2);
 if '04'=stringgrid3.Cells[2,arow] then g:=round(w*2);
 if '05'=stringgrid3.Cells[2,arow] then g:=4;
 if '06'=stringgrid3.Cells[2,arow] then g:=4;
         stringgrid3.Cells[9,arow]:=inttostr(g);
end;
procedure TForm1.StringGrid4AfterSelection(Sender:TObject; aCol, aRow: Integer);
var r,i:integer;n,z,s:string;
begin  r:=StringGrid3.row;
   memo1.Lines.add('afte'+inttostr(+StringGrid4.row));
   s:=stringgrid3.Cells[10,r];  z:=s;
 //  for i:=1 to  length(s)-1 do begin
//       z:=inttostr(ord(s[i]));
//       stringgrid4.Cells[1,i]:=z;
//   end;
i:=1;
while length(z)>0 do
   begin r:=pos('/',z);
   if r<=0 then begin z:=''; continue; end;
   if i>=stringgrid4.RowCount-3 then begin z:=''; continue; end;
   n:=copy(z,0,r-1); delete(z,1,r);
   stringgrid4.Cells[1,i]:=n;
   inc(i);
   end;
end;

procedure TForm1.StringGrid4Click(Sender: TObject);
VAR s,R:STRING; j,i:integer;
begin
if StringGrid4.row>=StringGrid4.rowcount-2 then exit;
if StringGrid4.Col=1 then else exit;        s:='не больше 255!';
r:=StringGrid4.Cells[1,StringGrid4.row]; if r='' then r:='0';
r:= clear_str(InputBox('ввести данные',s,r));
if strtoint(r)>255 then r:='255';
  StringGrid4.Cells[1, StringGrid4.row]:=r;
  StringGrid4.Cells[2, StringGrid4.row]:=inttohex(strtoint(r)); s:='';
  for i:=1 to StringGrid4.rowcount-3 do
      begin
       r:=StringGrid4.Cells[1 ,i]; if r='' then r:='00';
      s:=s+r+'/';
      end;
      StringGrid3.Cells[10,StringGrid3.row]:=s;
end;

procedure TForm1.TabSheet7ContextPopup(Sender: TObject; MousePos: TPoint;
  var Handled: Boolean);
begin

end;

procedure TForm1.Timer1Timer(Sender: TObject);
var    i,q,r:integer; z,s:string;
begin    timer1.Enabled:=false;
         q:=stringgrid2.Rowcount-1;   if q<=0 then exit;
         r:=stringgrid2.Row;
         if r<q then r:=r+1 else   r:=1;
  form1.Caption:=inttostr(stringgrid2.Row);
                  stringgrid2.Row:=r;  z:='';
      for i:=1 to stringgrid2.ColCount-1 do
        if stringgrid2.Cells[i,r]='' then
              z:=z+chr(0) else
              z:=z+chr(strtoint(stringgrid2.Cells[i,r]));
     timer1.Enabled:=true;
     if not LazSerial1.Active then exit;
        memo1.lines.add(z);
    LazSerial1.WriteData(z);
end;

end.

