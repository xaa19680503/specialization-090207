unit Unit1;
{$mode objfpc}{$H+}
interface
uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls, Spin, Menus,
  IdTCPClient, IdTCPServer, IdCustomTCPServer, IdContext ;

type
  { TForm1 }
  TForm1 = class(TForm)
    Button1: TButton;    Edit1: TEdit;    Edit2: TEdit;    Edit3: TEdit;
    IdTCPServer1: TIdTCPServer;
    MainMenu1: TMainMenu;
    Memo1: TMemo;     Memo2: TMemo;
    MenuItem1: TMenuItem;     MenuItem2: TMenuItem;
    SpinEdit1: TSpinEdit;     SpinEdit2: TSpinEdit;
    procedure Button1Click(Sender: TObject);
    procedure FormActivate(Sender: TObject);
    procedure FormClose(Sender: TObject; var CloseAction: TCloseAction);
    procedure IdTCPServer1Execute(AContext: TIdContext);
    procedure MenuItem2Click(Sender: TObject);
    PROCEDURE  SendMessageToServer(const AServerIP: string; const Port: Integer;
      const INF: string);
  private
  public
  end;

var  Form1: TForm1;

implementation
{$R *.lfm}

{ TForm1 }
 procedure TFORM1.SendMessageToServer(
   const AServerIP: string;
        const Port: Integer;
   const INF: string
   );
  VAR   TCPClient: TIdTCPClient;
    VAR
    S:STRING;
begin
  TCPClient := TIdTCPClient.Create(nil);
    TCPClient.Host := AServerIP;
    TCPClient.Port := Port;
    try
      TCPClient.Connect;     // Отправляем данные серверу через поток вывода
    TCPClient.IOHandler.WriteLn('HELL0! ->'+INF);
    MEMO1.Lines.Add('Сообщение получено сервером');
  finally
      TCPClient.Free;
  end;
end;
procedure TForm1.IdTCPServer1Execute(AContext: TIdContext);
VAR S:STRING;
begin     IF NOT IdTCPServer1.Active THEN EXIT;
      // Приняли соединение, обрабатываем запрос клиента
  IF  SIZEOF(AContext.Connection.IOHandler.InputBuffer)=0 THEN EXIT;
  IF NOT  AContext.Connection.Connected THEN EXIT;
      s:= (AContext.Connection.IOHandler.ReadLn);
  if S <>'' then
  begin
    AContext.Connection.IOHandler.Write('Получено! ->'+S);
    MEMO2.LINES.Add(S);
  end;
  SLEEP(400);
end;

procedure TForm1.MenuItem2Click(Sender: TObject);
begin
   MenuItem2.Checked:=  NOT MenuItem2.Checked;
IF MenuItem2.Checked THEN
   MenuItem2.Caption:='В НАСТРОЙКИ' ELSE
   MenuItem2.Caption:='В РАБОТУ';

    SPINEDIT1.Enabled:=MenuItem2.Checked;
        EDIT1.ENABLED:=MenuItem2.Checked;
    SPINEDIT2.ENABLED:=MenuItem2.Checked;
        EDIT2.ENABLED:=MenuItem2.Checked;
      Button1.ENABLED:=NOT MenuItem2.Checked;
  IdTCPServer1.Active:=NOT MenuItem2.Checked;

IF  IdTCPServer1.Active THEN  BEGIN
  IdTCPServer1.Active:=FALSE;
  IdTCPServer1.DefaultPort:=SPINEDIT1.Value;
  IdTCPServer1.Bindings.Items[0].IP:=EDIT1.Text;
  IdTCPServer1.Bindings.Items[0].Port:=SPINEDIT1.Value;
  SLEEP(600);
  IdTCPServer1.Active:=TRUE;
  END;

end;

procedure TForm1.FormActivate(Sender: TObject);
begin
IdTCPServer1.Active:=FALSE;   IdTCPServer1.DefaultPort:=SPINEDIT1.Value;
IdTCPServer1.Bindings.Clear;  IdTCPServer1.Bindings.Add;
IdTCPServer1.Bindings.Items[0].IP:=EDIT1.Text;
IdTCPServer1.DefaultPort:=SPINEDIT1.Value;
IdTCPServer1.Bindings.Items[0].Port:=SPINEDIT1.Value;
IdTCPServer1.Active:=TRUE;
end;

procedure TForm1.FormClose(Sender: TObject; var CloseAction: TCloseAction);
begin       SLEEP(100);
           IdTCPServer1.Active:=FALSE;
           IdTCPServer1.Free;
end;

procedure TForm1.Button1Click(Sender: TObject);
begin
  SendMessageToServer(EDIT2.TEXT, SPINEDIT2.Value,EDIT3.TEXT);
end;

end.

