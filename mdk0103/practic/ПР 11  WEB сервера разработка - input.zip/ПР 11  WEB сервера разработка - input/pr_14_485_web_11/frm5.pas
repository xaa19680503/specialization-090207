unit frm5;
{$mode ObjFPC}{$H+}
interface
uses HTTP_SERVER,   // БИБЛИОТЕКА  процедур СЕРВЕРА
    fphttpserver, fphtml,  // БИБЛИОТЕКА  СЕРВЕРА
         RegexPr,
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, ExtCtrls, StdCtrls;
type
  { TForm5 }
  TForm5 = class(TForm)
    Image1: TImage;
    Memo1: TMemo;
    Splitter1: TSplitter;
    procedure FormCreate(Sender: TObject);
    procedure OnServerRequest(Sender: TObject;
                        var ARequest: TFPHTTPConnectionRequest;
                       var AResponse: TFPHTTPConnectionResponse);
  private
  public
  end;
var
  Form5: TForm5;
   aRes: TFPHTTPConnectionResponse;
implementation
{$R *.lfm}
procedure OnSe;
begin
  ares:=TFPHTTPConnectionResponse.Create;
  ares.Free;
end;

procedure TForm5.OnServerRequest(
            Sender: TObject;
      var ARequest: TFPHTTPConnectionRequest;
     var AResponse: TFPHTTPConnectionResponse  ) ;
var ur: String;  LName,   Nom ,     FN : String;
begin                // inherited HandleRequest(ARequest, AResponse);
   fn:=GetCurrentDir()+'\http\index.html';
   AResponse.Host;

   if not FileExists(FN) then
       begin      AResponse.Code:=404;  AResponse.SendContent;  exit;       end;
ur:=ARequest.URI+'-t-'+AResponse.URL;
  if memo1.Lines.Count>20 then memo1.clear;
     memo1.lines.Add(ur+' -'+EmptyStr +'-');   AResponse.Contents.Clear;
    try       Nom := ARequest.QueryFields.Values['foo'];
    if not (nom = EmptyStr) then   BEGIN
                    AResponse.Content := 'Hello, ' + Nom + '!';
                    AResponse.SendContent;       END
    ELSE    BEGIN
       LName := ARequest.QueryFields.Values['Name'];
    if LName = EmptyStr then begin
                    AResponse.Contents.LoadFromFile(fn);
                    AResponse.SendContent;       end
               else AResponse.Content := 'Hello, ' + LName + '!';
                 END;
     finally
     end;
end;

procedure TForm5.FormCreate(Sender: TObject);
VAR S:STRING;
begin  // RegisterRoutes;
          s:=ExtractFilePath(ParamStr(0))+'\HTTP\S.png';
          Image1.Picture.LoadFromFile(S);
   TThreadServer.Create(8080, @OnServerRequest);
end;
end.

