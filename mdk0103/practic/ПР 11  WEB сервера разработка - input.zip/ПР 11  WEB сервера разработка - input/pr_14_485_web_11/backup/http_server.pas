unit  HTTP_SERVER;
{$mode objfpc}{$H+}
interface
   { TForm5 }

uses  Classes, SysUtils,
//               fphttpapp, httpdefs,   httproute, fpjson, jsonparser, fpwebfile,
               fphttpserver,  // БИБЛИОТЕКА  СЕРВЕРА
              RegexPr;
Type  //ЗДЕСЬ ОПИСЫВАЕМ ОБЬЕКТЫ
  //==================================== // Server ОБЬЕКТ
  TThreadServer = class(TThread) //ОРГАНИЗУЕМ ОБЪЕКТ ПОТОК WEB СЕРВЕРА
  protected
    procedure Execute; override;
  public
      FPHttpServer1: TFPHttpServer;
     constructor Create(Port: Integer; OnQuery: THTTPServerRequestHandler);
      destructor Destroy; override;
  end;
implementation // =========== НИЖЕ  ОПИСАНИЕ ФУНКЦИЙ И ПРОЦЕДУР
  {
procedure DefaultRoute(ARequest: TRequest; AResponse: TResponse);
 begin
  AResponse.Content :=
    '<html>' +
    '<head>' +
    '<title>FP Web Server</title>' +
    '</head>' +
    '<body>' +
    '<ul>' +
    '<li><a href="/">Default</a></li>' +
    '<li><a href="/about">About</a></li>' +
    '</ul>' +
    '<h1>FP Web Server</h1>' +
    '<p>Default Route</>' +
    '</body>' +
    '</html>';
 end;

 procedure AboutRoute(ARequest: TRequest; AResponse: TResponse);
 begin
  AResponse.Content :=
    '<html>' +
    '<head>' +
    '<title>FP Web Server: About</title>' +
    '</head>' +
    '<body>' +
    '<ul>' +
    '<li><a href="/">Default</a></li>' +
    '<li><a href="/about">About</a></li>' +
    '</ul>' +
    '<h1>FP Web Server: About</h1>' +
    '<p>About Route</>' +
    '</body>' +
    '</html>';
 end;
}
procedure RegisterRoutes;
 begin
  // Responds to any method
 // HTTPRouter.RegisterRoute('/', rmAll, @DefaultRoute, True);
  // Responds only to the GET method
  //HTTPRouter.RegisterRoute('/about', rmGet, @AboutRoute);
 end;




// =========== Server ===========
constructor TThreadServer.Create(Port: Integer; OnQuery: THTTPServerRequestHandler);
begin  //RegisterRoutes;
  Self.FreeOnTerminate := true;
  FPHttpServer1 := TFPHttpServer.Create(nil);  // СОЗДАЛИ ОБЬЕКТ WEB СВЯЗИ
  FPHttpServer1.Port := Port;
  FPHttpServer1.OnRequest := OnQuery;
  FPHttpServer1.LookupHostNames:=False;
  inherited Create(False);
end; ////////////////////////////////

destructor TThreadServer.Destroy;
begin  FPHttpServer1.Free;
end; ////////////////////////////////
procedure TThreadServer.Execute;
begin
  try    FPHttpServer1.Active := True;
  except    on E: Exception do
    begin      Exit;    end;
  end;
end; ////////////////////////////////
end.

