unit Unit1;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, ExtCtrls, ComCtrls,
  Grids, StdCtrls, Menus, ValEdit, fpSpreadsheetCtrls, fpSpreadsheetGrid, Types;

type

  { TForm1 }

  TForm1 = class(TForm)
    Button1: TButton;
    Button2: TButton;
    Button3: TButton;
    Button4: TButton;
    Button5: TButton;
    Button6: TButton;
    Button7: TButton;
    Button8: TButton;
    Button9: TButton;
    Edit1: TEdit;
    GroupBox1: TGroupBox;
    GroupBox2: TGroupBox;
    Label1: TLabel;
    ListBox1: TListBox;
    MenuItem1: TMenuItem;
    MenuItem2: TMenuItem;
    PageControl1: TPageControl;
    Panel1: TPanel;
    Panel2: TPanel;
    PopupMenu1: TPopupMenu;
    StringGrid1: TStringGrid;
    sWorksheetGrid1: TsWorksheetGrid;
    TabSheet1: TTabSheet;
    TabSheet2: TTabSheet;
    TabSheet3: TTabSheet;
    procedure Button1Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure Button3Click(Sender: TObject);
    procedure Button4Click(Sender: TObject);
    procedure Button5Click(Sender: TObject);
    procedure Button6Click(Sender: TObject);
    procedure Button7Click(Sender: TObject);
    procedure Button8Click(Sender: TObject);
    procedure Button9Click(Sender: TObject);
    procedure Edit1Enter(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure GroupBox2Click(Sender: TObject);
    procedure ListBox1Click(Sender: TObject);
    procedure ListBox1DblClick(Sender: TObject);
    procedure MenuItem1Click(Sender: TObject);
    procedure MenuItem2Click(Sender: TObject);
    procedure PageControl1Change(Sender: TObject);
    procedure TabSheet2ContextPopup(Sender: TObject; MousePos: TPoint;
      var Handled: Boolean);
  private
  idx:integer;
  public

  end;

var
  Form1: TForm1;

implementation

{$R *.lfm}

{ TForm1 }

procedure TForm1.FormCreate(Sender: TObject);
begin
  StringGrid1.Cells[0,0]:='№';
  StringGrid1.Cells[1,0]:='ИНН';
  StringGrid1.Cells[2,0]:='Название';
  StringGrid1.Cells[3,0]:='адрес';
  StringGrid1.Cells[4,0]:='телефон';
 // StringGrid1.Cells[5,0]:='прелставитель';

end;

procedure TForm1.GroupBox2Click(Sender: TObject);
begin

end;

procedure TForm1.ListBox1Click(Sender: TObject);
begin
                               if listbox1.ItemIndex<0 then exit;
edit1.text:=listbox1.Items.Strings[listbox1.itemindex];

end;

procedure TForm1.ListBox1DblClick(Sender: TObject);
begin
           if listbox1.ItemIndex<0 then exit; // не на позиции
  edit1.Text:=listbox1.Items.Strings[listbox1.ItemIndex];
end;

procedure TForm1.Edit1Enter(Sender: TObject);
begin
 if listbox1.ItemIndex<0 then exit; // не на позиции
    listbox1.Items.Strings[listbox1.ItemIndex]:=edit1.Text;  // редактируем
end;

procedure TForm1.Button1Click(Sender: TObject);
begin
  listbox1.Items.SaveToFile('list1.xtx');
end;

procedure TForm1.Button2Click(Sender: TObject);
begin
 listbox1.Items.loadfromFile('list1.xtx');
end;

procedure TForm1.Button3Click(Sender: TObject);
begin
    ListBox1.items.Clear;
end;

procedure TForm1.Button4Click(Sender: TObject);
begin
stringGrid1.rowcount:=stringGrid1.rowCount+1;
stringGrid1.Cells[0,stringGrid1.rowcount-1]:=
        inttostr(stringGrid1.rowCount-1);
end;

procedure TForm1.Button5Click(Sender: TObject);
begin
   if   (stringGrid1.RowCount)>1 then
         stringGrid1.rowCount:=stringGrid1.rowCount-1;
end;
/////////////      ////////////////
procedure TForm1.Button6Click(Sender: TObject);
begin
 stringGrid1.RowCount:=1;
end;
//////////////   ////////////////
procedure TForm1.Button7Click(Sender: TObject);
begin
  stringgrid1.savetofile('stringgrid1.txt');
end;
////////////////////////  ///////////////////
procedure TForm1.Button8Click(Sender: TObject);
Var Info : TSearchRec;         s:string;
begin
    stringgrid1.RowCount:=20;
 s:=ExtractFilePath(ParamStr(0))+'stringgrid1.txt';
   if findfirst(s, faAnyFile, Info )=0 then else
    begin showmessage('file not find '); exit; end;
  stringgrid1.LoadFromFile('stringgrid1.txt');
end;

procedure TForm1.Button9Click(Sender: TObject);
begin

end;

procedure TForm1.MenuItem1Click(Sender: TObject);
begin
  ListBox1.Items.Add('?');
end;

procedure TForm1.MenuItem2Click(Sender: TObject);
begin
 if  ListBox1.ItemIndex>=0 then
     ListBox1.Items.Delete(ListBox1.ItemIndex);
end;

procedure TForm1.PageControl1Change(Sender: TObject);
begin


end;

procedure TForm1.TabSheet2ContextPopup(Sender: TObject; MousePos: TPoint;
  var Handled: Boolean);
begin

end;

end.

