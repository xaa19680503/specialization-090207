unit Unit3;
{$mode ObjFPC}{$H+}
interface
uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, TAGraph, TASeries;
type
  { TForm3 }
  TForm3 = class(TForm)
    Chart1: TChart;
    Chart1BarSeries1: TBarSeries;
    Chart1LineSeries1: TLineSeries;
  private
  public
    proc, value: array of real;
    max_proc, max_value:real;
  end;
var
  Form3: TForm3;
implementation
{$R *.lfm}
{ TForm3 }
end.

