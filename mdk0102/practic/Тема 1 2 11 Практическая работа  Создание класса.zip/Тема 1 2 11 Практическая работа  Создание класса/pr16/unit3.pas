unit Unit3;
{$mode ObjFPC}{$H+}
interface
uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, TAGraph, TASeries;
type
  { TForm3 }
  TForm3 = class(TForm)
    Chart1: TChart;
    Chart1BarSeries1: TBarSeries;
    Chart1LineSeries1: TLineSeries;
  private
  public
    proc, value: array of real;
    max_proc, max_value:real;
  end;
var
  Form3: TForm3;
implementation
{$R *.lfm}
{ TForm3 }
end.
procedure TForm1.MenuItem4Click(Sender: TObject);
var v,i:integer; g,r:real;
 begin
   if id<0 then id:=0 else  inc(id);    //указали позицию
   setlength(grf,id+1); // определили место  где создать форму
   Application.CreateForm(TForm3,grf[id]);  // создали форму
                        V:=stringgrid2.col;
   setlength(grf[id].value,stringgrid2.RowCount);
  // setlength(grf[id].proc ,stringgrid2.RowCount);
              for i:=1 to  stringgrid2.RowCount-1 do
      begin
          if           stringgrid2.Cells[v,i]='' then r:=0 else
         r:=strtofloat(stringgrid2.Cells[v,i]);  grf[id].value[i]:=r;
//          if i=1 then grf[id].max_value:=abs(r);
//          if          grf[id].max_value< abs(r) then
//                      grf[id].max_value:=abs(r);
     end;   //          grf[id].max_proc:=grf[id].max_value/100;

//  for i:=0 to stringgrid2.RowCount-1 do
//        begin  //-----преобразуем в  процент----
//        g:=grf[id].value[i];
//        g:=g/grf[id].max_proc;
//        grf[id].proc[i]:=g;
//        end;
     randomize;
     grf[id].Chart1LineSeries1.Clear();
     for i:=0 to length(grf[id].value)-1 do
     begin
     g:=grf[id].value[i];
        grf[id].Chart1LineSeries1.AddXY(i,g); //i*0.1,sin(random(4)*i*0.1));
     end;
     grf[id].Show;  //---показали-------
 end;
