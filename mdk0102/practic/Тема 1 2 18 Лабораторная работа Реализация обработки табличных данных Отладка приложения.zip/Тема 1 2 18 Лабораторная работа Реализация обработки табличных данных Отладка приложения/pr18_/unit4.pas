unit Unit4;
{$mode ObjFPC}{$H+}
interface
uses
  Classes, SysUtils, Forms,unit3,
  Controls, Graphics, Dialogs, StdCtrls,TASeries,
 ExtCtrls, ActnList,TAGraph;
type

  { TForm4 }

  TForm4 = class(TForm3)
    ComboBox1: TComboBox;
    procedure Button1Click(Sender: TObject);
    procedure ComboBox1Change(Sender: TObject);
    procedure FormClose(Sender: TObject; var CloseAction: TCloseAction);

    procedure FormShow(Sender: TObject);
    procedure Panel2Click(Sender: TObject);
    procedure RadioGroup1Click(Sender: TObject);
  private
  public  ind:integer;
     max,prc:real;
  //  proc, value: array of real;
    ///   max_proc, max_value:real;
//                firm: array of one_then;
    //   n_firm,  count_firm:integer;
  end;
var
  Form4: TForm4;
implementation
{$R *.lfm}

{ TForm4 }
  //---
procedure TForm4.FormClose(Sender: TObject; var CloseAction: TCloseAction);
var i:integer;
begin
   for i:=0 to length(firm)-1 do
              setlength(firm[i].one,0);
              setlength(firm,0);
end;  //---

procedure TForm4.ComboBox1Change(Sender: TObject);
var        b:TLineSeries;  i:integer;  s:TbarSeries;
begin if combobox1.ItemIndex<0   then exit;  // вдруг  не в диапозоне
      if combobox1.Items.Count=0 then exit;  // вдруг  не  диапозона
       Chart1.ClearSeries();                // капец вcем графикам.
   s:=TbarSeries.Create(Chart1);  // создали график.
   s.Depth:=4;
   s.SeriesColor:=clblue;          // графику цвет.
for i:=0 to  length(firm)-1 do     //выборка по вертикали
   if radiogroup1.ItemIndex<1then  //выборка по проценту или величине
           S.AddXY(i,firm[i].one[combobox1.ItemIndex].value, firm[i].inn, clred)
    else   S.AddXY(i,firm[i].one[combobox1.ItemIndex].proc, firm[i].inn, clred);
Chart1.AddSeries(s);              // добили  серию - графмк
end;

procedure TForm4.Button1Click(Sender: TObject);
begin
  inherited;    Chart1.ClearSeries();           // капец вcем графикам.
end;


procedure TForm4.FormShow(Sender: TObject);
var V,e,i:integer;
begin
  inherited;
  if length(firm[0].one)<1 then exit; //если ничего нет---

for i:=0 to length(firm[0].one)-1 do       // в список критерии из списка.
   combobox1.Items.add(firm[0].one[i].nam);
   combobox1.Text:=combobox1.Items.Strings[0];
   combobox1.ReadOnly:=true;;

for e:=0 to COMBOBOX1.Items.Count-1 do  begin  //процентовка  по ВЕРТИКАЛИ
for i:=0 to length(firm)-1 do    begin
 if i=0 then  max:=ABS(firm[i].one[e].value);
           if max <abs(firm[i].one[e].value) then
              max:=abs(firm[i].one[e].value);
   end; prc:=max/100;   // процент ставка изветна
for I:=0 to length(firm)-1 do   // УКАЖЕМ ПРОЦЕНТ ПО ВЕРТИКАЛИ
   IF  PRC=0 THEN   firm[I].one[E].proc:=0
             ELSE   firm[I].one[E].proc:=firm[I].one[E].value/prc;
   end;
for i:=0 to length(firm)-1 do    begin
for e:=0 to length(firm[i].one)-1 do  begin  //процентовка  по горизонтали
  if E=0 theN
     firm[i].max_value:=ABS(firm[i].one[e].value);
  if firm[i].max_value <abs(firm[i].one[e].value) then
     firm[i].max_value:=abs(firm[i].one[e].value);
   end; firm[i].prc_value:=firm[i].max_value/100;
for E:=0 to length(firm[i].one)-1 do
                   firm[i].one[e].procent:=
                   firm[i].one[e].value/firm[i].prc_value; // УКАЖЕМ ПРОЦЕНТ ПО ГОРИЗОНТАЛИ
   end;
end;

procedure TForm4.Panel2Click(Sender: TObject);
begin

end;

procedure TForm4.RadioGroup1Click(Sender: TObject);
begin
  inherited;

end;

end.

