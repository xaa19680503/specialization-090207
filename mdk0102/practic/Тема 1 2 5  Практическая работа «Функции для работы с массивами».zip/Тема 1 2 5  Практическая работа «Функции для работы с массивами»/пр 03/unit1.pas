unit Unit1;
{$mode objfpc}{$H+}
interface
uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, ExtCtrls, StdCtrls,
  Grids, Buttons, Menus;
type
  { TForm1 }
  TForm1 = class(TForm)
    Button1: TButton;
    Button2: TButton;
    Edit1: TEdit;
    Memo1: TMemo;
    Panel1: TPanel;
    StringGrid1: TStringGrid;
    procedure Button1Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure Edit1EditingDone(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure MenuItem1Click(Sender: TObject);
    procedure MenuItem2Click(Sender: TObject);
    procedure StringGrid1EditingDone(Sender: TObject);
  private
  public
  end;

var
  Form1: TForm1;
implementation
{$R *.lfm}
function clear_str(s:string):string;
    var  d:string;      n:byte;
  begin  n:=1;      d:=s;
   while n<=length(d) do
      begin
      if d[n] in ['+','-','1','2','3','4','5','6','7','8','9','0','.',','] then
         begin
         if d[n]='.' then  d[n]:=',';
         if d[n]=',' then //-заменим на запятую точку
         if   n =1   then
             begin               d:='0'+d;
             if length(d)=2 then d:=d+'0';
             inc(n); continue;
             end else
          if   n =length(d)   then
              begin d:=d+'0';
              inc(n); continue;
              end ;

         if d[n]='-' then
         if   n >1   then
             begin  delete(d,n,1); continue; end;
         inc(n);  continue;
         end ;      delete(d,n,1);
      end;
  if length(d)<2 then       d:=d+'0';
     clear_str:=d;
 end;


{ TForm1 }
//--------------//----------------//-----------
procedure TForm1.Edit1EditingDone(Sender: TObject);
begin  edit1.text:=clear_str(Edit1.text);
        memo1.Lines.Add(edit1.text);
end;

procedure TForm1.FormCreate(Sender: TObject);
begin

end;

procedure TForm1.MenuItem1Click(Sender: TObject);
begin
 StringGrid1.SortColRow(true, StringGrid1.Row);
end;

procedure TForm1.MenuItem2Click(Sender: TObject);
begin
 StringGrid1.SortColRow(false, StringGrid1.Row);
end;

procedure TForm1.StringGrid1EditingDone(Sender: TObject);
var s:string;
begin
s:=StringGrid1.Cells[StringGrid1.col,StringGrid1.row];
   StringGrid1.Cells[StringGrid1.col,StringGrid1.row]:=clear_str(s);
end;

procedure TForm1.Button1Click(Sender: TObject);
begin
  memo1.Lines.Clear;
end;

procedure TForm1.Button2Click(Sender: TObject);
VAR I:INTEGER;  S:STRING; D,R:REAL; E:INTEGER;
begin
 FOR I:=0 TO MEMO1.Lines.Count-1 DO
    BEGIN    E:=0;R:=0;
    S:=MEMO1.Lines.Strings[I];
    IF POS(',',S)>0     THEN
       R:=STRTOFLOAT(S) ELSE
       E:=STRTOINT(S);
    D:=D+E+R;
    end;    SHOWMESSAGE(FLOATTOSTR(D));
end;

end.
