unit Unit3;
{$mode ObjFPC}{$H+}
interface
uses
  Classes, SysUtils, Forms, Controls, Graphics,
  Dialogs, ExtCtrls, StdCtrls, ActnList,TAGraph, TASeries;
type
  { TForm3 }
how_then=record
    nam:string;
    value:real;
    procent:real;
    end;
one_then=record
    one: array of how_then;
    max_value:real;
    prc_value:real;
    inn:string;
    adr:string;
    tel:string;
end;
  TForm3 = class(TForm)
    Chart1: TChart;
    ComboBox1: TComboBox;
   RadioGroup1: TRadioGroup;
    Chart1BarSeries1: TBarSeries;
    Chart1LineSeries1: TLineSeries;
    Button1: TButton; Panel1: TPanel;  Panel2: TPanel;
    procedure Button1Click(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure FormShow(Sender: TObject);
    procedure obr_one_firm(nomer,count:integer);
    procedure RadioGroup1Click(Sender: TObject);
  private
  public     proc, value: array of real;
    max_proc, max_value:real;
                   firm: array of one_then;
    n_firm,  count_firm:integer;
  end;
var          Form3: TForm3;
implementation
{$R *.lfm}
{ TForm3 }
procedure TForm3.obr_one_firm(nomer,count:integer);
var n,v,i:integer; r:real;
begin  if count<=0 then exit;
       if nomer<=0 then
          begin    n:=0;
          count_firm:=1; n_firm:=0;
          setlength(firm,n+1);
          end  else n:=nomer;   v:=count-1;
    setlength(firm[n].one,v+1);
    for i:=0 to v do  //--ищем наибольшую величину =100%
       begin                          r:=value[i];
                          firm[n].one[i].value:=r;
       if i=0 then        firm[n].max_value:=abs(r) else
       if                 firm[n].max_value< abs(r) then
                          firm[n].max_value:=abs(r); end;
       firm[n].prc_value:=firm[n].max_value/100;
        for i:=0 to v do
              begin  //-----преобразуем в  процент----
              r:=  firm[n].one[i].value;
              r:=r/firm[n].prc_value;
                   firm[n].one[i].procent:=r;
              end;
end;

procedure TForm3.RadioGroup1Click(Sender: TObject);
var i:integer;
begin    Chart1LineSeries1.Clear;
   if count_firm<=0 then exit;
  if  RadioGroup1.ItemIndex<0 then exit; // не указали вариант
   if RadioGroup1.ItemIndex=0 then
      for i:=0 to length(firm[n_firm].one)-1 do
          Chart1LineSeries1.AddXY(i,firm[n_firm].one[i].value);
   if RadioGroup1.ItemIndex=1 then
      for i:=0 to length(firm[n_firm].one)-1 do
          Chart1LineSeries1.AddXY(i,firm[n_firm].one[i].procent);
end;

procedure TForm3.FormCreate(Sender: TObject);
begin

end;

procedure TForm3.FormShow(Sender: TObject);
begin
  obr_one_firm(count_firm,length(value));
end;

procedure TForm3.Button1Click(Sender: TObject);
begin
   Chart1LineSeries1.Clear;
   Chart1barSeries1.Clear;
end;
end.
procedure TForm1.MenuItem4Click(Sender: TObject);
var v,i:integer; g,r:real;
 begin

     randomize;
     grf[id].Chart1LineSeries1.Clear();
     for i:=0 to length(grf[id].value)-1 do
     begin
     g:=grf[id].value[i];
        grf[id].Chart1LineSeries1.AddXY(i,g); //i*0.1,sin(random(4)*i*0.1));
     end;
     grf[id].Show;  //---показали-------
 end;
