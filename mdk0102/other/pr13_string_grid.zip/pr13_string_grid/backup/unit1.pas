unit Unit1;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, ExtCtrls, ComCtrls,
  Grids, StdCtrls, Menus, ValEdit, Buttons, CheckLst,Types; //  fpSpreadsheetCtrls,  fpSpreadsheetGrid, ;

type
tparametr=record
           param:string;
           value:real;
           nomer:integer;
         prosent:integer;
  end;
tfirm=record
         inn:string;
         adr:string;
        name:string;
     telefon:string;
         dat: array of tparametr;
       param: string;
       value: real;
end;


  { TForm1 }

  TForm1 = class(TForm)
    BitBtn1: TBitBtn;
    Button1: TButton;
    Button10: TButton;
    Button2: TButton;
    Button3: TButton;
    Button4: TButton;
    Button5: TButton;
    Button6: TButton;
    Button7: TButton;
    Button8: TButton;
    Button9: TButton;
    Edit1: TEdit;
    GroupBox1: TGroupBox;
    GroupBox2: TGroupBox;
    Label1: TLabel;
    Label2: TLabel;
    Label3: TLabel;
    Label4: TLabel;
    ListBox1: TListBox;
    MenuItem1: TMenuItem;
    MenuItem2: TMenuItem;
    PageControl1: TPageControl;
    Panel1: TPanel;
    Panel2: TPanel;
    Panel3: TPanel;
    PopupMenu1: TPopupMenu;
    StringGrid1: TStringGrid;
    StringGrid2: TStringGrid;
    TabSheet1: TTabSheet;
    TabSheet2: TTabSheet;
    TabSheet3: TTabSheet;
    procedure BitBtn1Click(Sender: TObject);
    procedure Button10Click(Sender: TObject);

    procedure Button1Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure Button3Click(Sender: TObject);
    procedure Button4Click(Sender: TObject);
    procedure Button5Click(Sender: TObject);
    procedure Button6Click(Sender: TObject);
    procedure Button7Click(Sender: TObject);
    procedure Button8Click(Sender: TObject);



    procedure Edit1EditingDone(Sender: TObject);

    procedure FormCreate(Sender: TObject);

    procedure ListBox1Click(Sender: TObject);
    procedure ListBox1DblClick(Sender: TObject);
    procedure MenuItem1Click(Sender: TObject);
    procedure MenuItem2Click(Sender: TObject);
    procedure PageControl1Change(Sender: TObject);

    procedure StringGrid2DrawCell(Sender: TObject; aCol, aRow: Integer;
      aRect: TRect; aState: TGridDrawState);
    procedure StringGrid2Selection(Sender: TObject; aCol, aRow: Integer);

  private
  idx:integer;
  public
    spisok: array of real;
  end;

var
  Form1: TForm1;

implementation

{$R *.lfm}

{ TForm1 }

procedure TForm1.FormCreate(Sender: TObject);
begin
  StringGrid1.Cells[0,0]:='№';
  StringGrid1.Cells[1,0]:='ИНН';
  StringGrid1.Cells[2,0]:='Название';
  StringGrid1.Cells[3,0]:='адрес';
  StringGrid1.Cells[4,0]:='телефон';
end;


procedure TForm1.ListBox1Click(Sender: TObject);
begin                           if listbox1.ItemIndex<0 then exit;
edit1.text:=listbox1.Items.Strings[listbox1.itemindex];
end;

procedure TForm1.ListBox1DblClick(Sender: TObject);
begin         if listbox1.ItemIndex<0 then exit; // не на позиции
  edit1.Text:=listbox1.Items.Strings[listbox1.ItemIndex];
end;


procedure TForm1.Button1Click(Sender: TObject);
begin    listbox1.Items.SaveToFile('list1.xtx');
end;


procedure TForm1.BitBtn1Click(Sender: TObject);
var i,e:integer;
begin
 IF  stringgrid2.ColCount< LISTBOX1.Count tHEN
     stringgrid2.ColCount:=LISTBOX1.Count+1;
 IF  stringgrid2.ROWCount= 0 tHEN
     stringgrid2.ROWCount:=1;
 for i:=0 to listbox1.Count-1 do
    begin stringgrid2.Cells[i+1,0]:= 'фактор-'+inttostr(i);
    end;  stringgrid2.Cells[0,  0]:='ИНН'; e:=0;
 ///-------------------------------------------
 IF  stringgrid2.rowCount< stringgrid1.rowCount tHEN
     stringgrid2.rowCount:=stringgrid1.rowcount+1;
 for i:=0 to listbox1.Count-1 do
    begin stringgrid2.Cells[0,i+1]:= stringgrid1.Cells[1,i+1];
    if  length(stringgrid1.Cells[1,i+1])>0 then inc(e); end;
               stringgrid2.RowCount:=e+1;

end;

procedure TForm1.Button10Click(Sender: TObject);
var z,i:integer;
begin   z:=-1;
  for i:=1  to stringgrid1.rowcount-1 do
      if z<0 then  if stringgrid1.Cells[1,i]='' then z:=i;
      if z>0 then     stringgrid1.RowCount:=z;
      if z>0 then     stringgrid2.RowCount:=z;
                      stringgrid2.colCount:=listbox1.Items.Count+1;
      for i:=1  to stringgrid1.rowcount-1 do
                   stringgrid2.Cells[0,i]:=stringgrid1.Cells[1,i];
      for i:=0  to listbox1.count-1 do
                   stringgrid2.Cells[i+1,0]:=listbox1.Items.Strings[i];
                   stringgrid2.Cells[0,0]:='INN'
end;

procedure TForm1.Button2Click(Sender: TObject);
begin   listbox1.Items.loadfromFile('list1.xtx');
end;

procedure TForm1.Button3Click(Sender: TObject);
begin   ListBox1.items.Clear;
end;

procedure TForm1.Button4Click(Sender: TObject);
begin
stringGrid1.rowcount:=stringGrid1.rowCount+1;
stringGrid1.Cells[0,stringGrid1.rowcount-1]:=
        inttostr(stringGrid1.rowCount-1);
end;

procedure TForm1.Button5Click(Sender: TObject);
begin
   if   (stringGrid1.RowCount)>1 then
         stringGrid1.rowCount:=stringGrid1.rowCount-1;
end;
/////////////      ////////////////
procedure TForm1.Button6Click(Sender: TObject);
begin
  showmessage('стереть'); exit;
  stringGrid1.RowCount:=1;
end;
//////////////   ////////////////
procedure TForm1.Button7Click(Sender: TObject);
begin  stringgrid1.savetofile('stringgrid1.txt');
end;
////////////////////////  ///////////////////
procedure TForm1.Button8Click(Sender: TObject);
Var Info : TSearchRec;         s:string;
begin  stringgrid1.RowCount:=20;
 s:=ExtractFilePath(ParamStr(0))+'stringgrid1.txt';
   if findfirst(s, faAnyFile, Info )=0 then else
    begin showmessage('file not find '); exit; end;
  stringgrid1.LoadFromFile('stringgrid1.txt');
end;


procedure TForm1.Edit1EditingDone(Sender: TObject);
begin
 if listbox1.ItemIndex<0 then exit; // не на позиции
    listbox1.Items.Strings[listbox1.ItemIndex]:=edit1.Text;
    listbox1.SetFocus;
end;

procedure TForm1.MenuItem1Click(Sender: TObject);
begin  ListBox1.Items.Add('?');
end;

procedure TForm1.MenuItem2Click(Sender: TObject);
begin
 if  ListBox1.ItemIndex>=0 then
     ListBox1.Items.Delete(ListBox1.ItemIndex);
end;

procedure TForm1.PageControl1Change(Sender: TObject);
begin

end;


procedure TForm1.StringGrid2DrawCell(Sender: TObject; aCol, aRow: Integer;
  aRect: TRect; aState: TGridDrawState);
begin
 IF ACOL=4 THEN BEGIN
  StringGrid2.Canvas.Brush.Color := CLGREEN; // назначение цвета ячейки
  StringGrid2.Canvas.FillRect(ARect); // закрашивание ячейки выбранным цветом
  StringGrid2.Canvas.Font.Color := clWhite; // назначение цвета шрифта
  StringGrid2.Canvas.TextOut(ARect.Left, ARect.Top, StringGrid2.Cells[ACol, ARow]);
   end;
  IF AROW=3 THEN BEGIN
  StringGrid2.Canvas.Brush.Color := CLBLUE; // назначение цвета ячейки
  StringGrid2.Canvas.FillRect(ARect); // закрашивание ячейки выбранным цветом
  StringGrid2.Canvas.Font.Color := clWhite; // назначение цвета шрифта
  StringGrid2.Canvas.TextOut(ARect.Left, ARect.Top, StringGrid2.Cells[ACol, ARow]);
   end;
end;

procedure TForm1.StringGrid2Selection(Sender: TObject; aCol, aRow: Integer);
var e,i:integer;
begin  e:=0;
   if stringgrid2.Cells[0,arow]='' then exit;
  label3.caption:=listbox1.Items.Strings[acol-1];
  for i:=1 to stringgrid2.RowCount-1 do
      if pos(stringgrid1.Cells[1,i],stringgrid2.Cells[0,arow])>0 then
          e:=i;
  if e=0 then    label2.Caption:='not found' else
                 label2.Caption:=stringgrid1.Cells[2,e];
end;



end.

