unit Unit1;
{$mode objfpc}{$H+}
interface
uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, ExtCtrls, StdCtrls,
  ComCtrls;
type
  { TForm1 }
  TForm1 = class(TForm)
    Button1: TButton;     CheckBox1: TCheckBox;
    CheckBox10: TCheckBox;    CheckBox11: TCheckBox;
    CheckBox12: TCheckBox;    CheckBox13: TCheckBox;
    CheckBox14: TCheckBox;    CheckBox15: TCheckBox;
    CheckBox16: TCheckBox;    CheckBox17: TCheckBox;
    CheckBox18: TCheckBox;    CheckBox19: TCheckBox;
    CheckBox2: TCheckBox;     CheckBox20: TCheckBox;
    CheckBox21: TCheckBox;    CheckBox22: TCheckBox;
    CheckBox23: TCheckBox;    CheckBox3: TCheckBox;
    CheckBox4: TCheckBox;    CheckBox5: TCheckBox;
    CheckBox6: TCheckBox;     CheckBox7: TCheckBox;
    CheckBox8: TCheckBox;     CheckBox9: TCheckBox;
    Panel1: TPanel;    Panel10: TPanel;
    Panel11: TPanel;    Panel12: TPanel;
    Panel13: TPanel;    Panel14: TPanel;
    Panel15: TPanel;    Panel16: TPanel;
    Panel17: TPanel;    Panel18: TPanel;
 Panel2: TPanel;  Panel3: TPanel; Panel4: TPanel;
    Panel5: TPanel; Panel6: TPanel;  Panel7: TPanel;  Panel8: TPanel;
    Panel9: TPanel;
    ProgressBar1: TProgressBar;
    ProgressBar2: TProgressBar;
    ProgressBar3: TProgressBar;
    ProgressBar4: TProgressBar;
    ProgressBar5: TProgressBar;
    RadioGroup1: TRadioGroup;
    Timer1: TTimer;
    procedure CheckBox11Change(Sender: TObject);

    procedure RadioGroup1Click(Sender: TObject);
    procedure panel_default;
    procedure Timer1Timer(Sender: TObject);
  private
  public
  end;
var
  Form1: TForm1;
implementation
{$R *.lfm}
{ TForm1 }
procedure TForm1.RadioGroup1Click(Sender: TObject);
begin
panel5.Color:=cldefault; panel6.Color:=cldefault;
panel7.Color:=cldefault; panel8.Color:=cldefault; panel9.Color:=cldefault;
CASE RADIOGROUP1.ItemIndex OF
0:  BEGIN panel5.Color:=clGREEN; panel8.Color:=clLIME; END;
1:  BEGIN panel5.Color:=clGREEN; panel6.Color:=clLIME; END;
2:  BEGIN panel6.Color:=clGREEN; panel5.Color:=clLIME; END;
3:  BEGIN panel7.Color:=clGREEN; panel8.Color:=clLIME; END;
4:  BEGIN panel8.Color:=clGREEN; panel7.Color:=clLIME; END;
5:  BEGIN panel9.Color:=clGREEN; panel5.Color:=clLIME; END;
6:  BEGIN panel6.Color:=clGREEN; panel9.Color:=clLIME; END;
end;
end;
procedure tform1.panel_default;
begin
Panel11.Color:=clMenu; Panel12.Color:=clMenu; panel13.Color:=clMenu;
panel14.Color:=clMenu; panel15.Color:=clMenu; panel16.Color:=clMenu;
panel17.Color:=clMenu; panel18.Color:=clMenu;
end;

procedure TForm1.Timer1Timer(Sender: TObject);
var value:integer;
begin  value:=0;
   if   progressBar1.Position<progressBar1.Max then
   if CheckBox1.Checked then  progressBar1.Position:= progressBar1.Position+1;
   if   progressBar1.Position>progressBar1.Min then
   if CheckBox6.Checked then   begin progressBar1.Position:= progressBar1.Position-1; inc(value); end;
   if   progressBar2.Position<progressBar2.Max then
   if CheckBox2.Checked then  progressBar2.Position:= progressBar2.Position+1;
   if   progressBar2.Position>progressBar2.Min then
   if CheckBox7.Checked then begin progressBar2.Position:= progressBar2.Position-1; inc(value); end;
   if   progressBar3.Position<progressBar3.Max then
   if CheckBox3.Checked then  progressBar3.Position:= progressBar3.Position+1;
   if   progressBar3.Position>progressBar3.Min then
   if CheckBox8.Checked then   begin progressBar3.Position:= progressBar3.Position-1; inc(value); end;
   if   progressBar4.Position<progressBar4.Max then
   if CheckBox4.Checked then  progressBar4.Position:= progressBar4.Position+1;
   if   progressBar4.Position>progressBar4.Min then
   if CheckBox9.Checked then begin progressBar4.Position:= progressBar4.Position-1; inc(value); end;
   if   progressBar5.Position<progressBar5.Max then
   if CheckBox5.Checked then  progressBar5.Position:= progressBar5.Position+1;
   if   progressBar5.Position>progressBar5.Min then
   if CheckBox10.Checked then begin progressBar5.Position:= progressBar5.Position-1; inc(value); end;
  if CheckBox16.Checked then
  begin panel11.Tag:=panel11.Tag+value; panel11.caption:=inttostr(panel11.Tag);end else
  if CheckBox17.Checked then
  begin panel18.Tag:=panel18.Tag+value; panel18.caption:=inttostr(panel18.Tag);end else
  if CheckBox18.Checked then
  begin panel17.Tag:=panel17.Tag+value; panel17.caption:=inttostr(panel17.Tag);end else
  if CheckBox19.Checked then
  begin panel16.Tag:=panel16.Tag+value; panel16.caption:=inttostr(panel16.Tag);end else
  if CheckBox20.Checked then
  begin panel15.Tag:=panel15.Tag+value; panel15.caption:=inttostr(panel15.Tag);end else
  if CheckBox21.Checked then
  begin panel14.Tag:=panel14.Tag+value; panel14.caption:=inttostr(panel14.Tag);end else
  if CheckBox22.Checked then
  begin panel13.Tag:=panel13.Tag+value; panel13.caption:=inttostr(panel13.Tag);end else
  if CheckBox23.Checked then
  begin panel12.Tag:=panel12.Tag+value; panel12.caption:=inttostr(panel12.Tag);end ;
end  ;



procedure TForm1.CheckBox11Change(Sender: TObject);
begin  panel_default;
   if CheckBox11.Checked then
   if CheckBox13.Checked then begin Panel16.Color:=clLIME; exit; end;
   if CheckBox11.Checked then
   if CheckBox12.Checked then begin Panel12.Color:=claqua; exit; end;
   if CheckBox13.Checked then
   if CheckBox12.Checked then begin Panel12.Color:=claqua; exit; end;
   if CheckBox14.Checked then
   if CheckBox12.Checked then begin Panel12.Color:=claqua; exit; end;
   if CheckBox15.Checked then
   if CheckBox12.Checked then begin Panel12.Color:=claqua; exit; end;
   if CheckBox11.Checked then Panel11.Color:=claqua;
   if CheckBox12.Checked then Panel12.Color:=claqua;
   if CheckBox13.Checked then Panel13.Color:=claqua;
   if CheckBox14.Checked then Panel14.Color:=claqua;
   if CheckBox15.Checked then Panel15.Color:=claqua;

end;

end.
