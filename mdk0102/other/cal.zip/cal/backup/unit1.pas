unit Unit1;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls, ExtCtrls,
  Menus;

type

  { TForm1 }

  TForm1 = class(TForm)
    Button1: TButton;
    Button10: TButton;
    Button11: TButton;
    Button12: TButton;
    Button13: TButton;
    Button14: TButton;
    Button15: TButton;
    Button16: TButton;
    Button17: TButton;
    Button18: TButton;
    Button2: TButton;
    Button3: TButton;
    Button4: TButton;
    Button5: TButton;
    Button6: TButton;
    Button7: TButton;
    Button8: TButton;
    Button9: TButton;
    ControlBar1: TControlBar;
    Edit1: TEdit;
    Edit2: TEdit;
    Edit3: TEdit;
    Panel1: TPanel;
    procedure Button11Click(Sender: TObject);
    procedure Button12Click(Sender: TObject);
    procedure Button15Click(Sender: TObject);
    procedure Button10Click(Sender: TObject);
    procedure Button13Click(Sender: TObject);
    procedure Button14Click(Sender: TObject);
    procedure Button16Click(Sender: TObject);
    procedure Button19Click(Sender: TObject);
    procedure Button1Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure Button3Click(Sender: TObject);
    procedure Button4Click(Sender: TObject);
    procedure Button5Click(Sender: TObject);
    procedure Button6Click(Sender: TObject);
    procedure Button7Click(Sender: TObject);
    procedure Button8Click(Sender: TObject);
    procedure Button9Click(Sender: TObject);
    procedure Button0Click(Sender: TObject);
    procedure Button17Click(Sender: TObject);
    procedure ControlBar1Click(Sender: TObject);
    procedure Edit1Change(Sender: TObject);
    procedure Edit2Change(Sender: TObject);
    procedure Edit3Change(Sender: TObject);
  private

  public

  end;

var
  Form1: TForm1;

  z:string;
  x:string;
  y:string;
  k:string;
  zpt1,zpt2:string;

implementation

{$R *.lfm}

{ TForm1 }
function add_char(s:string; c:char):string;
begin     k:='';
if length(s)<9 then
         s:=s+c
   else    MessageDlg ('внимание', 'переполнение!', mtConfirmation,
                  [ mbok],0);
  add_char:=s;
end;
procedure TForm1.Button15Click(Sender: TObject);
var f:string;
begin
if panel1.Caption='?' then
   BEGIN
   f:=copy(edit1.Text,1,Length(edit1.Text)) ;
   if length(f)>0 then
   if length(zpt1)<1 then
      begin Edit1.Text:=add_char(Edit1.Text,',');
              zpt1:=',';
      end
      else    MessageDlg ('внимание', 'дробная введена', mtConfirmation,
                  [ mbok],0);
   END ELSE
   BEGIN
   f:=copy(edit2.Text,1,Length(edit2.Text)) ;
   if length(f)>0 then
   if length(zpt2)<1 then
      begin Edit2.Text:=add_char(Edit2.Text,',');
              zpt2:=',';
      end
      else    MessageDlg ('внимание', 'дробная введена', mtConfirmation,
                  [ mbok],0);
   END;

end;

procedure TForm1.Button12Click(Sender: TObject);
begin
 panel1.Caption:='?';
  edit1.Text:=''; zpt1:='';
  edit2.Text:=''; zpt2:='';     edit3.text:='';
end;

procedure TForm1.Button11Click(Sender: TObject);
var f:string;
begin
if panel1.Caption='?' then
  BEGIN
  f:=copy(edit1.Text,1,Length(edit1.Text)) ;
  if length(f)>1 then
      Delete(f, Length(edit1.Text) - 1, 1)
               else BEGIN  f:='';
                  PANEL1.Caption:='?';
               end;
   edit1.Text:=f;
   IF Pos(',', F)=0 THEN ZPT1:='';
  end ELSE
  BEGIN
    f:=copy(edit2.Text,1,Length(edit2.Text)) ;
    if length(f)>1 then
        Delete(f, Length(edit2.Text) - 1, 1)
                 else BEGIN  f:='';
                     end;
     edit2.Text:=f;
     IF Pos(',', F)=0 THEN ZPT2:='';
  end;

end;

procedure TForm1.Button17Click(Sender: TObject);
var f:string;
begin
f:=copy(edit1.Text,1,Length(edit1.Text)) ;
if length(f)>0 then
    Panel1.Caption:='/';
IF length(zpt1)>0 then edit1.text:=edit1.text+'0';
end;

procedure TForm1.ControlBar1Click(Sender: TObject);
begin

end;

procedure TForm1.Edit1Change(Sender: TObject);
begin

end;

procedure TForm1.Edit2Change(Sender: TObject);
begin

end;

procedure TForm1.Edit3Change(Sender: TObject);
begin

end;

procedure TForm1.Button3Click(Sender: TObject);

begin   if panel1.Caption='?' then
       Edit1.Text:=add_char(Edit1.Text,'3')
else   Edit2.Text:=add_char(Edit2.Text,'3');
end;

procedure TForm1.Button4Click(Sender: TObject);
begin   if panel1.Caption='?' then
      Edit1.Text:=add_char(Edit1.Text,'4')
else  Edit2.Text:=add_char(Edit2.Text,'4')
end;

procedure TForm1.Button5Click(Sender: TObject);
begin  if panel1.Caption='?' then
      Edit1.Text:=add_char(Edit1.Text,'5')
else  Edit2.Text:=add_char(Edit2.Text,'5')
end;

procedure TForm1.Button6Click(Sender: TObject);
begin  if panel1.Caption='?' then
      Edit1.Text:=add_char(Edit1.Text,'6')
else  Edit2.Text:=add_char(Edit2.Text,'6');
end;

procedure TForm1.Button7Click(Sender: TObject);
begin
if panel1.Caption='?' then
   Edit1.Text:=add_char(Edit1.Text,'7')
   else
   Edit2.Text:=add_char(Edit2.Text,'7')
end;

procedure TForm1.Button8Click(Sender: TObject);
begin   if panel1.Caption='?' then
      Edit1.Text:=add_char(Edit1.Text,'8')
else  Edit2.Text:=add_char(Edit2.Text,'8');
end;

procedure TForm1.Button9Click(Sender: TObject);
begin   if panel1.Caption='?' then
      Edit1.Text:=add_char(Edit1.Text,'9')
else  Edit2.Text:=add_char(Edit2.Text,'9');
end;

procedure TForm1.Button1Click(Sender: TObject);
begin   if panel1.Caption='?' then
      Edit1.Text:=add_char(Edit1.Text,'1')
else  Edit2.Text:=add_char(Edit2.Text,'1');
end;


procedure TForm1.Button10Click(Sender: TObject);
var x,y,z:  Double ;
    oper:string;
begin
if length(edit1.text)<1 then exit;
if length(edit2.text)<1 then exit;

  IF length(zpt2)>0 then edit2.text:=edit2.text+'0';
          x:=strtofloat(edit1.text);
          y:=strtofloat(edit2.text);
       oper:=panel1.Caption;
  case oper of
  '+':begin z:=x+y;  end;
  '-':begin z:=x-y;  end;
  '*':begin z:=x*y;  end;
  '/':begin z:=x/y;  end;
  end;
  edit3.text:=floattostr(z);
end;

procedure TForm1.Button13Click(Sender: TObject);
var f:string;
begin
f:=copy(edit1.Text,1,Length(edit1.Text)) ;
if length(f)>0 then
    Panel1.Caption:='+';
IF length(zpt1)>0 then edit1.text:=edit1.text+'0';

end;

procedure TForm1.Button14Click(Sender: TObject);
var f:striNg;
begin
f:=copy(edit1.Text,1,Length(edit1.Text)) ;
if length(f)>0 then
    Panel1.Caption:='-';
IF length(zpt1)>0 then edit1.text:=edit1.text+'0';
end;

procedure TForm1.Button16Click(Sender: TObject);
var f:string;
begin
f:=copy(edit1.Text,1,Length(edit1.Text)) ;
if length(f)>0 then
    Panel1.Caption:='*';
IF length(zpt1)>0 then edit1.text:=edit1.text+'0';
end;

procedure TForm1.Button19Click(Sender: TObject);
begin

end;

procedure TForm1.Button2Click(Sender: TObject);
begin  if panel1.Caption='?' then
     Edit1.Text:=add_char(Edit1.Text,'2')
else Edit2.Text:=add_char(Edit2.Text,'2');
end;
procedure TForm1.Button0Click(Sender: TObject);
begin     if panel1.Caption='?' then
      Edit1.Text:=add_char(Edit1.Text,'0')
else  Edit2.Text:=add_char(Edit2.Text,'0');
end;

end.

