unit Unit1;
{$mode objfpc}{$H+}
interface
uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, ExtCtrls, StdCtrls,
  Grids, Buttons, Menus, ValEdit, TAChartExtentLink, TASources,
  TAChartImageList, TAChartCombos, TAGraph, TASeries, unit4, Unit5  ;

  type
  { TForm1 }
  TForm1 = class(TForm)
    Button1: TButton;
    Button2: TButton;
    Button3: TButton;
    Button4: TButton;
    Button5: TButton;
    Button6: TButton;
    Button7: TButton;
    Chart1: TChart;
    Chart1LineSeries1: TLineSeries;
    Edit1: TEdit;
    MainMenu1: TMainMenu;
    Memo1: TMemo;
    MenuItem1: TMenuItem;
    MenuItem10: TMenuItem;
    MenuItem11: TMenuItem;
    MenuItem12: TMenuItem;
    MenuItem13: TMenuItem;
    MenuItem14: TMenuItem;
    MenuItem15: TMenuItem;
    Separator3: TMenuItem;
    MenuItem2: TMenuItem;
    MenuItem3: TMenuItem;
    MenuItem4: TMenuItem;
    MenuItem5: TMenuItem;
    MenuItem6: TMenuItem;
    MenuItem7: TMenuItem;
    MenuItem8: TMenuItem;
    MenuItem9: TMenuItem;
    PopupMenu2: TPopupMenu;
    Separator2: TMenuItem;
    OpenDialog1: TOpenDialog;
    Separator1: TMenuItem;
    Panel1: TPanel;
    PopupMenu1: TPopupMenu;
    SaveDialog1: TSaveDialog;
    StringGrid1: TStringGrid;
    procedure Button1Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure Button3Click(Sender: TObject);
    procedure Button4Click(Sender: TObject);
    procedure Button5Click(Sender: TObject);
    procedure Button6Click(Sender: TObject);
    procedure Button7Click(Sender: TObject);
    procedure Edit1EditingDone(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure FormShow(Sender: TObject);
    procedure Memo1Change(Sender: TObject);
    procedure MenuItem10Click(Sender: TObject);
    procedure MenuItem11Click(Sender: TObject);
    procedure MenuItem12Click(Sender: TObject);
    procedure MenuItem13Click(Sender: TObject);
    procedure MenuItem15Click(Sender: TObject);
    procedure MenuItem1Click(Sender: TObject);
    procedure MenuItem2Click(Sender: TObject);
    procedure MenuItem3Click(Sender: TObject);
    procedure MenuItem4Click(Sender: TObject);
    procedure MenuItem5Click(Sender: TObject);
    procedure MenuItem6Click(Sender: TObject);
    procedure MenuItem7Click(Sender: TObject);
    procedure MenuItem8Click(Sender: TObject);
    procedure MenuItem9Click(Sender: TObject);
    procedure StringGrid1EditingDone(Sender: TObject);
  private
    id:integer;
  public
  frm :array of tform3; //это массив форм   ДИНАМИЧЕСКИЙ
  end;

var
  Form1: TForm1;
implementation
{$R *.lfm}

function clear_str(s:string):string;
    var  d:string;      n:byte;
  begin  n:=1;      d:=s;
   while n<=length(d) do
      begin
      if d[n] in ['+','-','1','2','3','4','5','6','7','8','9','0','.',','] then
         begin
         if d[n]='.' then  d[n]:=',';
         if d[n]=',' then //-заменим на запятую точку
         if   n =1   then
             begin               d:='0'+d;
             if length(d)=2 then d:=d+'0';
             inc(n); continue;
             end else
          if   n =length(d)   then
              begin d:=d+'0';
              inc(n); continue;
              end ;

         if d[n]='-' then
         if   n >1   then
             begin  delete(d,n,1); continue; end;
         inc(n);  continue;
         end ;      delete(d,n,1);
      end;
  if length(d)<2 then       d:=d+'0';
     clear_str:=d;
 end;

{ TForm1 }
//--------------//----------------//-----------
procedure TForm1.Edit1EditingDone(Sender: TObject);
begin  edit1.text:=clear_str(Edit1.text);
        memo1.Lines.Add(edit1.text);
end;

procedure TForm1.FormCreate(Sender: TObject);
var x,y:integer;
begin
for X:=0 to form1.StringGrid1.ColCount-1 do
   for y:=1 to form1.StringGrid1.rowCount-1 do
   form1.StringGrid1.Cells[x,y]:=inttostr(-50+Random(101));
memo1.clear;
end;

procedure TForm1.FormShow(Sender: TObject);
begin

end;

procedure TForm1.Memo1Change(Sender: TObject);
begin

end;

procedure TForm1.MenuItem10Click(Sender: TObject);
var n,k,i:integer;
begin openDialog1.Filter:='Text files only|*.tab';;
      openDialog1.InitialDir:=GetCurrentDir+'\arhiv';
      openDialog1.FileName:='tab'; ///+timetostr(s);
      openDialog1.Execute;
      StringGrid1.ColCount:=1000;
      StringGrid1.rowCount:=1000;
   if openDialog1.FileName='' then  else
      StringGrid1.LoadFromFile(openDialog1.FileName);
       n:=-1;  k:=-1;
   for i:=0 to  StringGrid1.rowCount-1 do
      if length(StringGrid1.Cells[1,i])>0 then n:=i+1;
   for i:=0 to  StringGrid1.ColCount-1 do
      if length(StringGrid1.Cells[i,1])>0 then k:=i+1;
  if  k>0 then  StringGrid1.colCount:=k;
  if  n>0 then  StringGrid1.RowCount:=n;
end;

procedure TForm1.MenuItem11Click(Sender: TObject);
begin

end;
///////////   ///////////////
procedure TForm1.MenuItem12Click(Sender: TObject);
var i:integer; g,r:real;
begin
  if memo1.Lines.Count=0 then exit;

  if id<0 then id:=0 else  inc(id);    //указали позицию
  setlength(frm,id+1); // определили место  где создать форму
  Application.CreateForm(TForm3,frm[id]);  // создали форму
  frm[id].Memo1.Clear;

for i:=0 to  memo1.Lines.Count-1 do
   begin                       r:=abs(strtofloat(memo1.Lines.Strings[i]));
   if i=0 then frm[id].max_value:=r;
               frm[id].Memo1.Lines.Add(memo1.Lines.Strings[i]);
   if frm[id].max_value < r then frm[id].max_value := r;
   end;

   setlength(frm[id].value,memo1.Lines.Count);
             frm[id].max_proc:=frm[id].max_value/100;

   for i:=0 to memo1.Lines.Count-1 do
        begin  //-----преобразуем в  процент----
        g:=strtofloat(memo1.lines.Strings[i]);
        g:=g/frm[id].max_proc;
        frm[id].memo1.lines.Strings[i]:=floattostr(g);
        frm[id].value[i]:=g;
        end;
     randomize;
     frm[id].Chart1LineSeries1.Clear();
     for i:=1 to length(frm[id].value)-1 do
     begin
     g:=frm[id].value[i];
        frm[id].Chart1LineSeries1.AddXY(i,g); //i*0.1,sin(random(4)*i*0.1));
     end;

     frm[id].Show;  //---показали-------

end;
 //////////              /////////////////
procedure TForm1.MenuItem13Click(Sender: TObject);
 var srt: array of real;
       i:integer;
begin
   setlength(srt,memo1.Lines.Count);
 for i:=0 to length(srt)-1 do
      srt[i]:=strtofloat(memo1.Lines[i]);

     Chart1LineSeries1.Clear();
     for i:=1 to length(srt)-1 do
        begin
        Chart1LineSeries1.AddXY(i*0.1,srt[i]);//sin(random(4)*i*0.1));
        end;
end;
//////////////          //////////////////////
procedure TForm1.MenuItem15Click(Sender: TObject);
 var i:integer; g,r:real;
 begin


   if id<0 then id:=0 else  inc(id);    //указали позицию
   setlength(frm,id+1); // определили место  где создать форму
   Application.CreateForm(TForm3,frm[id]);  // создали форму
   frm[id].Memo1.Clear;
 for i:=1 to  stringgrid1.RowCount-1 do
    begin                       r:=abs(strtofloat(stringgrid1.Cells[stringgrid1.col,i]));
    if i=0 then frm[id].max_value:=r;
                frm[id].Memo1.Lines.Add(stringgrid1.Cells[stringgrid1.col,i]);
    if frm[id].max_value < r then frm[id].max_value := r;
    end;
    setlength(frm[id].value,frm[id].memo1.Lines.Count);
             frm[id].max_proc:=frm[id].max_value/100;
  for i:=0 to frm[id].memo1.Lines.Count-1 do
        begin  //-----преобразуем в  процент----
        g:=strtofloat(frm[id].memo1.lines.Strings[i]);
        g:=g/frm[id].max_proc;
        frm[id].memo1.lines.Strings[i]:=floattostr(g);
        frm[id].value[i]:=g;
        end;
     randomize;
     frm[id].Chart1LineSeries1.Clear();
     for i:=1 to length(frm[id].value) do
     begin
     g:=frm[id].value[i];
        frm[id].Chart1LineSeries1.AddXY(i,g); //i*0.1,sin(random(4)*i*0.1));
     end;
     frm[id].Show;  //---показали-------
 end;
 //////////////             /////////////////
procedure TForm1.MenuItem1Click(Sender: TObject);
begin
   StringGrid1.SortColRow(true, StringGrid1.Row);
end;
   /////////////           /////////////////////
procedure TForm1.MenuItem2Click(Sender: TObject);
begin
 StringGrid1.SortColRow(false, StringGrid1.Row);
end;
procedure SortStringGrid(var GenStrGrid: TStringGrid; ThatCol: Integer);
 const   TheSeparator = '@';   // Define the Separator
 var   CountItem, I, J, K, ThePosition: integer;
       MyList: TStringList;
       MyString, TempString: string;
 Begin    // Give the number of rows in the StringGrid
  CountItem := GenStrGrid.RowCount;
  MyList        := TStringList.Create;   //Create the List
   MyList.Sorted := False;
   try
     begin
       for I := 1 to (CountItem - 1) do
         MyList.Add(GenStrGrid.Rows[I].Strings[ThatCol] + TheSeparator +
           GenStrGrid.Rows[I].Text);
      Mylist.Sort;   //Sort the List

     for K := 1 to Mylist.Count do
     begin MyString := MyList.Strings[(K - 1)];
        ThePosition := Pos(TheSeparator, MyString);
         TempString := '';
         TempString := Copy(MyString, (ThePosition + 1), Length(MyString));
         MyList.Strings[(K - 1)] := '';
         MyList.Strings[(K - 1)] := TempString;
       end;
       for J := 1 to (CountItem - 1) do
         GenStrGrid.Rows[J].Text := MyList.Strings[(J - 1)];
     end;
   finally MyList.Free;
   end;
 end;
procedure TForm1.MenuItem3Click(Sender: TObject);
begin
   SortStringGrid(StringGrid1, StringGrid1.col);
end;
 ///////////////           //////////////////
procedure TForm1.MenuItem4Click(Sender: TObject);
begin

end;
///////////////         ////////////////////////
procedure TForm1.MenuItem5Click(Sender: TObject);
begin
   Srtgrd(StringGrid1, StringGrid1.col);
end;
   ////////////               ///////////////////
procedure TForm1.MenuItem6Click(Sender: TObject);
var i:integer;
begin
 for i:=1 to   StringGrid1.ColCount-1 do
       Srtgrd(StringGrid1,i);
end;
////////////////           ///////////////////
procedure TForm1.MenuItem7Click(Sender: TObject);
//var s:string;
begin SaveDialog1.Filter:='Text files only|*.txt';;
      SaveDialog1.InitialDir:=GetCurrentDir+'\arhiv';
      SaveDialog1.FileName:='exp'; ///+timetostr(s);
      SaveDialog1.Execute;
  if  SaveDialog1.FileName='' then  else
     if Memo1.Lines.Count=0  then  else
        Memo1.Lines.SaveToFile(SaveDialog1.FileName);
end;

procedure TForm1.MenuItem8Click(Sender: TObject);
begin     openDialog1.Filter:='Text files only|*.txt';;
      openDialog1.InitialDir:=GetCurrentDir+'\arhiv';
      openDialog1.FileName:='exp'; ///+timetostr(s);
      openDialog1.Execute;
   if openDialog1.FileName='' then  else
      Memo1.Lines.loadfromFile(openDialog1.FileName);
end;

procedure TForm1.MenuItem9Click(Sender: TObject);
begin SaveDialog1.Filter:='Text files only|*.tab';;
      SaveDialog1.InitialDir:=GetCurrentDir+'\arhiv';
      SaveDialog1.FileName:='tab'; ///+timetostr(s);
      SaveDialog1.Execute;
  if  SaveDialog1.FileName='' then  else
     if StringGrid1.ColCount=0  then  else
       if StringGrid1.rowCount=0  then  else
          StringGrid1.SaveToFile(SaveDialog1.FileName);

end;

procedure TForm1.StringGrid1EditingDone(Sender: TObject);
var s:string;
begin
s:=StringGrid1.Cells[StringGrid1.col,StringGrid1.row];
   StringGrid1.Cells[StringGrid1.col,StringGrid1.row]:=clear_str(s);
end;

procedure TForm1.Button1Click(Sender: TObject);
var srt: array of real;
       i:integer;
begin
   setlength(srt,memo1.Lines.Count);
 for i:=0 to length(srt)-1 do
      srt[i]:=strtofloat(memo1.Lines[i]);
   BiDirBubbleSort(srt);  memo1.Lines.Clear;

   for i:=0 to length(srt)-1 do
    memo1.Lines.Add(floattostr(srt[i]));

    randomize;
     Chart1LineSeries1.Clear();
     for i:=1 to length(srt)-1 do
     begin
     Chart1LineSeries1.AddXY(i*0.1,srt[i]);//sin(random(4)*i*0.1));
     end;



end;

procedure TForm1.Button2Click(Sender: TObject);
VAR I:INTEGER;  S:STRING; D,R:REAL; E:INTEGER;
begin
 FOR I:=0 TO MEMO1.Lines.Count-1 DO
    BEGIN    E:=0;R:=0;
    S:=MEMO1.Lines.Strings[I];
    IF POS(',',S)>0     THEN
       R:=STRTOFLOAT(S) ELSE
       E:=STRTOINT(S);
    D:=D+E+R;
    end;    SHOWMESSAGE(FLOATTOSTR(D));
end;

procedure TForm1.Button3Click(Sender: TObject);
var x,y:integer;
begin
for X:=0 to form1.StringGrid1.ColCount-1 do
   for y:=1 to form1.StringGrid1.rowCount-1 do
   form1.StringGrid1.Cells[x,y]:=inttostr(-50+Random(101));
end;

procedure TForm1.Button4Click(Sender: TObject);
begin
    StringGrid1.ColCount:=StringGrid1.ColCount+1;
end;

procedure TForm1.Button5Click(Sender: TObject);
begin
   StringGrid1.ColCount:=StringGrid1.ColCount-1;
end;

procedure TForm1.Button6Click(Sender: TObject);
begin
      StringGrid1.rowCount:=StringGrid1.rowCount+1;
end;

procedure TForm1.Button7Click(Sender: TObject);
begin
    StringGrid1.rowCount:=StringGrid1.rowCount-1;
end;

end.
