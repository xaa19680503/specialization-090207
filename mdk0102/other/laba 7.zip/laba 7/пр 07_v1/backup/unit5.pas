unit Unit5;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, ComCtrls, StdCtrls,
  Spin, TAGraph, TASources, Types, TACustomSource, TADbSource,
  TATransformations, TANavigation, TAIntervalSources, TAChartExtentLink,
  TAChartLiveView, TASeries, TAMultiSeries;

type

  { TForm3 }

  TForm3 = class(TForm)
    Button1: TButton;
    Button2: TButton;
    Button3: TButton;
    Button4: TButton;
    Chart1: TChart;
    Chart1BarSeries1: TBarSeries;
    Chart1LineSeries1: TLineSeries;
    Chart1PieSeries1: TPieSeries;
    Memo1: TMemo;
    PageControl1: TPageControl;
    SpinEdit1: TSpinEdit;
    TabSheet1: TTabSheet;
    TabSheet2: TTabSheet;
    procedure Button1Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure Button3Click(Sender: TObject);
    procedure Button4Click(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure FormShow(Sender: TObject);
    function ListChartSource1Compare(AItem1, AItem2: Pointer): Integer;
    procedure PageControl1Change(Sender: TObject);
    procedure SpinEdit1Change(Sender: TObject);
    procedure TabSheet1ContextPopup(Sender: TObject; MousePos: TPoint;
      var Handled: Boolean);
    procedure TabSheet1Show(Sender: TObject);
  private

  public
    max_value:real;
    max_proc :real;
        value: array of real;
  end;

var
  Form3: TForm3;

implementation

{$R *.lfm}

{ TForm3 }

procedure TForm3.FormCreate(Sender: TObject);

begin

end;

procedure TForm3.FormShow(Sender: TObject);
var i:integer; g,r:real;
begin    exit;
      setlength(value,memo1.Lines.Count);
             max_proc:=max_value/100;

    for i:=0 to memo1.Lines.Count-1 do
         begin  //-----преобразуем в  процент----
         g:=strtofloat(memo1.lines.Strings[i]);
         g:=g/max_proc;
        memo1.lines.Strings[i]:=floattostr(g);
        value[i]:=g;
         end;
      randomize;
      Chart1LineSeries1.Clear();
      for i:=1 to length(value)-1 do
      begin
      g:=value[i];
         Chart1LineSeries1.AddXY(i,g); //i*0.1,sin(random(4)*i*0.1));
      end;
end;

procedure TForm3.Button1Click(Sender: TObject);
var i:integer; g:real;
begin

    for i:=1 to length(value) do
    begin
    g:=value[i];
    Chart1pieSeries1.AddXY(i,g); //i*0.1,sin(random(4)*i*0.1));
    end;
end;

procedure TForm3.Button2Click(Sender: TObject);
var i:integer; g:real;
begin
    for i:=1 to length(value) do
    begin
    g:=value[i];
    Chart1barSeries1.AddXY(i,g); //i*0.1,sin(random(4)*i*0.1));
    end;
end;

procedure TForm3.Button3Click(Sender: TObject);
begin
      Chart1LineSeries1.Clear();
    Chart1pieSeries1.Clear();
     Chart1BarSeries1.Clear();
                 Chart1.Depth :=0;
      Chart1LineSeries1.Depth :=0;
       Chart1pieSeries1.Depth :=0;
       Chart1barSeries1.Depth :=0;

end;

procedure TForm3.Button4Click(Sender: TObject);
var i:integer; g:real;
begin
    for i:=1 to length(value) do
    begin
    g:=value[i];
    Chart1lineSeries1.AddXY(i,g); //i*0.1,sin(random(4)*i*0.1));
    end;
end;

function TForm3.ListChartSource1Compare(AItem1, AItem2: Pointer): Integer;
begin

end;

////////////////////////////
procedure TForm3.PageControl1Change(Sender: TObject);
begin

end;

procedure TForm3.SpinEdit1Change(Sender: TObject);
var
  s: TLineSeries;
  d: TPieSeries;
begin            Chart1.Depth := SpinEdit1.Value;
      Chart1LineSeries1.Depth :=SpinEdit1.Value;
      Chart1pieSeries1.Depth :=SpinEdit1.Value;
      Chart1barSeries1.Depth :=SpinEdit1.Value;

end;

   //////////////////////////////
procedure TForm3.TabSheet1ContextPopup(Sender: TObject; MousePos: TPoint;
  var Handled: Boolean);
begin

end;

procedure TForm3.TabSheet1Show(Sender: TObject);

begin

end;

end.

