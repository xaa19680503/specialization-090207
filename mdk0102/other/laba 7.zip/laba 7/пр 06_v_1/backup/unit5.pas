unit Unit5;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, ComCtrls, StdCtrls,
  TAGraph, TASources, Types, TACustomSource, TADbSource, TATransformations,
  TANavigation, TAIntervalSources, TAChartExtentLink, TAChartLiveView, TASeries,
  TAMultiSeries;

type

  { TForm3 }

  TForm3 = class(TForm)
    Chart1: TChart;
    Chart1LineSeries1: TLineSeries;
    Memo1: TMemo;
    PageControl1: TPageControl;
    TabSheet1: TTabSheet;
    TabSheet2: TTabSheet;
    procedure FormCreate(Sender: TObject);
    function ListChartSource1Compare(AItem1, AItem2: Pointer): Integer;
    procedure PageControl1Change(Sender: TObject);
    procedure TabSheet1ContextPopup(Sender: TObject; MousePos: TPoint;
      var Handled: Boolean);
  private

  public
    max_value:real;
    max_proc :real;
        value: array of real;
  end;

var
  Form3: TForm3;

implementation

{$R *.lfm}

{ TForm3 }

procedure TForm3.FormCreate(Sender: TObject);

begin

end;

function TForm3.ListChartSource1Compare(AItem1, AItem2: Pointer): Integer;
begin

end;

////////////////////////////
procedure TForm3.PageControl1Change(Sender: TObject);
begin

end;
   //////////////////////////////
procedure TForm3.TabSheet1ContextPopup(Sender: TObject; MousePos: TPoint;
  var Handled: Boolean);
begin

end;

end.

