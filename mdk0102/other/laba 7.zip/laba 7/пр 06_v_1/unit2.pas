unit Unit2;

{$mode ObjFPC}{$H+}

interface



implementation

{$R *.lfm}

end.

