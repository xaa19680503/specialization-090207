unit Unit5;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls, TAGraph,
  TASeries;

type

  { TForm3 }

  TForm3 = class(TForm)
    Chart1: TChart;
    Chart1LineSeries1: TLineSeries;
    Memo1: TMemo;

  private

  public
       max_value:real;
    max_proc :real;
        value: array of real;
  end;

var
  Form3: TForm3;

implementation

{$R *.lfm}

{ TForm3 }

end.

