unit Unit1;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls, ExtCtrls,
  Spin, ComCtrls, EditBtn, TAGraph, TASeries, TAChartExtentLink, TAChartCombos,
  TAChartLiveView, TANavigation, TAStyles, TATools, TADbSource, ActnList,
  MaskEdit, ValEdit, TACustomSource, TASources, TAFuncSeries, TAChartListbox, Types;
type

  { TForm1 }

  TForm1 = class(TForm)
    Button1: TButton;
    Button2: TButton;
    Chart2: TChart;
    Chart2LineSeries1: TLineSeries;
    Chart2LineSeries2: TLineSeries;
    CheckBox1: TCheckBox;
    CheckBox2: TCheckBox;
    CheckBox3: TCheckBox;
    CheckBox4: TCheckBox;
    clear: TButton;
    Chart1: TChart;
    FloatSpinEdit1: TFloatSpinEdit;
    FloatSpinEdit2: TFloatSpinEdit;
    FloatSpinEdit3: TFloatSpinEdit;
    FloatSpinEdit4: TFloatSpinEdit;
    FloatSpinEdit5: TFloatSpinEdit;
    FloatSpinEdit6: TFloatSpinEdit;
    GroupBox1: TGroupBox;
    Image1: TImage;
    Label1: TLabel;
    Label2: TLabel;
    Label3: TLabel;
    Label4: TLabel;
    Label5: TLabel;
    Label6: TLabel;
    Label7: TLabel;
    Label8: TLabel;
    Label9: TLabel;
    PageControl1: TPageControl;
    Panel1: TPanel;
    Panel2: TPanel;
    Panel3: TPanel;
    ProgressBar1: TProgressBar;
    ProgressBar2: TProgressBar;
    ProgressBar3: TProgressBar;
    ProgressBar4: TProgressBar;
    SpinEdit1: TSpinEdit;
    SpinEdit2: TSpinEdit;
    TabSheet1: TTabSheet;
    TabSheet2: TTabSheet;
    TabSheet3: TTabSheet;
    Timer1: TTimer;
    procedure Button1Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure ChartListbox1Click(Sender: TObject);
    procedure CheckBox3Change(Sender: TObject);
    procedure clearClick(Sender: TObject);
    procedure DbChartSource1GetItem(ASender: TDbChartSource;
      var AItem: TChartDataItem);
    procedure FormCreate(Sender: TObject);
    procedure ProgressBar3ContextPopup(Sender: TObject; MousePos: TPoint;
      var Handled: Boolean);
    procedure Timer1Timer(Sender: TObject);
    procedure ValueListEditor1Click(Sender: TObject);

  private
    t_pila:integer;
      pila:array [1..100] of real;
  public

  end;

var
  Form1: TForm1;
implementation
{$R *.lfm}
{ TForm1 }
procedure TForm1.Button1Click(Sender: TObject);
var        s:TLineSeries;  i:integer;  r:TbarSeries;
   y,a,b,c,d,t,x:real;
begin if SpinEdit1.Value<=0 then exit;
        a:=floatspinedit3.Value;        b:=floatspinedit4.Value;
        c:=floatspinedit5.Value;        d:=floatspinedit6.Value;
   s:=TlineSeries.Create(Chart1);  // создали график.
   s.Depth:=4;
   x:= floatSpinEdit1.Value;
   t:=(floatSpinEdit2.Value-floatSpinEdit1.Value)/SpinEdit1.Value;
   s.SeriesColor:=clblue;          // графику цвет.
for i:=0 to SpinEdit1.Value  do
      begin  if i>0 then x:=x+t;
                  y:=x*x*x*a+x*x*b+x*c+d;
        S.AddXY(i,y);
      end;
Chart1.AddSeries(s);
end;

procedure TForm1.Button2Click(Sender: TObject);
  var        s:TLineSeries;  i:integer;  r:TbarSeries;
     y,a,b,c,d,t,x:real;
  begin if SpinEdit1.Value<=0 then exit;
          a:=floatspinedit3.Value;        b:=floatspinedit4.Value;
          c:=floatspinedit5.Value;        d:=floatspinedit6.Value;
     s:=TlineSeries.Create(Chart1);  // создали график.
     s.Depth:=5;
     x:= floatSpinEdit1.Value;
     t:=(floatSpinEdit2.Value-floatSpinEdit1.Value)/SpinEdit1.Value;
     s.SeriesColor:=clgreen;          // графику цвет.
  for i:=0 to SpinEdit1.Value  do
        begin  if i>0 then x:=x+t;
                    y:=sin(x);
          S.AddXY(i,y);
        end;
  Chart1.AddSeries(s);
  end;

procedure TForm1.ChartListbox1Click(Sender: TObject);
begin

end;

procedure TForm1.CheckBox3Change(Sender: TObject);
begin
end;

procedure TForm1.clearClick(Sender: TObject);
begin
  chart1.Series.Clear;
end;

procedure TForm1.DbChartSource1GetItem(ASender: TDbChartSource;
  var AItem: TChartDataItem);
begin

end;

procedure TForm1.FormCreate(Sender: TObject);
var i:integer;
begin
   for i:=0 to 201  do
      begin
       Chart2LineSeries2.add(0);
      end;     t_pila:=0;
end;

procedure TForm1.ProgressBar3ContextPopup(Sender: TObject; MousePos: TPoint;
  var Handled: Boolean);
begin

end;

/////////////////////////////////////////////////////////////
procedure TForm1.Timer1Timer(Sender: TObject);
var  i,p:integer;
begin
if    CheckBox3.Checked then   begin
      ProgressBar1.Position:=ProgressBar1.Position+1;
   p:=ProgressBar1.Position;
  if t_pila<100 then  Chart2LineSeries1.Add(ProgressBar1.Position);
  if T_pila<100 then               pila[p]:=ProgressBar1.Position;
  if T_pila=100 then
   begin  Chart2LineSeries1.Active:=false;
          Chart2LineSeries1.Clear;
   for i:=1 to 99 do begin
         pila[i  ]:=pila[i+1];
         Chart2LineSeries1.Add(pila[i]);
         end;  pila[100]:=p;
         Chart2LineSeries1.Active:=true;
   end;
   if ProgressBar1.Position =100 then
   if T_pila<100  then t_pila:=100;
   if ProgressBar1.Position =100 then ProgressBar1.Position:=0;
   end;
if    CheckBox1.Checked then begin// x  for sinus
      ProgressBar3.Position:=ProgressBar3.Position+1;
   if ProgressBar3.Position =360 then ProgressBar3.Position:=0; end;
if    CheckBox2.Checked then begin// x  for cosinys
      ProgressBar4.Position:=ProgressBar3.Position+1;
   if ProgressBar4.Position =360 then ProgressBar4.Position:=0; end;
if    CheckBox4.Checked then   begin
   if ProgressBar2.TAG=0 then   begin
   if ProgressBar2.Position <100 then
      ProgressBar2.Position:=ProgressBar2.Position+1 else
      ProgressBar2.TAG:=1;   end;
   if ProgressBar2.TAG=1 then   begin
   if ProgressBar2.Position >0 then
      ProgressBar2.Position:=ProgressBar2.Position-1 else
      ProgressBar2.TAG:=0;   end;
   end;
end;

procedure TForm1.ValueListEditor1Click(Sender: TObject);
begin

end;

end.

