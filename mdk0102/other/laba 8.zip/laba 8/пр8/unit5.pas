unit Unit5;
{$mode ObjFPC}{$H+}
interface
uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls, Spin, Menus,
  TAGraph, TASeries,  TAFuncSeries;
type
  { TForm3 }
  TForm3 = class(TForm)
    MenuItem1: TMenuItem;
    MenuItem2: TMenuItem;
    MenuItem3: TMenuItem;
    PopupMenu1: TPopupMenu;
    Button1: TButton;
    Button2: TButton;
    Button3: TButton;
    Button4: TButton;
    Chart1: TChart;
    Chart1BarSeries1: TBarSeries;
    Chart1LineSeries1: TLineSeries;
    Chart1PieSeries1: TPieSeries;
    Memo1: TMemo;
    SpinEdit1: TSpinEdit;
    procedure Button1Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure Button3Click(Sender: TObject);
    procedure Button4Click(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure MenuItem1Click(Sender: TObject);
    procedure MenuItem2Click(Sender: TObject);
    procedure MenuItem3Click(Sender: TObject);
    procedure SpinEdit1Change(Sender: TObject);
  private
  public
       max_value:real;
    max_proc :real;
        value: array of real;
  end;

var
  Form3: TForm3;

implementation

{$R *.lfm}

{ TForm3 }


procedure TForm3.Button1Click(Sender: TObject);

begin
    Chart1BarSeries1.Clear;
    Chart1LineSeries1.Clear;
    Chart1PieSeries1.Clear;

end;

procedure TForm3.Button2Click(Sender: TObject);
var i:integer; g:real;
begin
    for i:=1 to length(value) do
    begin
    g:=value[i];
    Chart1pieSeries1.AddXY(i,g);
    end;
end;

procedure TForm3.Button3Click(Sender: TObject);
var i:integer; g:real;
begin
    for i:=1 to length(value) do
    begin
    g:=value[i];
    Chart1lineSeries1.AddXY(i,g); //i*0.1,sin(random(4)*i*0.1));
    end;
end;

procedure TForm3.Button4Click(Sender: TObject);
var i:integer; g:real;
begin
    for i:=1 to length(value) do
    begin     g:=value[i];
    Chart1barSeries1.AddXY(i,g);
    end;
end;

procedure TForm3.FormCreate(Sender: TObject);
begin

end;

procedure TForm3.MenuItem1Click(Sender: TObject);
var    saveDialog1: tsaveDialog;
begin     savedialog1:=tsavedialog.Create(self);
  SaveDialog1.Filter:='Text files only|*.bmp';;
      SaveDialog1.InitialDir:=GetCurrentDir+'\bmp';
      SaveDialog1.FileName:='exp';
      SaveDialog1.Execute;
  if  SaveDialog1.FileName='' then  else
  Chart1.SaveToBitmapFile(SaveDialog1.FileName);
  SaveDialog1.Free;

  // Chart1.SaveToFile(TJPEGImage, GetFileName('jpg'));
  ///Chart1.SaveToFile(TPortableNetworkGraphic, GetFileName('png'));
end;

procedure TForm3.MenuItem2Click(Sender: TObject);
var    saveDialog1: tsaveDialog;
begin           showmessage( 'посморите в примерах'); exit;
      SaveDialog1.Filter:='Text files only|*.svg';;
      SaveDialog1.InitialDir:=GetCurrentDir+'\bmp';
      SaveDialog1.FileName:='exp';
      SaveDialog1.Execute;
  if  SaveDialog1.FileName='' then  else
 /// Chart1.SaveToSVGFile(GetFilename(SaveDialog1.FileName));
end;

procedure TForm3.MenuItem3Click(Sender: TObject);
begin
    Chart1.CopyToClipboardBitmap;
end;

procedure TForm3.SpinEdit1Change(Sender: TObject);
begin
  chart1.Depth:=SpinEdit1.value;
  Chart1barSeries1.Depth:=SpinEdit1.value;
  Chart1LineSeries1.Depth:=SpinEdit1.value;
  Chart1pieSeries1.Depth:=SpinEdit1.value;
end;

end.

