unit Unit1;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, ExtCtrls, ComCtrls,
  Grids, StdCtrls, Menus;

type

  { TForm1 }

  TForm1 = class(TForm)
    Button1: TButton;
    Button2: TButton;
    Button3: TButton;
    Edit1: TEdit;
    GroupBox1: TGroupBox;
    Label1: TLabel;
    ListBox1: TListBox;
    MenuItem1: TMenuItem;
    MenuItem2: TMenuItem;
    PageControl1: TPageControl;
    Panel1: TPanel;
    PopupMenu1: TPopupMenu;
    TabSheet1: TTabSheet;
    TabSheet2: TTabSheet;
    procedure Button1Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure Button3Click(Sender: TObject);
    procedure Edit1Enter(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure ListBox1Click(Sender: TObject);
    procedure ListBox1DblClick(Sender: TObject);
    procedure MenuItem1Click(Sender: TObject);
    procedure MenuItem2Click(Sender: TObject);
    procedure PageControl1Change(Sender: TObject);
  private

  public

  end;

var
  Form1: TForm1;

implementation

{$R *.lfm}

{ TForm1 }

procedure TForm1.FormCreate(Sender: TObject);
begin

end;

procedure TForm1.ListBox1Click(Sender: TObject);
begin
                               if listbox1.ItemIndex<0 then exit;
edit1.text:=listbox1.Items.Strings[listbox1.itemindex];

end;

procedure TForm1.ListBox1DblClick(Sender: TObject);
begin
           if listbox1.ItemIndex<0 then exit; // не на позиции
  edit1.Text:=listbox1.Items.Strings[listbox1.ItemIndex];
end;

procedure TForm1.Edit1Enter(Sender: TObject);
begin
 if listbox1.ItemIndex<0 then exit; // не на позиции
    listbox1.Items.Strings[listbox1.ItemIndex]:=edit1.Text;  // редактируем
end;

procedure TForm1.Button1Click(Sender: TObject);
begin
  listbox1.Items.SaveToFile('list1.xtx');
end;

procedure TForm1.Button2Click(Sender: TObject);
begin
 listbox1.Items.loadfromFile('list1.xtx');
end;

procedure TForm1.Button3Click(Sender: TObject);
begin
    ListBox1.items.Clear;
end;

procedure TForm1.MenuItem1Click(Sender: TObject);
begin
  ListBox1.Items.Add('?');
end;

procedure TForm1.MenuItem2Click(Sender: TObject);
begin
 if  ListBox1.ItemIndex>=0 then
    ListBox1.Items.Delete(ListBox1.ItemIndex);
end;

procedure TForm1.PageControl1Change(Sender: TObject);
begin


end;

end.

