unit Unit1;
{$mode objfpc}{$H+}
interface
uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls, Spin, Menus,
  ComCtrls, ExtCtrls, IdTCPClient, IdTCPServer, IdCustomTCPServer, IdContext ;

type
  { TForm1 }
  TForm1 = class(TForm)
    Button1: TButton;
    Button2: TButton;
    Button3: TButton;
    Button4: TButton;
    Button5: TButton;
    Edit1: TEdit;    Edit2: TEdit;    Edit3: TEdit;
    IdTCPServer1: TIdTCPServer;
    Label1: TLabel;
    MainMenu1: TMainMenu;
    Memo1: TMemo;     Memo2: TMemo;
    MenuItem1: TMenuItem;     MenuItem2: TMenuItem;
    MenuItem3: TMenuItem;
    MenuItem4: TMenuItem;
    MenuItem5: TMenuItem;
    MenuItem6: TMenuItem;
    MenuItem7: TMenuItem;
    MenuItem8: TMenuItem;
    PopupMenu1: TPopupMenu;
    ProgressBar1: TProgressBar;
    RadioGroup1: TRadioGroup;
    SpinEdit1: TSpinEdit;     SpinEdit2: TSpinEdit;
    TrackBar1: TTrackBar;
    procedure Button1Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure Button3Click(Sender: TObject);
    procedure Button4Click(Sender: TObject);
    procedure Button5Click(Sender: TObject);
    procedure Edit2Change(Sender: TObject);
    procedure FormActivate(Sender: TObject);
    procedure FormClose(Sender: TObject; var CloseAction: TCloseAction);
    procedure FormCreate(Sender: TObject);
    procedure IdTCPServer1Execute(AContext: TIdContext);
    procedure MenuItem2Click(Sender: TObject);
    procedure MenuItem3Click(Sender: TObject);
    procedure MenuItem4Click(Sender: TObject);
    procedure MenuItem5Click(Sender: TObject);
    procedure MenuItem6Click(Sender: TObject);
    procedure MenuItem7Click(Sender: TObject);
    procedure MenuItem8Click(Sender: TObject);
    procedure RadioGroup1ChangeBounds(Sender: TObject);
    procedure RadioGroup1Click(Sender: TObject);
    procedure RadioGroup1Enter(Sender: TObject);
    PROCEDURE  SendMessageToServer(const AServerIP: string; const Port: Integer;
      const INF: string);
    procedure SpinEdit1Change(Sender: TObject);
    procedure SpinEdit2Change(Sender: TObject);
    procedure TrackBar1Change(Sender: TObject);
    procedure TrackBar1EndDrag(Sender, Target: TObject; X, Y: Integer);
    procedure TrackBar1MouseUp(Sender: TObject; Button: TMouseButton;
      Shift: TShiftState; X, Y: Integer);
  private
  public
  end;

var  Form1: TForm1;

implementation
{$R *.lfm}

{ TForm1 }
 procedure TFORM1.SendMessageToServer(
   const AServerIP: string;
        const Port: Integer;
   const INF: string
   );
  VAR   TCPClient: TIdTCPClient;
    VAR
    S:STRING;
begin
  TCPClient := TIdTCPClient.Create(nil);
    TCPClient.Host := AServerIP;
    TCPClient.Port := Port;
    try
      TCPClient.Connect;     // Отправляем данные серверу через поток вывода
    TCPClient.IOHandler.WriteLn('HELL0! ->'+INF);
    MEMO1.Lines.Add('Сообщение получено сервером');
  finally
      TCPClient.Free;
  end;
end;

procedure TForm1.SpinEdit1Change(Sender: TObject);
begin

end;

procedure TForm1.SpinEdit2Change(Sender: TObject);
begin

end;

procedure TForm1.TrackBar1Change(Sender: TObject);
begin

end;

procedure TForm1.TrackBar1EndDrag(Sender, Target: TObject; X, Y: Integer);
begin
  SendMessageToServer(EDIT2.TEXT,
                  SPINEDIT2.Value,
                  '<trbk>'+inttostr(TrackBar1.Position)+ '/trbk>');
end;

procedure TForm1.TrackBar1MouseUp(Sender: TObject; Button: TMouseButton;
  Shift: TShiftState; X, Y: Integer);
begin
     SendMessageToServer(EDIT2.TEXT,
                  SPINEDIT2.Value,
                  '<trbk>'+inttostr(TrackBar1.Position)+ '/trbk>');
end;

procedure TForm1.IdTCPServer1Execute(AContext: TIdContext);
VAR S:STRING; i:integer;
begin     IF NOT IdTCPServer1.Active THEN EXIT;
      // Приняли соединение, обрабатываем запрос клиента
  IF  SIZEOF(AContext.Connection.IOHandler.InputBuffer)=0 THEN EXIT;
  IF NOT  AContext.Connection.Connected THEN EXIT;
     s:= (AContext.Connection.IOHandler.ReadLn);
  if S <>'' then
  begin
   AContext.Connection.IOHandler.Write('Получено! ->'+S);
   MEMO2.LINES.Add(S);
   if pos('ON',s)>0  then begin form1.Caption:='ON'; exit; end;
   if pos('OFF',s)>0 then begin form1.Caption:='OFF';exit; end;
   if pos('line',s)>0  then begin label1.Caption:='line'; exit; end;
   if pos('clear',s)>0 then begin label1.Caption:='clear';exit; end;
   if pos('save',s)>0  then begin memo1.Lines.SaveToFile('eee'); exit; end;
   if pos('load',s)>0 then begin memo1.Lines.loadfromFile('eee'); exit; end;
   if pos('out',s)>0  then begin memo1.Lines.SaveToFile('kkk'); exit; end;
   if pos('inp',s)>0 then begin memo1.Lines.loadfromFile('kkk'); exit; end;
   if pos('clr_m1',s)>0 then begin memo1.Lines.clear; exit; end;
   if pos('clr_m2',s)>0 then begin memo2.Lines.clear; exit; end;

if pos('frm0',s)>0 then begin form1.color:=clblue; exit;end;
if pos('frm1',s)>0 then begin form1.color:=clgreen; exit; end;
if pos('frm2',s)>0 then begin form1.color:=clred; exit; end;
if pos('frm3',s)>0 then begin form1.color:=cldefault;exit; end;

   if pos('edt0',s)>0 then begin edit3.color:=clblue; exit;end;
   if pos('edt1',s)>0 then begin edit3.color:=clgreen; exit; end;
   if pos('edt2',s)>0 then begin edit3.color:=clred; exit; end;
   if pos('edt3',s)>0 then begin edit3.color:=cldefault;exit; end;


   i:=pos('<trbk>',s);
   if i>0 then begin i:=i+6;
                     s:=copy(s,i,length(s)-i-5);
                     progressbar1.Position :=strtoint(s);
              // MEMO2.LINES.Add(S+'<----');
               end;
  end;
  SLEEP(400);
end;

procedure TForm1.MenuItem2Click(Sender: TObject);
begin
   MenuItem2.Checked:=  NOT MenuItem2.Checked;
IF MenuItem2.Checked THEN
   MenuItem2.Caption:='В НАСТРОЙКИ' ELSE
   MenuItem2.Caption:='В РАБОТУ';

    SPINEDIT1.Enabled:=MenuItem2.Checked;
        EDIT1.ENABLED:=MenuItem2.Checked;
    SPINEDIT2.ENABLED:=MenuItem2.Checked;
        EDIT2.ENABLED:=MenuItem2.Checked;
      Button1.ENABLED:=NOT MenuItem2.Checked;
  IdTCPServer1.Active:=NOT MenuItem2.Checked;

IF  IdTCPServer1.Active THEN  BEGIN
  IdTCPServer1.Active:=FALSE;
  IdTCPServer1.DefaultPort:=SPINEDIT1.Value;
  IdTCPServer1.Bindings.Items[0].IP:=EDIT1.Text;
  IdTCPServer1.Bindings.Items[0].Port:=SPINEDIT1.Value;
  SLEEP(600);
  IdTCPServer1.Active:=TRUE;
  END;

end;

procedure TForm1.MenuItem3Click(Sender: TObject);
begin
     SendMessageToServer(EDIT2.TEXT, SPINEDIT2.Value,'save');
end;

procedure TForm1.MenuItem4Click(Sender: TObject);
begin
    SendMessageToServer(EDIT2.TEXT, SPINEDIT2.Value,'load');
end;

procedure TForm1.MenuItem5Click(Sender: TObject);
begin
SendMessageToServer(EDIT2.TEXT, SPINEDIT2.Value,'line');
end;

procedure TForm1.MenuItem6Click(Sender: TObject);
begin
  SendMessageToServer(EDIT2.TEXT, SPINEDIT2.Value,'clear');
end;

procedure TForm1.MenuItem7Click(Sender: TObject);
begin
SendMessageToServer(EDIT2.TEXT, SPINEDIT2.Value,'out');
end;

procedure TForm1.MenuItem8Click(Sender: TObject);
begin
SendMessageToServer(EDIT2.TEXT, SPINEDIT2.Value,'inp');
end;

procedure TForm1.RadioGroup1ChangeBounds(Sender: TObject);
begin

end;

procedure TForm1.RadioGroup1Click(Sender: TObject);
begin
     SendMessageToServer(EDIT2.TEXT, SPINEDIT2.Value,'frm'+
     inttostr(radiogroup1.ItemIndex));

end;

procedure TForm1.RadioGroup1Enter(Sender: TObject);
begin

end;

procedure TForm1.FormActivate(Sender: TObject);
begin
IdTCPServer1.Active:=FALSE;   IdTCPServer1.DefaultPort:=SPINEDIT1.Value;
IdTCPServer1.Bindings.Clear;  IdTCPServer1.Bindings.Add;
IdTCPServer1.Bindings.Items[0].IP:=EDIT1.Text;
IdTCPServer1.DefaultPort:=SPINEDIT1.Value;
IdTCPServer1.Bindings.Items[0].Port:=SPINEDIT1.Value;
IdTCPServer1.Active:=TRUE;
end;

procedure TForm1.FormClose(Sender: TObject; var CloseAction: TCloseAction);
begin       SLEEP(100);
           IdTCPServer1.Active:=FALSE;
           IdTCPServer1.Free;
end;

procedure TForm1.FormCreate(Sender: TObject);
begin

end;

procedure TForm1.Button1Click(Sender: TObject);
begin
  SendMessageToServer(EDIT2.TEXT, SPINEDIT2.Value,EDIT3.TEXT);
end;

procedure TForm1.Button2Click(Sender: TObject);
begin
    SendMessageToServer(EDIT2.TEXT, SPINEDIT2.Value,'ON');
end;

procedure TForm1.Button3Click(Sender: TObject);
begin
    SendMessageToServer(EDIT2.TEXT, SPINEDIT2.Value,'OFF');
end;

procedure TForm1.Button4Click(Sender: TObject);
begin
   SendMessageToServer(EDIT2.TEXT, SPINEDIT2.Value,'clr_m1');
end;

procedure TForm1.Button5Click(Sender: TObject);
begin


end;

procedure TForm1.Edit2Change(Sender: TObject);
begin

end;



end.

