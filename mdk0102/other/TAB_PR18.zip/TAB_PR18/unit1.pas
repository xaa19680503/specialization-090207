unit Unit1;
{$mode objfpc}{$H+}
interface
uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls, vsHttpServer,
  ComObj, vsTypeDef, vsAuthentication, vsVisualSynapse;
type
  { TForm1 }
  TForm1 = class(TForm)
    Button1: TButton;
    Button2: TButton;
    Button3: TButton;
    vsHTTPServer1: TvsHTTPServer;
    procedure Button1Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure Button3Click(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure vsHTTPServer1Authenticate(Sender: TComponent; User, Pass: string;
      IPInfo: TIPInfo; var Authenticated: boolean);
  private
  public
  end;
var
  Form1: TForm1;
      XL: variant;
implementation
{$R *.lfm}
{ TForm1 }
procedure TForm1.Button1Click(Sender: TObject);
VAR J,I:INTEGER;
      N:CHAR;
begin  J:=1;
  XL := CreateOleObject('Excel.Application');   // Обьект EXCEL
  // Чтоб не задавал вопрос о сохранении документа
  XL.DisplayAlerts := false;
  XL.WorkBooks.Add;  // новый документ
  // Когда прога уже оттестирована лучше это делать в конце, быстрей работает,
  // а пока нет лучше в начале
  // Левое и правое поля отступа для печати
  XL.WorkBooks[1].WorkSheets[1].PageSetup.LeftMargin := 30;
  XL.WorkBooks[1].WorkSheets[1].PageSetup.RightMargin := 10;
  XL.WorkBooks[1].WorkSheets[1].Name := 'prais ';  // Даём название страничке
  XL.WorkBooks[1].WorkSheets[1].PageSetup.PrintTitleRows := '$3:$3';  // Строка появляется на каждом листе при печати
  XL.WorkBooks[1].WorkSheets[1].PageSetup.PrintTitleColumns := '$A:$A';

  for i := 4 to 13 do    // формат числа
    XL.WorkBooks[1].WorkSheets[1].Columns[i].NumberFormat := '0,00';
    XL.WorkBooks[1].WorkSheets[1].Columns[4].NumberFormat := '0,00';

  XL.WorkBooks[1].WorkSheets[1].Columns[1].ColumnWidth := 4.5;  // Таким способом можно задавать ширину колонки
  XL.WorkBooks[1].WorkSheets[1].Columns[2].ColumnWidth := 50;
  for i := 3 to 13 do
    XL.WorkBooks[1].WorkSheets[1].Columns[i].ColumnWidth := 8;

  XL.WorkBooks[1].WorkSheets[1].Rows[1].Font.Bold := True;  // Шрифт жирный
  XL.WorkBooks[1].WorkSheets[1].Rows[1].Font.Color := clBlack;
  XL.WorkBooks[1].WorkSheets[1].Rows[1].Font.Size := 16;
  XL.WorkBooks[1].WorkSheets[1].Rows[1].Font.Name := 'Times New Roman';
  XL.WorkBooks[1].WorkSheets[1].Cells[1, 4] := 'PRICE LIST';
  XL.WorkBooks[1].WorkSheets[1].Rows[1].VerticalAlignment := 2;  // Выравнивам по центру по вертикали
  XL.WorkBooks[1].WorkSheets[1].Rows[1].HorizontalAlignment := 3;  // Выравнивам по центру по горизонтали
  XL.WorkBooks[1].WorkSheets[1].Range['A1:D1'].Merge; // Обьединяем ячейки

  // Выравнивам по центру по вертикали
  XL.WorkBooks[1].WorkSheets[1].Rows[3].VerticalAlignment := 2;
  // Выравнивам по центру по горизонтали
  XL.WorkBooks[1].WorkSheets[1].Rows[3].HorizontalAlignment := 3;
  // Выравнивам по левому краю
  XL.WorkBooks[1].WorkSheets[1].Cells[3, 2].HorizontalAlignment := 2;
  XL.WorkBooks[1].WorkSheets[1].Cells[3, 3].HorizontalAlignment := 2;
  // Выравнивам по правому краю
  XL.WorkBooks[1].WorkSheets[1].Cells[3, 4].HorizontalAlignment := 4;
  XL.WorkBooks[1].WorkSheets[1].Rows[3].Font.Color := clBlack;
  XL.WorkBooks[1].WorkSheets[1].Rows[3].Font.Name := 'Times New Roman';
  XL.WorkBooks[1].WorkSheets[1].Rows[3].Font.Size := 12;
  XL.WorkBooks[1].WorkSheets[1].Rows[3].Font.Bold := True;
  XL.WorkBooks[1].WorkSheets[1].Cells[3, 1] := '№';
  XL.WorkBooks[1].WorkSheets[1].Cells[3, 2] := 'NAME';
  XL.WorkBooks[1].WorkSheets[1].Cells[3, 3] := 'ED. IZM.';

  // обрисовка диапазона ячеек только снизу
  // Borders[1] .... [4] - это края ячейки ColorIndex -4142 - пустой цвет i и n - переменные
  XL.WorkBooks[1].WorkSheets[1].Range['A' + IntToStr(i) + ':' + chr(ord('C') + 1)+ IntToStr(i)].Borders.LineStyle := 1;
  XL.WorkBooks[1].WorkSheets[1].Range['A' + IntToStr(i) + ':' + chr(ord('C') + 2)+ IntToStr(i)].Borders.Weight := 2;
  XL.WorkBooks[1].WorkSheets[1].Range['A' + IntToStr(i) + ':' + chr(ord('C') + 3)+ IntToStr(i)].Borders[4].ColorIndex := 1;
  XL.WorkBooks[1].WorkSheets[1].Range['A' + IntToStr(i) + ':' + chr(ord('C') + 4)+ IntToStr(i)].Borders[1].ColorIndex := -4142;
  XL.WorkBooks[1].WorkSheets[1].Range['A' + IntToStr(i) + ':' + chr(ord('C') + 5)+ IntToStr(i)].Borders[2].ColorIndex := -4142;
  XL.WorkBooks[1].WorkSheets[1].Range['A' + IntToStr(i) + ':' + chr(ord('C') + 6)+ IntToStr(i)].Borders[3].ColorIndex := -4142;

  // обрисовка диапазона ячеек
  XL.WorkBooks[1].WorkSheets[1].Range['A3:' + chr(ord('C') + 1) +IntToStr(i)].Borders.LineStyle := 1;
  XL.WorkBooks[1].WorkSheets[1].Range['A3:' + chr(ord('C') + 2) + IntToStr(i)].Borders.Weight := 2;
  XL.WorkBooks[1].WorkSheets[1].Range['A3:' + chr(ord('C') + 3) +IntToStr(i)].Borders.ColorIndex := 1;

  XL.WorkBooks[1].WorkSheets[1].Cells[i, 7] := 'COUNT';  // присвоение ячейке значения

  // Поворачивать слова, писать вертикально, под углом и т.д.

  XL.WorkBooks[1].WorkSheets[1].Rows[2].Orientation := 90;
  XL.WorkBooks[1].WorkSheets[1].Range['A2:B2'].Orientation := 0;
  XL.Visible := true;
end;
/////////////////////////////////////
procedure TForm1.Button2Click(Sender: TObject);
var  V: Variant;
   begin
     V := CreateOleObject('InternetExplorer.Application');
     V.Toolbar := FALSE;
     V.Left := (Screen.Width - 600) div 2;
     V.Width := 600;
     V.Top := (Screen.Height - 400) div 2;
     V.Height := 400;
     V.Visible := TRUE;
     V.Navigate(URL := 'file://C:\config.sys');
      V.StatusText := V.LocationURL;
     Sleep(10000);
     V.Quit;
end;
/////////////////////////////////////
type
   IIE = dispinterface
   ['{0002DF05-0000-0000-C000-000000000046}']
     property Visible: WordBool dispid 402;
 end;
      /////////////////////////////////////
procedure TForm1.Button3Click(Sender: TObject);
   VAR  II: IIE;
   begin
     II := CreateOleObject('InternetExplorer.Application') as IIE;
     II.Visible := TRUE;
end;
/////////////////////////////////////
procedure TForm1.FormCreate(Sender: TObject);
begin

end;
/////////////////////////////////////
procedure TForm1.vsHTTPServer1Authenticate(Sender: TComponent; User,
  Pass: string; IPInfo: TIPInfo; var Authenticated: boolean);
begin

end;


end.
      https://delphi-manual.ru/stringgrid-and-excel.php
Только имейте в виду, что таблица может содержать не только данные непосредственно в ячейках, но и формулы. При записи данных из нашей таблицы StringGrid всё, кроме непосредственно записываемого текста, будет уничтожено!
   Напоследок нужно заставить таблицу Excel сохранить обработанные данные:
Excel.ActiveWorkbook.SaveAs('Имя_Файла');//Или SaveAs('OpenDialog1.FileName');
   Можно вывести отчёт на печеть. Вот как задана функция печати:

function PrintOut(
   From: Variant;//Необязательно. Номер срааницы с которой начинается печать.
      To: Variant;//Необязательно. Номер страницы по какую продолжается печать.
  Copies: Variant;//Необязательно. Количество копий.
 Preview: Variant;//Необязательно. Предварительный просмотр (True или False).
    ActivePrinter: Variant;//Необязательно. Имя активного принтера.
      PrintToFile: Variant;//Необязательно. При значении True печать будет идти в файл.
          Collate: Variant//Необязательно. При значении True копии страниц объединяются.
                ): Workbook;
   Воспользоваться этой функцией можно как методом переменной, указывающей страницу - Sheet (также Excel.ActiveWorkBook или Excel.WorkSheets):
  Sheet.PrintOut(1, 1, 1, False, True)
