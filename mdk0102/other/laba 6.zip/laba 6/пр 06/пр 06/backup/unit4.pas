unit Unit4;

{$mode ObjFPC}{$H+}

interface

uses
  Controls, Graphics , ExtCtrls, StdCtrls  ,
  Classes, SysUtils,
 Math, Variants,Grids ;

        type srt_str=record
          d:real;
          s:string;
        end;

procedure BiDirBubbleSort(var data: array of real);
 procedure Srtgrd(var GenStrGrid: TStringGrid; Col: Integer);    overload;


implementation



   procedure BiDirBubbleSort(var data: array of real);
   {--------------------------------------------}
   {--- Сортировка двунаправленным пузырьком ---}
   {---    (вещественный массив типа real)   ---}
   {--------------------------------------------}
   var
     j,limit,st: integer;
     t: real;
     Swapped: Boolean;
   begin
     limit:=High(data)+1;
     st:=-1;
     while (st<limit) do
       begin
         inc(st);
         dec(limit);
         Swapped:=false;
         j:=st;
         while (j<limit) do
           begin
             if (data[j]>data[j+1]) then
               begin
                 t:=data[j];
                 data[j]:=data[j+1];
                 data[j+1]:=t;
                 Swapped:=true
               end;
             inc(j)
           end;
         if (not Swapped) then exit
           else Swapped:=false;
         j:=limit-1;
         repeat
           if (data[j]>data[j+1]) then
             begin
               t:=data[j];
               data[j]:=data[j+1];
               data[j+1]:=t;
               Swapped:=true
             end;
           dec(j)
         until (j<st);
         if (not Swapped) then exit;
       end
   end;

  procedure Srtgrd(var GenStrGrid: TStringGrid; Col: Integer); overload;
   var   CountItem, I : integer;
         s:string;
         d:array of real;
         f:array of srt_str;
    Begin               CountItem := GenStrGrid.RowCount;
            setlength(d,CountItem);
          for  I:= 1 to (CountItem - 1) do
             begin
             s:=GenStrGrid.Rows[I].Strings[Col];
              d[I]:=strtofloat(s);
             end;
          BiDirBubbleSort(d);
          for  I:= 1 to (CountItem - 1) do
             begin   s:=floattostr(d[i]);
             GenStrGrid.Rows[I].Strings[Col]:=s;
             end;
    end;


end.

