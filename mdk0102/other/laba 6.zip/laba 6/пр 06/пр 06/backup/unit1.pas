unit Unit1;
{$mode objfpc}{$H+}
interface
uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, ExtCtrls, StdCtrls,
  Grids, Buttons, Menus,unit4  ;

  type
  { TForm1 }
  TForm1 = class(TForm)
    Button1: TButton;
    Button2: TButton;
    Button3: TButton;
    Button4: TButton;
    Button5: TButton;
    Button6: TButton;
    Button7: TButton;
    Edit1: TEdit;
    MainMenu1: TMainMenu;
    Memo1: TMemo;
    MenuItem1: TMenuItem;
    MenuItem2: TMenuItem;
    MenuItem3: TMenuItem;
    MenuItem4: TMenuItem;
    MenuItem5: TMenuItem;
    MenuItem6: TMenuItem;
    Panel1: TPanel;
    PopupMenu1: TPopupMenu;
    StringGrid1: TStringGrid;
    procedure Button1Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure Button3Click(Sender: TObject);
    procedure Button4Click(Sender: TObject);
    procedure Button5Click(Sender: TObject);
    procedure Button6Click(Sender: TObject);
    procedure Button7Click(Sender: TObject);
    procedure Edit1EditingDone(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure MenuItem1Click(Sender: TObject);
    procedure MenuItem2Click(Sender: TObject);
    procedure MenuItem3Click(Sender: TObject);
    procedure MenuItem4Click(Sender: TObject);
    procedure MenuItem5Click(Sender: TObject);
    procedure MenuItem6Click(Sender: TObject);
    procedure StringGrid1EditingDone(Sender: TObject);
  private
  public
  end;

var
  Form1: TForm1;
implementation
{$R *.lfm}

function clear_str(s:string):string;
    var  d:string;      n:byte;
  begin  n:=1;      d:=s;
   while n<=length(d) do
      begin
      if d[n] in ['+','-','1','2','3','4','5','6','7','8','9','0','.',','] then
         begin
         if d[n]='.' then  d[n]:=',';
         if d[n]=',' then //-заменим на запятую точку
         if   n =1   then
             begin               d:='0'+d;
             if length(d)=2 then d:=d+'0';
             inc(n); continue;
             end else
          if   n =length(d)   then
              begin d:=d+'0';
              inc(n); continue;
              end ;

         if d[n]='-' then
         if   n >1   then
             begin  delete(d,n,1); continue; end;
         inc(n);  continue;
         end ;      delete(d,n,1);
      end;
  if length(d)<2 then       d:=d+'0';
     clear_str:=d;
 end;

{ TForm1 }
//--------------//----------------//-----------
procedure TForm1.Edit1EditingDone(Sender: TObject);
begin  edit1.text:=clear_str(Edit1.text);
        memo1.Lines.Add(edit1.text);
end;

procedure TForm1.FormCreate(Sender: TObject);
var x,y:integer;
begin
for X:=0 to form1.StringGrid1.ColCount-1 do
   for y:=1 to form1.StringGrid1.rowCount-1 do
   form1.StringGrid1.Cells[x,y]:=inttostr(-50+Random(101));
memo1.clear;
end;

procedure TForm1.MenuItem1Click(Sender: TObject);
begin
 StringGrid1.SortColRow(true, StringGrid1.Row);
end;

procedure TForm1.MenuItem2Click(Sender: TObject);
begin
 StringGrid1.SortColRow(false, StringGrid1.Row);
end;
procedure SortStringGrid(var GenStrGrid: TStringGrid; ThatCol: Integer);
 const   TheSeparator = '@';   // Define the Separator
 var   CountItem, I, J, K, ThePosition: integer;
       MyList: TStringList;
       MyString, TempString: string;
 Begin    // Give the number of rows in the StringGrid
  CountItem := GenStrGrid.RowCount;
  MyList        := TStringList.Create;   //Create the List
   MyList.Sorted := False;
   try
     begin
       for I := 1 to (CountItem - 1) do
         MyList.Add(GenStrGrid.Rows[I].Strings[ThatCol] + TheSeparator +
           GenStrGrid.Rows[I].Text);
      Mylist.Sort;   //Sort the List

     for K := 1 to Mylist.Count do
     begin MyString := MyList.Strings[(K - 1)];
        ThePosition := Pos(TheSeparator, MyString);
         TempString := '';
         TempString := Copy(MyString, (ThePosition + 1), Length(MyString));
         MyList.Strings[(K - 1)] := '';
         MyList.Strings[(K - 1)] := TempString;
       end;
       for J := 1 to (CountItem - 1) do
         GenStrGrid.Rows[J].Text := MyList.Strings[(J - 1)];
     end;
   finally MyList.Free;
   end;
 end;
procedure TForm1.MenuItem3Click(Sender: TObject);
begin

end;

procedure TForm1.MenuItem4Click(Sender: TObject);
begin

end;

procedure TForm1.MenuItem5Click(Sender: TObject);
begin
   Srtgrd(StringGrid1, StringGrid1.col);
end;

procedure TForm1.MenuItem6Click(Sender: TObject);
var i:integer;
begin
 for i:=1 to   StringGrid1.ColCount-1 do
       Srtgrd(StringGrid1,i);
end;

procedure TForm1.StringGrid1EditingDone(Sender: TObject);
var s:string;
begin
s:=StringGrid1.Cells[StringGrid1.col,StringGrid1.row];
   StringGrid1.Cells[StringGrid1.col,StringGrid1.row]:=clear_str(s);
end;

procedure TForm1.Button1Click(Sender: TObject);
var srt: array of real;
       i:integer;
begin
   setlength(srt,memo1.Lines.Count);
 for i:=0 to length(srt)-1 do
      srt[i]:=strtofloat(memo1.Lines[i]);
   BiDirBubbleSort(srt);  memo1.Lines.Clear;

   for i:=0 to length(srt)-1 do
    memo1.Lines.Add(floattostr(srt[i]));

end;

procedure TForm1.Button2Click(Sender: TObject);
VAR I:INTEGER;  S:STRING; D,R:REAL; E:INTEGER;
begin
 FOR I:=0 TO MEMO1.Lines.Count-1 DO
    BEGIN    E:=0;R:=0;
    S:=MEMO1.Lines.Strings[I];
    IF POS(',',S)>0     THEN
       R:=STRTOFLOAT(S) ELSE
       E:=STRTOINT(S);
    D:=D+E+R;
    end;    SHOWMESSAGE(FLOATTOSTR(D));
end;

procedure TForm1.Button3Click(Sender: TObject);
var x,y:integer;
begin
for X:=0 to form1.StringGrid1.ColCount-1 do
   for y:=1 to form1.StringGrid1.rowCount-1 do
   form1.StringGrid1.Cells[x,y]:=inttostr(-50+Random(101));
end;

procedure TForm1.Button4Click(Sender: TObject);
begin
    StringGrid1.ColCount:=StringGrid1.ColCount+1;
end;

procedure TForm1.Button5Click(Sender: TObject);
begin
   StringGrid1.ColCount:=StringGrid1.ColCount-1;
end;

procedure TForm1.Button6Click(Sender: TObject);
begin
      StringGrid1.rowCount:=StringGrid1.rowCount+1;
end;

procedure TForm1.Button7Click(Sender: TObject);
begin
    StringGrid1.rowCount:=StringGrid1.rowCount-1;
end;

end.
