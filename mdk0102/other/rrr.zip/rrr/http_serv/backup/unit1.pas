unit Unit1;

{$mode objfpc}{$H+}

interface
  uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs,Unit2, Menus, StdCtrls;

type
    { TForm1 }
   TForm1 = class(TForm)
    Memo1: TMemo;
    procedure FormCreate(Sender: TObject);
  private

  public

  end;

var
  Form1: TForm1;
  Serv : TTestHTTPServer;
  implementation
{$R *.lfm}
{ TForm1 }

procedure TForm1.FormCreate(Sender: TObject);
begin
   Serv:=TTestHTTPServer.Create(Nil);
  try
    Serv.BaseDir:=ExtractFilePath(ParamStr(0));

    Serv.Threaded:=False;
    Serv.Port:=80;
    Serv.AcceptIdleTimeout:=1000;
    Serv.OnAcceptIdle:=@Serv.DoIdle;
    Serv.Active:=True;
  finally
    Serv.Free;   end;
end;

end.

