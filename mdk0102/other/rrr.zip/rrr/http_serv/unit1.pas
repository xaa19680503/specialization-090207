unit Unit1;

{$mode objfpc}{$H+}

interface
  uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs,Unit2, Menus, StdCtrls;

type
    { TForm1 }
   TForm1 = class(TForm)
    Button1: TButton;
    Memo1: TMemo;
    procedure Button1Click(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure FormDestroy(Sender: TObject);
  private

  public

  end;

var
  Form1: TForm1;
  Serv : TTestHTTPServer;
  implementation
{$R *.lfm}
{ TForm1 }

procedure TForm1.FormCreate(Sender: TObject);
begin

end;

procedure TForm1.FormDestroy(Sender: TObject);
begin  if serv=nil then else
            Serv.Free;
end;

procedure TForm1.Button1Click(Sender: TObject);
begin
   Serv:=TTestHTTPServer.Create(Nil);
  try
    Serv.BaseDir:=ExtractFilePath(ParamStr(0));

    Serv.Threaded:=False;
    Serv.Port:=80;
    Serv.AcceptIdleTimeout:=1000;
    Serv.OnAcceptIdle:=@Serv.DoIdle;
    Serv.Active:=True;
  finally
    Serv.Free;
  end;

end;

end.

