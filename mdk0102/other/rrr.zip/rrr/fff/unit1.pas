unit Unit1;
{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics,
  Dialogs, StdCtrls, Unit2, fphttpserver;

type

  { TForm1 }

  TForm1 = class(TForm)
    ButtonRequest: TButton;
    Memo1: TMemo;
    procedure Button1Click(Sender: TObject);

    procedure FormCreate(Sender: TObject);
    procedure OnClientResponse(ThreadClient: TThreadClient);
    procedure OnClientError(ThreadClient: TThreadClient; E: Exception);
    procedure OnServerRequest(Sender: TObject;var ARequest: TFPHTTPConnectionRequest;var AResponse: TFPHTTPConnectionResponse);
  private
  FCount:integer;
  public

  end;

var
  Form1: TForm1;

implementation

{$R *.lfm}

{ TForm1 }
////////////////////////////////////////////////////////////////////////////
//=========================
// SERVER HTTP
//=========================

//=========================
// Server - start
procedure TForm1.FormCreate(Sender: TObject);
begin FCount:=0;
  Memo1.Clear;
  Memo1.Lines.Add('Auto start listening on port 80');
  TThreadServer.Create(80, @OnServerRequest);
end;
///////////////////////////////////////////////////////////////////////////////////
//=========================
//  If (length(FN)>0) and (FN[1]='/') then
//    Delete(FN,1,1);
//  DoDirSeparators(FN);
//  FN:=BaseDir+FN;
 // if FileExists(FN) then
//    begin
//    F:=TFileStream.Create(FN,fmOpenRead);
//    try
 //     CheckMimeLoaded;
 //     AResponse.ContentType:=MimeTypes.GetMimeType(ExtractFileExt(FN));
//      Writeln('Serving file: "',Fn,'". Reported Mime type: ',AResponse.ContentType);
//      AResponse.ContentLength:=F.Size;
//      AResponse.ContentStream:=F;
//      AResponse.Contents.Add('<form>> send </form>');
//      AResponse.SendContent;

//      AResponse.ContentStream:=Nil;
///    finally
///      F.Free;
//    end;
//    end  ;;
 // else
//    begin
  //  AResponse.Code:=404;
 //   AResponse.SendContent;
//    end;
//  Inc(FCount);
//  If FCount>=5 then
//    Active:=False;
//end;
// Server - Response
/////////////////////////////////////////////////////////////////////////////////
procedure TForm1.OnServerRequest(Sender: TObject;var ARequest: TFPHTTPConnectionRequest;var AResponse: TFPHTTPConnectionResponse);
var url: String;
     F : TFileStream;
    FN : String;
    mm:tmemo; i:integer;
begin
  url := 'http://'+ARequest.Host+'/'+ARequest.GetNextPathInfo+'?myvariable='+ARequest.QueryFields.Values['myvariable'];
    fn:=GetCurrentDir()+'\http\index.html';
//  AResponse.Content := fn+' '+inttostr(memo1.Lines.Count)+' OnServerRequest from='+ARequest.RemoteAddr+' -> to='+url;
 // AResponse.Contents.Add('<form>> send </form>');
  //AResponse.SendContent;

  if memo1.Lines.Count>20 then memo1.clear;
     memo1.lines.Add(url);

  //   exit;
  if FileExists(FN) then
      begin
   //   F:=TFileStream.Create(FN,fmOpenRead);
      try
          mm:=tmemo.Create(self);
          mm.Lines.LoadFromFile(fn);
          for i:=1 to mm.Lines.Count-1 do
             begin
              AResponse.Contents.Add(mm.Lines.Strings[i]);
             end;
  //      AResponse.Contents.Add('<form>> send </form>');
        AResponse.SendContent;
//        AResponse.ContentStream:=Nil;
      finally
         mm.Free;
    //      F.Free;
       end;
      end
    else
    begin
     AResponse.Code:=404;
     AResponse.SendContent;
      end;
 //   Inc(FCount);
//    If FCount>=5 then
//     TThreadServer.Active:=False;

end;
//////////////////////////////
procedure TForm1.Button1Click(Sender: TObject);
begin
  TThreadClient.Create('http://10.0.0.2:80/page.php?myvariable=test', @OnClientResponse, @OnClientError);
end;
//=========================
// Client - client response
procedure TForm1.OnClientResponse(ThreadClient: TThreadClient);
begin
  Memo1.lines.Add('OnClientResponse='+ThreadClient.Response);
end;
//=========================
// Client - client error
procedure TForm1.OnClientError(ThreadClient: TThreadClient; E: Exception);
begin
  Memo1.lines.Add('URL:'+ThreadClient.url+' Error:'+ E.Message);
end;


end.

