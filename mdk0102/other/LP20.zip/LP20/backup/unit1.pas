unit Unit1;
{$mode objfpc}{$H+}
{$ASMMODE INTEL}    //!!!Использовать эту директиву asm
interface
uses
  Classes, SysUtils, FileUtil, Forms, Controls, Graphics, Dialogs, StdCtrls,
  LCLProc, Menus, ExtCtrls, DBGrids, ComCtrls, DBExtCtrls, DBCtrls, Crt,
  Windows, Variants, dbf, Math, DB, memds, LazUTF8, IniFiles ;
type
  { TForm1 }

  TForm1 = class(TForm)
    Button1: TButton;     Button2: TButton;    Button3: TButton;
    CheckBox1: TCheckBox;
    CheckBox2: TCheckBox;
    DataSource1: TDataSource;
    Dbf1: TDbf;
    DBGrid1: TDBGrid;
    DBGrid2: TDBGrid;
    MainMenu1: TMainMenu;
     Memo1: TMemo;
    MenuItem1: TMenuItem;     MenuItem2: TMenuItem;    MenuItem3: TMenuItem;
    MenuItem4: TMenuItem;
    MenuItem5: TMenuItem;
    Separator1: TMenuItem;
    OpenDialog1: TOpenDialog;    PageControl1: TPageControl;    Panel1: TPanel;
    TabSheet1: TTabSheet;    TabSheet2: TTabSheet;
    TabSheet3: TTabSheet;
    TabSheet4: TTabSheet;
    Timer1: TTimer;
    procedure Button1Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure Button3Click(Sender: TObject);
    procedure CheckBox1Change(Sender: TObject);
    procedure CheckBox2Change(Sender: TObject);
    procedure MenuItem2Click(Sender: TObject);
    procedure MenuItem3Click(Sender: TObject);
    procedure MenuItem4Click(Sender: TObject);
    procedure MenuItem5Click(Sender: TObject);
    procedure   n_dbf(sss:string);   ///Записать в класс формы
    procedure   POTOK(PT:STRING);   ///Записать в класс формы
    procedure new_dbf;
  private
  public
  end;

var
  Form1: TForm1;
     si: TSystemInfo;
implementation
{$R *.lfm}
{ TForm1 }
///--------------создать базу новую --------------------///
procedure TForm1.new_dbf;
var  NewDBF: TDBF; Info : TSearchRec;  s:string;
begin  s:=ExtractFilePath(ParamStr(0))+'m_t.dbf';
  if findfirst(s, faAnyFile, Info )=0 then
    begin showmessage('file find ok');
      MenuItem2.Checked := true;  //укажум галочку
      MenuItem2.Enabled:=false;  //сменим активность окна
      exit;
    end;    NewDBF := TDBF.Create(nil);  //создаи обьект
    try    //контроль на ошибку
      NewDBF.TableName := 'm_t.dbf';  //указали имя
      NewDBF.FieldDefs.Add('ramdom', ftFloat ); //указали поле
      NewDBF.FieldDefs.Add('name', ftString, 25); //указали поле
      NewDBF.FieldDefs.Add('INF1', ftString, 35);  // указали другое поле
      NewDBF.FieldDefs.Add('INF2', ftWord     );  // указали другое поле
      NewDBF.FieldDefs.Add('dwLength',ftWord  );  // указали другое поле
      NewDBF.FieldDefs.Add('dwMemoryLoad',ftWord );  // указали другое поле
      NewDBF.FieldDefs.Add('dwTotalPhys',ftWord );  // указали другое поле
      NewDBF.FieldDefs.Add('dwAvailPhys',ftWord );  // указали другое поле
      NewDBF.FieldDefs.Add('dwTotalPageFile',ftWord );  // указали другое поле
      NewDBF.FieldDefs.Add('dwAvailPageFile',ftWord );  // указали другое поле
      NewDBF.FieldDefs.Add('dwTotalVirtual',ftWord );  // указали другое поле
      NewDBF.FieldDefs.Add('dwAvailVirtual',ftWord );  // указали другое поле
      NewDBF.FieldDefs.Add('c',ftWord );   NewDBF.FieldDefs.Add('d',ftWord );
      NewDBF.FieldDefs.Add('e',ftWord  );  NewDBF.FieldDefs.Add('j',ftWord );
      NewDBF.FieldDefs.Add('f',ftWord );   NewDBF.FieldDefs.Add('g',ftWord );
      NewDBF.FieldDefs.Add('k',ftWord );  // указали другое поле
      NewDBF.FieldDefs.Add('count_proc',ftWord );  // указали другое поле
      NewDBF.FieldDefs.Add('spider_proc',ftWord );  // указали другое поле
      NewDBF.FieldDefs.Add('memo',ftMemo);  // указали другое поле
      NewDBF.FieldDefs.Add('dat',ftDate);  // указали другое поле
     NewDBF.FieldDefs.Add('tim',ftDateTime);  // указали другое поле
      NewDBF.CreateTable; //сохранить базу
    finally   // при завершении
      NewDBF.Free;    //освободить обьект
      MenuItem2.Checked := true;  //укажум галочку
      MenuItem2.Enabled:=false;  //сменим активность окна
    end;
end;
///--------------------------------------////--------------------------------------////
function GetCPUSpeed: Double;
const   DelayTime = 500;
var
  TimerHi, TimerLo: DWORD;
  PriorityClass, Priority: Integer;
begin
  PriorityClass := GetPriorityClass(GetCurrentProcess);
  Priority      := GetThreadPriority(GetCurrentThread);
  SetPriorityClass(GetCurrentProcess, REALTIME_PRIORITY_CLASS);
  SetThreadPriority(GetCurrentThread, THREAD_PRIORITY_TIME_CRITICAL);
  Sleep(10);
  asm
    dw 310Fh
    mov TimerLo, eax
    mov TimerHi, edx
  end;
  Sleep(DelayTime);
  asm
    dw 310Fh
    sub eax, TimerLo
    sbb edx, TimerHi
    mov TimerLo, eax
    mov TimerHi, edx
  end;
  SetThreadPriority(GetCurrentThread, Priority);
  SetPriorityClass(GetCurrentProcess, PriorityClass);
  Result := TimerLo / (1000 * DelayTime);
end;

procedure TForm1.Button1Click(Sender: TObject);
var MS:TMemoryStatus;
begin
  MS.dwLength:=sizeof(TMemoryStatus);
  GlobalMemoryStatus(MS);    // ПРИНЯЛИ ДАННЫЕ С РЕЕСТРА О РЕСУРСАХ
  Memo1.Text := 'Свободно: ' + IntToStr(MS.dwAvailPhys div 1024) + 'K байт' ;
  MS.dwLength:=SizeOf(TMemoryStatus) ;
 // with MS do begin
    Memo1.Lines.Add(IntToStr(ms.dwLength) + ' Размер записи') ;
    Memo1.Lines.Add(IntToStr(ms.dwMemoryLoad) + '% используемой памяти') ;
    Memo1.Lines.Add(FloatToStr(ms.dwTotalPhys) + ' Полный объем физической памяти в байтах') ;
    Memo1.Lines.Add(IntToStr(ms.dwAvailPhys) + ' Доступно физической памяти в байтах') ;
    Memo1.Lines.Add(IntToStr(ms.dwTotalPageFile) + ' Всего байт из файла подкачки') ;
    Memo1.Lines.Add(IntToStr(ms.dwAvailPageFile) + ' Доступные байты в файле подкачки') ;
    Memo1.Lines.Add(IntToStr(ms.dwTotalVirtual) + ' Пользовательские Байты Адресного пространства') ;
    Memo1.Lines.Add(IntToStr(ms.dwAvailVirtual) + ' Доступные байты пользователя адресного пространства') ;
//   end;

end;

procedure TForm1.Button2Click(Sender: TObject);
var how:int64; i:integer; df,ds,s:string;
begin
for i:=3 to 9 do
  begin s:='';
    case i of
    9:s:='k: ';
    8:s:='g: ';
    7:s:='f: ';
    3:s:='c: ';
    4:s:='d: ';
    5:s:='e: ';
    6:s:='j: ';
    end;
       how:=DiskSize(i);
    if how<=0 then continue;
    df:=' свободно '+inttostr(DiskFree(i) div 1024  )+'к бт';
    ds:=' размер '+inttostr(DiskSize(i) div 1024 )+'к бт';
    memo1.Lines.Add(s+df+ds );
  end;

end;

procedure TForm1.Button3Click(Sender: TObject);
begin
      GetSystemInfo({var}si);  ///УЗНАЛИ СКРОЛЬКО  ПРОЦЕССОРОВ
    memo1.Lines.Add(' процессоров: '+inttostr(si.dwNumberOfProcessors));
    memo1.Lines.Add('Your CPU speed: %f MHz', [GetCPUSpeed]);  //КАКАЯ ЧАСТОТА

end;

procedure TForm1.CheckBox1Change(Sender: TObject);
var      I:INTEGER; P, s:string;
  PascalFiles: TStringList;
begin
         CheckBox2.Checked:=false; dbf1.Active:=FALSE;
         s:=ExtractFilePath(ParamStr(0)+'m_t.dbf');        // СВЕДЕНИЕ О БАЗЕ
                        PascalFiles := TStringList.Create; // СОЗДАДИМ СПИСОК
try     FindAllFiles(PascalFiles, s, 'm_t.dbf' , true);    // В СПИСОК РЕЗУЛЬТАТ ПОИСКА
                  I:=PascalFiles.Count;                    // ДЛИНА СПИСКА
finally              PascalFiles.Free;
end;    IF I<1  THEN   exit ;    // ДЛИНА СПИСКА МЕНЕЕ ЕДИНЫЦЫ  ТО ВЫХОД
IF dbf1.Active=FALSE THEN  dbf1.TableName:='m_t.dbf';
IF dbf1.Active=FALSE THEN  dbf1.FilePath:=S;
    dbf1.Active:=CheckBox1.Checked;  // АКТИВНОСТЬ БАЗЫ ВКЛЮЧИТЬ ИЛИ ВЫКЛЮЧИТЬ
end;
procedure TForm1.CheckBox2Change(Sender: TObject);
var      I:INTEGER; P, s:string;
  PascalFiles: TStringList;
begin                              dbf1.Active:=false;
s:=ExtractFilePath(ParamStr(0)+'sss.dbf');        // СВЕДЕНИЕ О БАЗЕ
                      PascalFiles := TStringList.Create; // СОЗДАДИМ СПИСОК
try     FindAllFiles(PascalFiles, s, 'sss.dbf' , true);    // В СПИСОК РЕЗУЛЬТАТ ПОИСКА
                  I:=PascalFiles.Count;                    // ДЛИНА СПИСКА
finally              PascalFiles.Free;
end;    IF I<1  THEN   exit ;    // ДЛИНА СПИСКА МЕНЕЕ ЕДИНЫЦЫ  ТО ВЫХОД
IF dbf1.Active=FALSE THEN  dbf1.TableName:='sss.dbf';
IF dbf1.Active=FALSE THEN  dbf1.FilePath:=S;
    dbf1.Active:=CheckBox2.Checked;  // АКТИВНОСТЬ БАЗЫ ВКЛЮЧИТЬ ИЛИ ВЫКЛЮЧИТЬ
end;

procedure TForm1.MenuItem2Click(Sender: TObject);
begin
  new_dbf;
end;
 /////////////////////////
procedure TForm1.MenuItem3Click(Sender: TObject);
var    n, I:INTEGER; P, s:string;
  PascalFiles: TStringList;
begin    s:=ExtractFilePath(ParamStr(0)+'m_t.dbf');
                        PascalFiles := TStringList.Create;
   try     FindAllFiles(PascalFiles, s, 'm_t.dbf' , true);
                     I:=PascalFiles.Count;
   finally              PascalFiles.Free;
   end;    IF I<1  THEN   exit ;
   Dbf1.TableName:='m_t.dbf'; Dbf1.FilePathFull:=S; Dbf1.Active:=true;
   dbf1.Open; {// ОТКРЫТЬ  }
   P:=INTTOSTR(DBF1.RecordCount);
   n:=DBF1.RecordCount;
   memo1.Lines.Add(s+' ПОТОК №'+P);
FOR I:=0 TO 100 DO   BEGIN
    DBF1.Append;   //ДОБАВИТЬ
    DBF1.FieldValues['ramdom']:= RandomRange(1, 1000)/100; // СЛУЧАЙНОЕ ЧИСЛО
    DBF1.FieldValues['name'  ]:=P+'-w-'+inttostr(i); //НОМЕР В ПОТОКЕ
    DBF1.FieldValues['INF2'  ]:= n;
    dbf1.Post;      //СОХРАНИТЬ//
   memo1.Lines.Add(DBF1.FieldValues['name'  ]);
    end;
dbf1.Close; {ЗАКРЫТЬ}   dbf1.Active:=false;
end;
  ///////////////////////////////
procedure TForm1.MenuItem4Click(Sender: TObject);
begin
   n_dbf('sss' );
end;
  /////////////////////////
procedure TForm1.MenuItem5Click(Sender: TObject);
begin
 POTOK('sss' );
end;

procedure TForm1.n_dbf(sss:string);
var  NewDBF: TDBF; Info : TSearchRec;  s:string;
begin  s:=ExtractFilePath(ParamStr(0))+sss+'.dbf';
  if findfirst(s, faAnyFile, Info )=0 then
    begin showmessage('file find ok');    exit;  end;
  NewDBF := TDBF.Create(nil);  //создаи обьект
    try    //контроль на ошибку
      NewDBF.TableName := sss+'.dbf';                       //указали имя базы
      NewDBF.FieldDefs.Add('ramdom', ftFloat );
      NewDBF.FieldDefs.Add('name', ftString, 25);       //указали поле
      NewDBF.FieldDefs.Add('INF1', ftString, 35);      // указали другое поле
       NewDBF.FieldDefs.Add('INF2', ftWord     );       // указали другое поле
       NewDBF.FieldDefs.Add('count_proc',ftWord );  // указали другое поле
      NewDBF.FieldDefs.Add('dat',ftDate);                // указали другое поле
       NewDBF.CreateTable;                                   //сохранить базу
    finally                                                             // при завершении
      NewDBF.Free;                                          //освободить объект
    end;    end;


procedure  TForm1.POTOK(PT:STRING);
var    n:word;  I:INTEGER; P, s:string;
  PascalFiles: TStringList;
begin    s:=ExtractFilePath(ParamStr(0)+PT+'.dbf');
                        PascalFiles := TStringList.Create;
   try     FindAllFiles(PascalFiles, s, PT+'.dbf' , true);
                     I:=PascalFiles.Count;
   finally           PascalFiles.Free;
   end;    IF I<1  THEN   exit ;  Dbf1.Active:=false;
   Dbf1.TableName:=PT+'.dbf'; Dbf1.FilePathFull:=S;
   dbf1.FilePath:=S;
   dbf1.Open;  {// ОТКРЫТЬ}
   P:=INTTOSTR(DBF1.RecordCount);
   n:=DBF1.RecordCount;
   memo1.Lines.Add(s+' ПОТОК №'+P);
FOR I:=0 TO 100 DO   BEGIN
    DBF1.Append;        //ДОБАВИТЬ
    DBF1.FieldValues['ramdom']:= RandomRange(1, 1000)/100; // СЛУЧАЙНОЕ ЧИСЛО
    DBF1.FieldValues['name'  ]:=P+'-R-'+inttostr(i);      //НОМЕР В ПОТОКЕ
    DBF1.FieldValues['INF2'  ]:= n;
    DBF1.FieldValues['dat'  ]:=  date;
    dbf1.Post;         //СОХРАНИТЬ
    memo1.Lines.Add(DBF1.FieldValues['name'  ]);  /// УКАЖЕМ В МЕМО ИМЯ  ПОТОКА
    end;      dbf1.Close; {ЗАКРЫТЬ}   dbf1.Active:=false;
end;


end.

