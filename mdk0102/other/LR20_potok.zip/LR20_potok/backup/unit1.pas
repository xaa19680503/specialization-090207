unit Unit1;
{$mode objfpc}{$H+}
{$ASMMODE INTEL}    //!!!Использовать эту директиву asm
interface
uses
  Classes, SysUtils, FileUtil, Forms, Controls, Graphics, Dialogs, StdCtrls,
  LCLProc, Menus, ExtCtrls, DBGrids, ComCtrls, Crt, Windows, Variants, dbf,
  Math, DB, SQLDB, LazUTF8, TASources, TAGraph, TAFuncSeries, TASeries,
  IniFiles, Types, Grids, Spin;
type
  { TForm1 }
  TForm1 = class(TForm)
    Button1: TButton;      Button2: TButton;    Button3: TButton;
    Chart1: TChart;
    Chart1BarSeries1: TBarSeries;
    CheckBox1: TCheckBox;
    CheckBox2: TCheckBox;
    CheckBox3: TCheckBox;
    DataSource1: TDataSource;    Dbf1: TDbf;
    DBGrid1: TDBGrid;
    MainMenu1: TMainMenu;
    Memo1: TMemo;
    MenuItem1: TMenuItem;    MenuItem2: TMenuItem;    MenuItem3: TMenuItem;
    OpenDialog1: TOpenDialog;
    PageControl1: TPageControl;
    RadioGroup1: TRadioGroup;
    SpinEdit1: TSpinEdit;
    TabSheet1: TTabSheet;    TabSheet2: TTabSheet;
    TabSheet3: TTabSheet;
    Timer1: TTimer;
    procedure Button1Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure Button3Click(Sender: TObject);
    procedure CheckBox1Change(Sender: TObject);
    procedure CheckBox2Change(Sender: TObject);
    procedure CheckBox3Change(Sender: TObject);

    procedure DBGrid1DrawColumnCell(Sender: TObject; const Rect: TRect;
      DataCol: Integer; Column: TColumn; State: TGridDrawState);


    procedure FormCreate(Sender: TObject);
    procedure MenuItem2Click(Sender: TObject);
    procedure MenuItem3Click(Sender: TObject);
    procedure MenuItem4Click(Sender: TObject);
    procedure new_dbf;
    procedure RadioGroup1Click(Sender: TObject);
    procedure TabSheet2ContextPopup(Sender: TObject; MousePos: TPoint;
      var Handled: Boolean);
    procedure Timer1Timer(Sender: TObject);
  private
    ii:integer;
    { private declarations }
  public
    { public declarations }
  end;

var
  Form1: TForm1;
   si: TSystemInfo;
implementation
{$R *.lfm}
{ TForm1 }
function GetCPUSpeed: Double;
const   DelayTime = 500;
var
  TimerHi, TimerLo: DWORD;
  PriorityClass, Priority: Integer;
begin
  PriorityClass := GetPriorityClass(GetCurrentProcess);
  Priority      := GetThreadPriority(GetCurrentThread);
  SetPriorityClass(GetCurrentProcess, REALTIME_PRIORITY_CLASS);
  SetThreadPriority(GetCurrentThread, THREAD_PRIORITY_TIME_CRITICAL);
  Sleep(10);
  asm
    dw 310Fh
    mov TimerLo, eax
    mov TimerHi, edx
  end;
  Sleep(DelayTime);
  asm
    dw 310Fh
    sub eax, TimerLo
    sbb edx, TimerHi
    mov TimerLo, eax
    mov TimerHi, edx
  end;
  SetThreadPriority(GetCurrentThread, Priority);
  SetPriorityClass(GetCurrentProcess, PriorityClass);
  Result := TimerLo / (1000 * DelayTime);
end;


procedure TForm1.Button1Click(Sender: TObject);
var MS:TMemoryStatus;
begin
  MS.dwLength:=sizeof(TMemoryStatus);
  GlobalMemoryStatus(MS);
  Memo1.Text := 'Свободно: ' + IntToStr(MS.dwAvailPhys div 1024) + 'K байт' ;
  MS.dwLength:=SizeOf(TMemoryStatus) ;
 // with MS do begin
    Memo1.Lines.Add(IntToStr(ms.dwLength) + ' Размер записи') ;
    Memo1.Lines.Add(IntToStr(ms.dwMemoryLoad) + '% используемой памяти') ;
    Memo1.Lines.Add(FloatToStr(ms.dwTotalPhys) + ' Полный объем физической памяти в байтах') ;
    Memo1.Lines.Add(IntToStr(ms.dwAvailPhys) + ' Доступно физической памяти в байтах') ;
    Memo1.Lines.Add(IntToStr(ms.dwTotalPageFile) + ' Всего байт из файла подкачки') ;
    Memo1.Lines.Add(IntToStr(ms.dwAvailPageFile) + ' Доступные байты в файле подкачки') ;
    Memo1.Lines.Add(IntToStr(ms.dwTotalVirtual) + ' Пользовательские Байты Адресного пространства') ;
    Memo1.Lines.Add(IntToStr(ms.dwAvailVirtual) + ' Доступные байты пользователя адресного пространства') ;
//   end;
end;

procedure TForm1.Button2Click(Sender: TObject);
var how:int64; i:integer; df,ds,s:string;
begin
for i:=3 to 9 do
  begin s:='';
    case i of
    9:s:='k: ';
    8:s:='g: ';
    7:s:='f: ';
    3:s:='c: ';
    4:s:='d: ';
    5:s:='e: ';
    6:s:='j: ';
    end;
       how:=DiskSize(i);
    if how<=0 then continue;
    df:=' свободно '+inttostr(DiskFree(i) div 1024  )+'к бт';
    ds:=' размер '+inttostr(DiskSize(i) div 1024 )+'к бт';
    memo1.Lines.Add(s+df+ds );
  end;
end;

procedure TForm1.Button3Click(Sender: TObject);
begin
    GetSystemInfo({var}si);
    memo1.Lines.Add(' процессоров: '+inttostr(si.dwNumberOfProcessors));
    memo1.Lines.Add('Your CPU speed: %f MHz', [GetCPUSpeed]);
end;

procedure TForm1.CheckBox1Change(Sender: TObject);
begin
  dbf1.Active:=CheckBox1.Checked;
            if CheckBox1.Checked  then
                         dbf1.RecNo:=5;
end;

procedure TForm1.CheckBox2Change(Sender: TObject);
begin  if CheckBox1.Checked then else exit;;
dbf1.Filtered:=false;
//dbf1.Filter:= 'name = "'+edit1.Text+'"';
case RadioGroup1.ItemIndex of
0:begin  dbf1.Filter:= 'inf2 = '+inttostr(spinedit1.value);end;
1:begin  dbf1.Filter:= 'inf2 < '+inttostr(spinedit1.value);end;
2:begin dbf1.Filter:= 'inf2 > '+inttostr(spinedit1.value);end;
3:begin dbf1.Filter:= 'inf2 <> '+inttostr(spinedit1.value); end;
end;
dbf1.Filtered:=CheckBox2.Checked;
end;

procedure TForm1.CheckBox3Change(Sender: TObject);
begin
timer1.Enabled:=CheckBox3.Checked;
TabSheet3.Visible:=CheckBox3.Checked;
if  timer1.Enabled then
PageControl1.PageIndex:=2;
end;

procedure TForm1.DBGrid1DrawColumnCell(Sender: TObject; const Rect: TRect;
  DataCol: Integer; Column: TColumn; State: TGridDrawState);
begin
  spinedit1.Value:=dbf1.FieldValues['inf2'  ];
end;


procedure TForm1.FormCreate(Sender: TObject);
begin
      Button1Click(Sender );
      Button2Click(Sender );
      Button3Click(Sender );
end;
procedure TForm1.new_dbf;
var  NewDBF: TDBF; Info : TSearchRec;  s:string;
begin  s:=ExtractFilePath(ParamStr(0))+'m_t.dbf';
  if findfirst(s, faAnyFile, Info )=0 then
    begin showmessage('file find ok');
      MenuItem2.Checked := true;  //укажум галочку
      MenuItem2.Enabled:=false;  //сменим активность окна
      exit;
    end;      Dbf1.TableName:=s;
    NewDBF := TDBF.Create(nil);  //создаи обьект
    try    //контроль на ошибку
      NewDBF.TableName := 'm_t.dbf';  //указали имя
      NewDBF.FieldDefs.Add('ramdom', ftFloat ); //указали поле
      NewDBF.FieldDefs.Add('name', ftString, 25); //указали поле
      NewDBF.FieldDefs.Add('INF1', ftString, 35);  // указали другое поле
      NewDBF.FieldDefs.Add('INF2', ftWord     );  // указали другое поле
      NewDBF.FieldDefs.Add('dwLength',ftWord  );  // указали другое поле
      NewDBF.FieldDefs.Add('dwMemoryLoad',ftWord );  // указали другое поле
      NewDBF.FieldDefs.Add('dwTotalPhys',ftWord );  // указали другое поле
      NewDBF.FieldDefs.Add('dwAvailPhys',ftWord );  // указали другое поле
      NewDBF.FieldDefs.Add('dwTotalPageFile',ftWord );  // указали другое поле
      NewDBF.FieldDefs.Add('dwAvailPageFile',ftWord );  // указали другое поле
      NewDBF.FieldDefs.Add('dwTotalVirtual',ftWord );  // указали другое поле
      NewDBF.FieldDefs.Add('dwAvailVirtual',ftWord );  // указали другое поле
      NewDBF.FieldDefs.Add('c',ftWord );   NewDBF.FieldDefs.Add('d',ftWord );
      NewDBF.FieldDefs.Add('e',ftWord  );  NewDBF.FieldDefs.Add('j',ftWord );
      NewDBF.FieldDefs.Add('f',ftWord );   NewDBF.FieldDefs.Add('g',ftWord );
      NewDBF.FieldDefs.Add('k',ftWord );  // указали другое поле
      NewDBF.FieldDefs.Add('count_proc',ftWord );  // указали другое поле
      NewDBF.FieldDefs.Add('spider_proc',ftWord );  // указали другое поле
      NewDBF.FieldDefs.Add('memo',ftMemo);  // указали другое поле
      NewDBF.FieldDefs.Add('dat',ftDate);  // указали другое поле
     NewDBF.FieldDefs.Add('tim',ftDateTime);  // указали другое поле
      NewDBF.CreateTable; //сохранить базу
    finally   // при завершении
      NewDBF.Free;    //освободить обьект
      MenuItem2.Checked := true;  //укажум галочку
      MenuItem2.Enabled:=false;  //сменим активность окна
      end;


end;

procedure TForm1.RadioGroup1Click(Sender: TObject);
begin

end;

procedure TForm1.TabSheet2ContextPopup(Sender: TObject; MousePos: TPoint;
  var Handled: Boolean);
begin

end;

procedure TForm1.Timer1Timer(Sender: TObject);
var i:integer;
begin
   if CheckBox1.Checked then else exit;;
   if dbf1.EOF then exit;
   dbf1.Next;
if  Chart1BarSeries1.Count>10 then Chart1BarSeries1.clear;
    Chart1BarSeries1.Add(dbf1.FieldValues['ramdom']);
   if dbf1.EOF then dbf1.First;
end;

procedure TForm1.MenuItem2Click(Sender: TObject);
begin
  new_dbf;
end;

procedure TForm1.MenuItem3Click(Sender: TObject);
var    n, I:INTEGER; P, s:string;
  PascalFiles: TStringList;
begin    s:=ExtractFilePath(ParamStr(0)+'m_t.dbf');
                        PascalFiles := TStringList.Create;
   try     FindAllFiles(PascalFiles, s, 'm_t.dbf' , true);
                     I:=PascalFiles.Count;
   finally              PascalFiles.Free;
   end;    IF I<1  THEN   exit ;
   Dbf1.TableName:='m_t.dbf'; Dbf1.FilePathFull:=S; Dbf1.Active:=false;
   dbf1.Open; {// ОТКРЫТЬ }   P:=INTTOSTR(DBF1.RecordCount);
   n:=DBF1.RecordCount;
   memo1.Lines.Add(s+' ПОТОК №'+P);
FOR I:=0 TO 100 DO   BEGIN
    DBF1.Append;   //ДОБАВИТЬ
    DBF1.FieldValues['ramdom']:= RandomRange(1, 1000)/100; // СЛУЧАЙНОЕ ЧИСЛО
    DBF1.FieldValues['name'  ]:=P+'-w-'+inttostr(i); //НОМЕР В ПОТОКЕ
    DBF1.FieldValues['INF2'  ]:=n;
    dbf1.Post;      //СОХРАНИТЬ
    dbf1.RecNo:=DBF1.RecordCount-i;
   memo1.Lines.Add(DBF1.FieldValues['name'  ]);
    end;      dbf1.Close; {ЗАКРЫТЬ}   dbf1.Active:=false;
end;

procedure TForm1.MenuItem4Click(Sender: TObject);
var    n, I:INTEGER; P, s:string;
  PascalFiles: TStringList;
begin
    s:=ExtractFilePath(ParamStr(0)+'m_t.dbf');
                        PascalFiles := TStringList.Create;
   try     FindAllFiles(PascalFiles, s, 'm_t.dbf' , true);
                     I:=PascalFiles.Count;
   finally              PascalFiles.Free;
   end;    IF I<1  THEN   exit ;
   Dbf1.TableName:='m_t.dbf'; Dbf1.FilePathFull:=S; Dbf1.Active:=false;
   dbf1.Open; {// ОТКРЫТЬ }   P:=INTTOSTR(DBF1.RecordCount);
   n:=DBF1.RecordCount;

while not(dbf1.eof) do
FOR I:=0 TO 100 DO   BEGIN
    DBF1.Append;   //ДОБАВИТЬ
    DBF1.FieldValues['ramdom']:= RandomRange(1, 1000)/100; // СЛУЧАЙНОЕ ЧИСЛО
    DBF1.FieldValues['name'  ]:=P+'-w-'+inttostr(i); //НОМЕР В ПОТОКЕ
    DBF1.FieldValues['INF2'  ]:=n;
    dbf1.Post;      //СОХРАНИТЬ

    dbf1.next;
    end;
    dbf1.Close;
    dbf1.Active:=false;

end;

//NewDBF.TableName := 'm_t.dbf';  //указали имя
//NewDBF.FieldDefs.Add('ramdom', ftFloat ); //указали поле
//NewDBF.FieldDefs.Add('name', ftString, 25); //указали поле
//NewDBF.FieldDefs.Add('INF1', ftString, 35);  // указали другое поле
//NewDBF.FieldDefs.Add('INF2', ftWord     );  // указали другое поле
//NewDBF.FieldDefs.Add('dwLength',ftWord  );  // указали другое поле
//NewDBF.FieldDefs.Add('dwMemoryLoad',ftWord );  // указали другое поле
//NewDBF.FieldDefs.Add('dwTotalPhys',ftWord );  // указали другое поле
//NewDBF.FieldDefs.Add('dwAvailPhys',ftWord );  // указали другое поле
//NewDBF.FieldDefs.Add('dwTotalPageFile',ftWord );  // указали другое поле
//NewDBF.FieldDefs.Add('dwAvailPageFile',ftWord );  // указали другое поле
//NewDBF.FieldDefs.Add('dwTotalVirtual',ftWord );  // указали другое поле
//NewDBF.FieldDefs.Add('dwAvailVirtual',ftWord );  // указали другое поле
//NewDBF.FieldDefs.Add('c',ftWord );   NewDBF.FieldDefs.Add('d',ftWord );
//NewDBF.FieldDefs.Add('e',ftWord  );  NewDBF.FieldDefs.Add('j',ftWord );
//NewDBF.FieldDefs.Add('f',ftWord );   NewDBF.FieldDefs.Add('g',ftWord );
//NewDBF.FieldDefs.Add('k',ftWord );  // указали другое поле
//NewDBF.FieldDefs.Add('count_proc',ftWord );  // указали другое поле
//NewDBF.FieldDefs.Add('spider_proc',ftWord );  // указали другое поле
//NewDBF.FieldDefs.Add('memo',ftMemo);  // указали другое поле
//NewDBF.FieldDefs.Add('dat',ftDate);  // указали другое поле
//NewDBF.FieldDefs.Add('tim',ftDateTime);  // указали другое поле
//NewDBF.CreateTable; //сохранить базу

//    DBF1.First;

end.



