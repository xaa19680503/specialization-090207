unit Unit2;
 {$mode ObjFPC}{$H+}
 interface
 uses  Classes, SysUtils, Menus, Dialogs;
 type   { TDataModule1 }
   TDataModule1 = class(TDataModule)
MenuItem1: TMenuItem;
    MenuItem2: TMenuItem;    MenuItem3: TMenuItem;
    MenuItem4: TMenuItem;    MenuItem5: TMenuItem;
    MenuItem6: TMenuItem;    MenuItem7: TMenuItem;
    MenuItem8: TMenuItem;    OpenDialog1: TOpenDialog;
    OpenDialog2: TOpenDialog;
    SaveDialog1: TSaveDialog;
    SaveDialog2: TSaveDialog;

  private
  public
  end;
var  DataModule1: TDataModule1;
implementation
uses Unit1;    ///укажем библиотеку с обьектом  form1
{$R *.lfm}
{ TDataModule1 }
end.

