unit Unit1;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, ExtCtrls, Grids,
  StdCtrls, Menus;

type
  { TForm1 }
  TForm1 = class(TForm)
    Label1: TLabel;
    Label2: TLabel;
    MainMenu1: TMainMenu;
    Memo1: TMemo;
    MenuItem1: TMenuItem;
    MenuItem2: TMenuItem;
    MenuItem3: TMenuItem;
    MenuItem4: TMenuItem;
    MenuItem5: TMenuItem;
    MenuItem6: TMenuItem;
    MenuItem7: TMenuItem;
    MenuItem8: TMenuItem;
    Panel1: TPanel;
    Panel2: TPanel;
    StringGrid1: TStringGrid;
    procedure MenuItem2Click(Sender: TObject);
    procedure MenuItem3Click(Sender: TObject);
    procedure MenuItem5Click(Sender: TObject);
    procedure MenuItem6Click(Sender: TObject);
    procedure MenuItem7Click(Sender: TObject);
    procedure MenuItem8Click(Sender: TObject);
    procedure StringGrid1SelectCell(Sender: TObject; aCol, aRow: Integer;
      var CanSelect: Boolean);
  private
  row ,col:integer; // форме  укажем свойства
  public
  end;
var  Form1: TForm1;

implementation
uses Unit2;
{$R *.lfm}
{ TForm1 }
procedure TForm1.MenuItem8Click(Sender: TObject);
begin
     if memo1.Lines.Count>0 then     // если  строки есть
     if DataModule1.saveDialog1.Execute then    // если  открыли  ввод  записи
            begin                  //сохраним даные
            memo1.Lines.SaveToFile(DataModule1.saveDialog1.FileName);
            end;

end;

procedure TForm1.StringGrid1SelectCell(Sender: TObject; aCol, aRow: Integer;
  var CanSelect: Boolean);
begin
   label1.caption:=inttostr(acol); form1.col:=acol;
   label2.caption:=inttostr(arow); form1.row:=arow;
end;

procedure TForm1.MenuItem5Click(Sender: TObject);
begin
      if memo1.Lines.Count>0 then     // если  строки есть
     if DataModule1.openDialog1.Execute then    // если  открыли  ввод  записи
            begin                  //сохраним даные
            memo1.Lines.loadfromFile(DataModule1.openDialog1.FileName);
            end;
end;

procedure TForm1.MenuItem3Click(Sender: TObject);
begin

     if DataModule1.saveDialog2.Execute then    // если  открыли  ввод  записи
            begin                  //сохраним даные
            StringGrid1.SaveToFile(DataModule1.saveDialog2.FileName);
            end;
end;

procedure TForm1.MenuItem2Click(Sender: TObject);
begin    if DataModule1.openDialog2.Execute then    // если  открыли  ввод  записи
            begin                  //сохраним даные
            StringGrid1.loadfromFile(DataModule1.openDialog2.FileName);
            end;
end;

procedure TForm1.MenuItem6Click(Sender: TObject);
VAR I:INTEGER;
begin             StringGrid1.RowCount:=StringGrid1.RowCount+1;
  FORM1.row:=StringGrid1.RowCount-1;
//   if form1.row<1 then exit;
   if form1.COL<1 then exit;
   for i:=1 to StringGrid1.ColCount-1 do
               StringGrid1.Cells[i,form1.row]:='';
   if StringGrid1.ColCount<memo1.Lines.Count then
      StringGrid1.ColCount:=memo1.Lines.Count+1;
   for i:=0 to memo1.lines.Count-1 do
   begin
   StringGrid1.Cells[i+1,0        ]:='ЗНАЧ.'+INTTOSTR(I);
   StringGrid1.Cells[i+1,form1.row]:=memo1.Lines.Strings[i];
   end;
   StringGrid1.Cells[0,form1.row  ]:='ЭКСП-'+INTTOSTR(FORM1.row);
   StringGrid1.Cells[0,0          ]:='НАЗВ.';

end;

procedure TForm1.MenuItem7Click(Sender: TObject);
VAR I:INTEGER;
begin   //     StringGrid1.RowCount:=StringGrid1.RowCount+1;
//  FORM1.row:=StringGrid1.RowCount-1;
//   if form1.row<1 then exit;
   if form1.COL<1 then exit;
   for i:=1 to StringGrid1.ColCount-1 do
               StringGrid1.Cells[i,form1.row]:='';
   if StringGrid1.ColCount<memo1.Lines.Count then
      StringGrid1.ColCount:=memo1.Lines.Count+1;
   for i:=0 to memo1.lines.Count-1 do
   begin
   StringGrid1.Cells[i+1,0        ]:='ЗНАЧ.'+INTTOSTR(I);
   StringGrid1.Cells[i+1,form1.row]:=memo1.Lines.Strings[i];
   end;
   StringGrid1.Cells[0,form1.row  ]:='ЭКСП-'+INTTOSTR(FORM1.row);
   StringGrid1.Cells[0,0          ]:='НАЗВ.';
end;

end.

