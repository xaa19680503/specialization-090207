unit Unit5;
{$mode ObjFPC}{$H+}
interface
uses
  comobj, Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls,
  Grids, Menus, Types,unit2;
type
  { TForm5 }
  TForm5 = class(TForm)
    Button2: TButton;      MainMenu1: TMainMenu;
    MenuItem1: TMenuItem;    MenuItem2: TMenuItem;
    StringGrid1: TStringGrid;
    procedure Button1Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure MenuItem2Click(Sender: TObject);
    procedure StringGrid1DrawCell(Sender: TObject; aCol, aRow: Integer;
      aRect: TRect; aState: TGridDrawState);
  private
  public
  end;
var
  Form5: TForm5;
    xl:variant;
implementation
{$R *.lfm}
{ TForm5 }
procedure TForm5.StringGrid1DrawCell(Sender: TObject; aCol, aRow: Integer;
  aRect: TRect; aState: TGridDrawState);
begin
   IF AROW=StringGrid1.RowCount-1 THEN BEGIN
 StringGrid1.Canvas.Brush.Color := CLlime; // назначение цвета ячейки
 StringGrid1.Canvas.FillRect(ARect);      // закрашивание ячейки выбранным цветом
 StringGrid1.Canvas.Font.Color :=clblue; //clnavy; // clWhite; // назначение цвета шрифта
 StringGrid1.Canvas.TextOut(ARect.Left, ARect.Top, StringGrid1.Cells[ACol, ARow]);
  end;
end;
procedure TForm5.Button1Click(Sender: TObject);
VAR J,I:INTEGER;  N:CHAR;
begin  J:=1;
  XL := CreateOleObject('Excel.Application');   // Обьект EXCEL
  // Чтоб не задавал вопрос о сохранении документа
  XL.DisplayAlerts := false;
  XL.WorkBooks.Add;  // новый документ
  // Когда прога уже оттестирована лучше это делать в конце, быстрей работает,
  // а пока нет лучше в начале
  // Левое и правое поля отступа для печати
  XL.WorkBooks[1].WorkSheets[1].PageSetup.LeftMargin := 30;
  XL.WorkBooks[1].WorkSheets[1].PageSetup.RightMargin := 10;
  XL.WorkBooks[1].WorkSheets[1].Name := 'prais ';
  // Даём название страничке
  XL.WorkBooks[1].WorkSheets[1].PageSetup.PrintTitleRows := '$3:$3';
  // Строка появляется на каждом листе при печати
  XL.WorkBooks[1].WorkSheets[1].PageSetup.PrintTitleColumns := '$A:$A';

  for i := 4 to 13 do    // формат числа
    XL.WorkBooks[1].WorkSheets[1].Columns[i].NumberFormat := '0,00';
    XL.WorkBooks[1].WorkSheets[1].Columns[4].NumberFormat := '0,00';

  XL.WorkBooks[1].WorkSheets[1].Columns[1].ColumnWidth := 4.5;
  // Таким способом можно задавать ширину колонки
  XL.WorkBooks[1].WorkSheets[1].Columns[2].ColumnWidth := 50;
  for i := 3 to 13 do
    XL.WorkBooks[1].WorkSheets[1].Columns[i].ColumnWidth := 8;

  XL.WorkBooks[1].WorkSheets[1].Rows[1].Font.Bold := True;  // Шрифт жирный
  XL.WorkBooks[1].WorkSheets[1].Rows[1].Font.Color := clBlack;
  XL.WorkBooks[1].WorkSheets[1].Rows[1].Font.Size := 16;
  XL.WorkBooks[1].WorkSheets[1].Rows[1].Font.Name := 'Times New Roman';
  XL.WorkBooks[1].WorkSheets[1].Cells[1, 4] := 'PRICE LIST';
  XL.WorkBooks[1].WorkSheets[1].Rows[1].VerticalAlignment := 2;
  // Выравнивам по центру по вертикали
  XL.WorkBooks[1].WorkSheets[1].Rows[1].HorizontalAlignment := 3;
  // Выравнивам по центру по горизонтали
  XL.WorkBooks[1].WorkSheets[1].Range['A1:D1'].Merge; // Обьединяем ячейки

  // Выравнивам по центру по вертикали
  XL.WorkBooks[1].WorkSheets[1].Rows[3].VerticalAlignment := 2;
  // Выравнивам по центру по горизонтали
  XL.WorkBooks[1].WorkSheets[1].Rows[3].HorizontalAlignment := 3;
  // Выравнивам по левому краю
  XL.WorkBooks[1].WorkSheets[1].Cells[3, 2].HorizontalAlignment := 2;
  XL.WorkBooks[1].WorkSheets[1].Cells[3, 3].HorizontalAlignment := 2;
  // Выравнивам по правому краю
  XL.WorkBooks[1].WorkSheets[1].Cells[3, 4].HorizontalAlignment := 4;
  XL.WorkBooks[1].WorkSheets[1].Rows[3].Font.Color := clBlack;
  XL.WorkBooks[1].WorkSheets[1].Rows[3].Font.Name := 'Times New Roman';
  XL.WorkBooks[1].WorkSheets[1].Rows[3].Font.Size := 12;
  XL.WorkBooks[1].WorkSheets[1].Rows[3].Font.Bold := True;
  XL.WorkBooks[1].WorkSheets[1].Cells[3, 1] := '№';
  XL.WorkBooks[1].WorkSheets[1].Cells[3, 2] := 'NAME';
  XL.WorkBooks[1].WorkSheets[1].Cells[3, 3] := 'ED. IZM.';

  // обрисовка диапазона ячеек только снизу
  // Borders[1] .... [4] - это края ячейки ColorIndex -4142 - пустой цвет i и n - переменные
  XL.WorkBooks[1].WorkSheets[1].Range['A' + IntToStr(i) + ':' + chr(ord('C') + 1)+ IntToStr(i)].Borders.LineStyle := 1;
  XL.WorkBooks[1].WorkSheets[1].Range['A' + IntToStr(i) + ':' + chr(ord('C') + 2)+ IntToStr(i)].Borders.Weight := 2;
  XL.WorkBooks[1].WorkSheets[1].Range['A' + IntToStr(i) + ':' + chr(ord('C') + 3)+ IntToStr(i)].Borders[4].ColorIndex := 1;
  XL.WorkBooks[1].WorkSheets[1].Range['A' + IntToStr(i) + ':' + chr(ord('C') + 4)+ IntToStr(i)].Borders[1].ColorIndex := -4142;
  XL.WorkBooks[1].WorkSheets[1].Range['A' + IntToStr(i) + ':' + chr(ord('C') + 5)+ IntToStr(i)].Borders[2].ColorIndex := -4142;
  XL.WorkBooks[1].WorkSheets[1].Range['A' + IntToStr(i) + ':' + chr(ord('C') + 6)+ IntToStr(i)].Borders[3].ColorIndex := -4142;

  // обрисовка диапазона ячеек
  XL.WorkBooks[1].WorkSheets[1].Range['A3:' + chr(ord('C') + 1) +IntToStr(i)].Borders.LineStyle := 1;
  XL.WorkBooks[1].WorkSheets[1].Range['A3:' + chr(ord('C') + 2) + IntToStr(i)].Borders.Weight := 2;
  XL.WorkBooks[1].WorkSheets[1].Range['A3:' + chr(ord('C') + 3) +IntToStr(i)].Borders.ColorIndex := 1;

  XL.WorkBooks[1].WorkSheets[1].Cells[i, 7] := 'COUNT';
  // присвоение ячейке значения

  // Поворачивать слова, писать вертикально, под углом и т.д.
  XL.WorkBooks[1].WorkSheets[1].Rows[2].Orientation := 90;
  XL.WorkBooks[1].WorkSheets[1].Range['A2:B2'].Orientation := 0;

  XL.Visible := true;

end;

procedure TForm5.Button2Click(Sender: TObject);
VAR J,I:INTEGER;  N:CHAR;
begin  J:=1;
  XL := CreateOleObject('Excel.Application');   // Обьект EXCEL
  // Чтоб не задавал вопрос о сохранении документа
  XL.DisplayAlerts := false;
  XL.WorkBooks.Add;  // новый документ
for i:=2 to stringgrid1.colcount-5 do //распишим формат  колонок
   XL.WorkBooks[1].WorkSheets[1].Columns[i].NumberFormat := '0,00';
for i:=0 to stringgrid1.colcount-1 do
for j:=0 to stringgrid1.rowcount-1 do
  XL.WorkBooks[1].WorkSheets[1].Cells[j+1, i+1] :=stringgrid1.Cells[i,j];
  XL.Visible := true;
end;

procedure TForm5.MenuItem2Click(Sender: TObject);
VAR s1,s2:string; J,I:INTEGER; r,g:real;
begin  J:=1;
  XL := CreateOleObject('Excel.Application');   // Обьект EXCEL
  // Чтоб не задавал вопрос о сохранении документа
  XL.DisplayAlerts := false;     XL.WorkBooks.Add;  // новый документ

for i:=0 to stringgrid1.colcount-3 do
  begin
   s2:=clear_str(stringgrid1.Cells[i,stringgrid1.rowcount-1]);
    g:=strtofloat(s2)/(stringgrid1.rowcount-1);
for j:=0 to stringgrid1.rowcount-2 do
  begin
  XL.WorkBooks[1].WorkSheets[1].Cells[j+1, i+1] :=stringgrid1.Cells[i,j];
  if j<(stringgrid1.rowcount-2) then continue;
  if i<1 then continue;
  if j<1 then continue;
  XL.WorkBooks[1].WorkSheets[1].Cells[j+1, i+1]:=g;
  end;
  end;
  XL.WorkBooks[1].WorkSheets[1].Cells[stringgrid1.rowcount-1,1]:='sum/N';    XL.Visible := true;
end;


end.
