unit Unit3;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs;

type

  { TForm3 }

  TForm3 = class(TForm)
    procedure FormDestroy(Sender: TObject);
  private

  public

  end;

var
  Form3: TForm3;

implementation
    uses unit1;
{$R *.lfm}

{ TForm3 }

procedure TForm3.FormDestroy(Sender: TObject);
begin
        form1.MenuItem3.Checked:=false;
end;

end.

