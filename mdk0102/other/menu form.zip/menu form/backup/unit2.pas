unit Unit2;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs;

type

  { TForm2 }

  TForm2 = class(TForm)
    procedure FormClose(Sender: TObject; var CloseAction: TCloseAction);

    procedure FormDestroy(Sender: TObject);
  private

  public

  end;

var
  Form2: TForm2;

implementation
uses unit1;
{$R *.lfm}

{ TForm2 }

procedure TForm2.FormClose(Sender: TObject; var CloseAction: TCloseAction);
begin
         form1.MenuItem2.Checked:=false;
end;
procedure TForm2.FormDestroy(Sender: TObject);
begin
    form1.MenuItem2.Checked:=false;
end;

end.

