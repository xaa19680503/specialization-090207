unit Unit1;
{$mode objfpc}{$H+}
interface
uses  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, Menus;
type
  { TForm1 }
  TForm1 = class(TForm)
    MainMenu1: TMainMenu;
    MenuItem1: TMenuItem;
    MenuItem2: TMenuItem;
    MenuItem3: TMenuItem;
    procedure MenuItem2Click(Sender: TObject);
    procedure MenuItem3Click(Sender: TObject);
  private
  public
  end;
var  Form1: TForm1;
implementation
uses Unit2,Unit3;
{$R *.lfm}
{ TForm1 }
procedure TForm1.MenuItem2Click(Sender: TObject);
begin
  if  MenuItem2.Checked=false then
      MenuItem2.Checked:=true else MenuItem2.Checked:=false;
      form2.Visible:=MenuItem2.Checked;
end;

procedure TForm1.MenuItem3Click(Sender: TObject);
begin
   if  MenuItem3.Checked=false then
   MenuItem3.Checked:=true else MenuItem3.Checked:=false;
   form3.Visible:=MenuItem3.Checked;
end;

end.

