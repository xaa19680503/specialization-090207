unit Unit1;
{$mode objfpc}{$H+}
interface
uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, ExtCtrls, StdCtrls,
  ComCtrls, Spin, TAGraph, TAFuncSeries, TASeries, TADrawUtils, TACustomSeries,
  TAMultiSeries;
type
  value_pozition =record
   sum, val_sin,  val_cos, val_tri, val_pil:integer;   //текущее значние
  value: array of real;
  end;
 obr=record
  dx:real;  clk,max:  integer;   q1,q2,q3,q4:boolean;
  val_sin,  val_cos, val_tri, val_pil:real;      //  текущее значние
  tek_sin,  tek_cos, tek_tri, tek_pil:integer;   //  текущий просчет
  max_sin,  max_cos, max_tri, max_pil:integer;   //  диа тормоза
  clk_sin,  clk_cos, clk_tri, clk_pil:integer;   //  счетчики
  lim_sin,  lim_cos, lim_tri, lim_pil:integer;   //   предел счета
  tri_d,    pil_d,   cos_s,   sin_d:array of value_pozition;// масивы значений
 end;
  { TForm1 }
  TForm1 = class(TForm)
    Chart1: TChart;
    Chart1LineSeries1: TLineSeries;    Chart1LineSeries2: TLineSeries;
    Chart1LineSeries3: TLineSeries;     Chart1LineSeries4: TLineSeries;
    Chart1LineSeries5: TLineSeries;     Chart1LineSeries6: TLineSeries;
    CheckGroup1: TCheckGroup;
    FloatSpinEdit1: TFloatSpinEdit;     FloatSpinEdit2: TFloatSpinEdit;
    FloatSpinEdit3: TFloatSpinEdit;
    GroupBox1: TGroupBox; GroupBox2: TGroupBox;
    Label1: TLabel;  Label2: TLabel;
    Label3: TLabel;  Label4: TLabel;   Label5: TLabel;
    PageControl1: TPageControl;  PageControl2: TPageControl;
          Panel1: TPanel;              Panel2: TPanel;
    SpinEdit1: TSpinEdit;    SpinEdit2: TSpinEdit;
    SpinEdit3: TSpinEdit;    SpinEdit4: TSpinEdit;
    SpinEdit5: TSpinEdit;    TabSheet1: TTabSheet;
    TabSheet2: TTabSheet;    TabSheet3: TTabSheet;
    TabSheet4: TTabSheet;       Timer1: TTimer;
    procedure CheckGroup1Click(Sender: TObject);
    procedure CheckGroup1ItemClick(Sender: TObject; Index: integer);
    procedure FloatSpinEdit1Change(Sender: TObject);
    procedure FloatSpinEdit2Change(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure SpinEdit1Change(Sender: TObject);
    procedure SpinEdit2Change(Sender: TObject);
    procedure SpinEdit3Change(Sender: TObject);
    procedure SpinEdit4Change(Sender: TObject);
    procedure SpinEdit5Change(Sender: TObject);
    procedure Timer1Timer(Sender: TObject);
    procedure obr_q1;    procedure obr_q2;     procedure obr_q3;
    procedure obr_q4;    procedure obr_tim;
  private
  public
   obr:obr;
  end;

var  Form1: TForm1;

implementation
{$R *.lfm}
{ TForm1 }

function frm_dx(n,e:double;count:longint):real;
begin  frm_dx:=0; if count>0 then
       frm_dx:=(abs(e)-abs(n))/count;
end;
procedure TForm1.FormCreate(Sender: TObject);
var max,i :integer;
begin
   obr.max:=spinEdit1.Value;
   obr.dx:=frm_dx(FloatSpinEdit1.Value,FloatSpinEdit2.Value,spinEdit1.Value);
   max:= SpinEdit1.value;
   for i:=0  to max do
     chart1lineseries1.AddXY(i,0,inttostr(i),clblue);
   setlength(obr.sin_d,obr.max);
   setlength(obr.cos_s,obr.max);
   setlength(obr.pil_d,obr.max);
   setlength(obr.tri_d,obr.max);
end;

procedure TForm1.CheckGroup1ItemClick(Sender: TObject; Index: integer);
begin
 obr.q1:=CheckGroup1.Checked[0]; if obr.q1=false then Chart1LineSeries2.Clear else
                                  begin obr.max_sin:= SpinEdit1.Value; end;
 obr.q2:=CheckGroup1.Checked[1]; if obr.q2=false then Chart1LineSeries3.Clear else
                                  begin obr.max_cos:= SpinEdit1.Value; end;
 obr.q3:=CheckGroup1.Checked[2]; if obr.q3=false then Chart1LineSeries4.Clear else
                                  begin obr.max_pil:= SpinEdit1.Value; end;
 obr.q4:=CheckGroup1.Checked[3]; if obr.q4=false then Chart1LineSeries5.Clear else
                                  begin obr.max_tri:= SpinEdit1.Value; end;
end;

procedure TForm1.CheckGroup1Click(Sender: TObject);
begin

end;

procedure TForm1.FloatSpinEdit1Change(Sender: TObject);
begin

end;

procedure TForm1.FloatSpinEdit2Change(Sender: TObject);
begin
   obr.dx:=frm_dx(FloatSpinEdit1.Value,FloatSpinEdit2.Value,spinEdit1.Value);
end;



procedure TForm1.SpinEdit1Change(Sender: TObject);
begin
   obr.max:=spinEdit1.Value;
   obr.dx:=frm_dx(FloatSpinEdit1.Value,FloatSpinEdit2.Value,spinEdit1.Value);
end;

procedure TForm1.SpinEdit2Change(Sender: TObject);
begin
     obr.lim_cos:=SpinEdit2.Value;
end;

procedure TForm1.SpinEdit3Change(Sender: TObject);
begin
   obr.lim_sin:=SpinEdit3.Value;
end;

procedure TForm1.SpinEdit4Change(Sender: TObject);
begin
  obr.lim_pil:=SpinEdit4.Value  ;
end;

procedure TForm1.SpinEdit5Change(Sender: TObject);
begin
  obr.lim_tri:=SpinEdit5.Value  ;
end;

procedure tform1.obr_q1;
var i:integer;
begin
   if obr.max<Chart1LineSeries2.Count then Chart1LineSeries2.Clear;
   if  obr.max_sin>obr.clk_sin then  obr.clk_sin:=obr.clk_sin+1
                               else  obr.clk_sin:=0;
         obr.val_sin:=sin(obr.dx*obr.clk_sin);
  if obr.lim_sin=0 then
       begin   Chart1LineSeries2.Add(obr.val_sin); exit; end;
  if obr.tek_sin=0 then
       begin   Chart1LineSeries2.Add(obr.val_sin);       end;
  for i:=1 to obr.lim_sin do
       begin
       if    obr.max_sin> obr.clk_sin then
             obr.clk_sin:=obr.clk_sin+1
       else  obr.clk_sin:=0;
             obr.val_sin:=sin(obr.dx*obr.clk_sin);
             chart1LineSeries2.Add(obr.val_sin); ;
       end;
end;

procedure tform1.obr_q2;
var i:integer;
begin
   if obr.max<Chart1LineSeries3.Count then Chart1LineSeries3.Clear;
   if  obr.max_cos>obr.clk_cos then  obr.clk_cos:=obr.clk_cos+1
                               else  obr.clk_cos:=0;
         obr.val_cos:=cos(obr.dx*obr.clk_cos);
  if obr.lim_cos<1 then
       begin obr.val_cos:=cos(obr.dx*obr.clk_cos);
         Chart1LineSeries3.Add(obr.val_cos); exit; end;
  if obr.tek_cos=0 then
       begin  Chart1LineSeries3.Add(obr.val_cos); end;
  for i:=1 to obr.lim_cos do
       begin
       if   obr.max_cos> obr.clk_cos then
            obr.clk_cos:=obr.clk_cos+1
       else obr.clk_cos:=0;
            obr.val_cos:=cos(obr.dx*obr.clk_cos);
            chart1LineSeries3.Add(obr.val_cos); ;
       end;
end;

procedure tform1.obr_q3;
var i:integer;
begin
   if obr.max<Chart1LineSeries4.Count then Chart1LineSeries4.Clear;
   if  obr.max_pil>obr.clk_pil then  obr.clk_pil:=obr.clk_pil+1
                               else  obr.clk_pil:=0;
     obr.val_pil:=obr.dx*obr.clk_pil;
  if obr.lim_pil =0 then
       begin   Chart1LineSeries4.Add(obr.val_pil); exit; end;
  if obr.tek_pil=0 then
       begin   Chart1LineSeries4.Add(obr.val_pil);       end;
  for i:=1 to obr.lim_pil do
       begin
       if    obr.max_pil> obr.clk_pil then
             obr.clk_pil:=obr.clk_pil+1
       else  obr.clk_pil:=0;
             obr.val_pil:=obr.dx*obr.clk_pil;
             chart1LineSeries4.Add(obr.val_pil);
       end;
end;
/////////////////////////////////////////////////////////////
procedure tform1.obr_q4;
var i:integer;
begin
   if obr.max<Chart1LineSeries5.Count then Chart1LineSeries5.Clear;
   if  obr.max_sin>obr.clk_tri then  obr.clk_tri:=obr.clk_tri+1
                               else  obr.clk_tri:=0;
         obr.val_tri:=(obr.dx*obr.clk_tri);
  if obr.lim_tri=0 then
       begin   Chart1LineSeries5.Add(obr.val_tri); exit; end;
  if obr.tek_tri=0 then
       begin   Chart1LineSeries5.Add(obr.val_tri);       end;
  for i:=1 to obr.lim_tri do
       begin
       if    obr.max_tri> obr.clk_tri then
             obr.clk_tri:=obr.clk_tri+1
       else  obr.clk_tri:=0;
             obr.val_tri:=(obr.dx*obr.clk_tri);
             chart1LineSeries5.Add(obr.val_tri); ;
       end;
end;
/////////////////////////////////////////////////////////////
procedure tform1.obr_tim;
var y:real;
begin             y:=0;  if chart1LineSeries6.Count>obr.max then
                            chart1LineSeries6.Clear;

  if obr.q3 then  y:=y+obr.val_pil;
  if obr.q4 then  y:=y+obr.val_tri;
  if obr.q1 then  if y=0 then y:=y+obr.val_sin else y:=y*obr.val_sin;
  if obr.q2 then  if y=0 then y:=y+obr.val_cos else y:=y*obr.val_cos;
  chart1LineSeries6.Add(y); ;

end;
/////////////////////////////////////////////////////////////
procedure TForm1.Timer1Timer(Sender: TObject);
begin
   if obr.q1 then  obr_q1;
   if obr.q2 then  obr_q2;
   if obr.q3 then  obr_q3;
   if obr.q4 then  obr_q4; obr_tim;
end;

end.

