unit Unit1;
{$mode objfpc}{$H+}
interface
uses
  Classes, SysUtils, DB, dbf, Forms, Controls, Graphics, Dialogs, ExtCtrls,
  StdCtrls, DBGrids, Menus;
type
  { TForm1 }
  TForm1 = class(TForm)
    Button1: TButton;
    Button2: TButton;
    DataSource1: TDataSource;
    Dbf1: TDbf;
    DBGrid1: TDBGrid;
    MainMenu1: TMainMenu;
    MenuItem1: TMenuItem;
    MenuItem2: TMenuItem;
    MenuItem3: TMenuItem;
    Panel1: TPanel;
    procedure Button1Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure MenuItem2Click(Sender: TObject);
    procedure MenuItem3Click(Sender: TObject);
  private

  public

  end;

var
  Form1: TForm1;
implementation
{$R *.lfm}
{ TForm1 }
procedure TForm1.MenuItem2Click(Sender: TObject);
var  NewDBF: TDBF;
Var Info : TSearchRec;         s:string;
begin  s:=ExtractFilePath(ParamStr(0))+'my_tel.dbf';
  if findfirst(s, faAnyFile, Info )=0 then
    begin showmessage('file find ok'); exit; end;
              Dbf1.TableName:=s;
    NewDBF := TDBF.Create(nil);  //создаи обьект
    try    //контроль на ошибку
      NewDBF.TableName := 'my_tel.dbf';  //указали имя
      NewDBF.FieldDefs.Add('name', ftString, 25); //указали поле
      NewDBF.FieldDefs.Add('tel', ftString, 25);  // указали другое поле
      NewDBF.CreateTable; //сохранить базу
    finally   // при завершении
      NewDBF.Free;    //освободить обьект
      MenuItem2.Checked := true;  //укажум галочку
      MenuItem2.Enabled:=false;  //сменим активность окна
      end;
end;

procedure TForm1.Button2Click(Sender: TObject);
begin
  if Dbf1.Active=false then exit;
     dbf1.Delete;
end;

procedure TForm1.FormCreate(Sender: TObject);
begin

end;

procedure TForm1.Button1Click(Sender: TObject);
begin
if Dbf1.Active=false then exit;
Dbf1.Insert;
Dbf1.Post;
end;

 ////////////////////////////////////////////////////////
procedure TForm1.MenuItem3Click(Sender: TObject);
Var Info : TSearchRec;         s:string;
begin  s:=ExtractFilePath(ParamStr(0))+'my_tel.dbf';
  if findfirst(s,   faAnyFile,  Info )=0 then
  begin    Dbf1.TableName:=s;
           Dbf1.Active:=true;;
     MenuItem3.Checked:= true;  //укажум галочку
     MenuItem3.Enabled:=false;   //сменим активность окна
  end;
end;

end.

