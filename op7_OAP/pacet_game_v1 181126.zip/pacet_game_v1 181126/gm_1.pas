unit gm_1;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils;
type
TThr = class(TThread)  //организуем поток
 type
   Tread = function (var x,y:integer; width,height:integer;key_x,key_y:char):string of object;Register;  //TClientResponseFunction
   TError= function (var error:integer; E: Exception):string of object;Register;
protected
  procedure Execute; override;
public

  constructor Create(Port: Integer; rd:Tread  );
  destructor Destroy; override;
end;

implementation

constructor TThr.Create(Port: Integer;rd:Tread );
begin
  inherited Create(False);
end;
destructor TThr.Destroy;
begin
end;
procedure TThr.Execute;
begin  try
    except
    on E: Exception do    begin      Exit;    end;

    end;
end;
end.
