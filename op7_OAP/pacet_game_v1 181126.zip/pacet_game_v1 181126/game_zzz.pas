{ This file was automatically created by Lazarus. Do not edit!
  This source is only used to compile and install the package.
 }

unit game_zzz;

{$warn 5023 off : no warning about unused units}
interface

uses
  Image2, gm_1, LazarusPackageIntf;

implementation

procedure Register;
begin
  RegisterUnit('Image2', @Image2.Register);
end;

initialization
  RegisterPackage('game_zzz', @Register);
end.
