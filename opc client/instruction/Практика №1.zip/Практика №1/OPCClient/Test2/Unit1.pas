unit Unit1;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, FileUtil, Forms, Controls, Graphics, Dialogs, StdCtrls,
		ExtCtrls, OPCClient, uTagList;

type

		{ TForm1 }

  TForm1 = class(TForm)
				Button1 : TButton;
				OPCClient1 : TOPCClient;
				Shape1 : TShape;
				procedure Button1Click(Sender : TObject);
    procedure FormActivate(Sender : TObject);
				procedure FormClose(Sender : TObject; var {%H-}CloseAction : TCloseAction);
				procedure OPCClient1ChangeTag(const Sender : TObject;
						const aTagPosition : TTagPosition; const aTagChange : TTagItem);
  private
    { private declarations }
    TempPos:TTagPosition; {Переменная в памяти ПЛК}
    Out1Pos:TTagPosition; {Выход}
  public
    { public declarations }
  end;

var
  Form1 : TForm1;

implementation

{$R *.lfm}

{ TForm1 }

procedure TForm1.FormActivate(Sender : TObject);
begin
  OPCClient1.Conect;
  Out1Pos := OPCClient1.FindSGroupSTag('Gr1','.Out1');
  TempPos := OPCClient1.FindSGroupSTag('Gr1','.Temp');
end;

procedure TForm1.Button1Click(Sender : TObject);
begin
  OPCClient1.SetTagBoolean(TempPos, not OPCClient1.GetTagBoolean(TempPos));
end;

procedure TForm1.FormClose(Sender : TObject; var CloseAction : TCloseAction);
begin
  OPCClient1.Disconect;
end;

procedure TForm1.OPCClient1ChangeTag(const Sender : TObject;
		const aTagPosition : TTagPosition; const aTagChange : TTagItem);
begin
  if OPCClient1.GetTagBoolean(Out1Pos)
      then Shape1.Brush.Color := clGreen
      else Shape1.Brush.Color := clGray;
end;

end.

