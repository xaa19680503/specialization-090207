{*************************************************
  Редактор и просмотр Тэгов Компонента
  Copyright (C) 2013 Чигрин В.Н. vchigrin@mail.ru
**************************************************}
unit OPCTagListDsg;

{$mode objfpc}{$H+}

interface

uses
  ComponentEditors;

resourcestring
  {пункты всплывающего меню Компонента}
  sMenuItem1 = 'Просмотр значений OPC тэгов';
  sMenuItem2 = 'Редактирование списка OPC тэгов';

  msgCompEdit = 'OPC клиент включен или неуказано его имя,' + {#13#10} LineEnding
                    + 'редактирование НЕВОЗМОЖНО!';
  msgCompView = 'OPC Тэги просмотреть, НЕВОЗМОЖНО' + {#13#10} LineEnding
                    + 'неуказано его имя!';

type

  { TOPCTagListEditor }

  TOPCTagListEditor = class(TComponentEditor)
    function GetVerbCount : Integer; Override;
    function GetVerb(Index : Integer) : String; Override;
    procedure ExecuteVerb(Index : Integer); Override;
    procedure Edit; Override;
  end;

procedure Register;

implementation

uses
  OPCClient, uTagEdit, uViewTag, Controls, Forms, Dialogs, sysutils;

procedure Register;
begin
  RegisterComponentEditor(TOPCClient, TOPCTagListEditor);
end;

{ TOPCTagListEditor }

function TOPCTagListEditor.GetVerbCount : Integer;
begin
  Result := 2;//inherited GetVerbCount;
end;

function TOPCTagListEditor.GetVerb(Index : Integer) : String;
begin
  //Result := inherited GetVerb(Index);
  case Index of
    0  : Result := sMenuItem1;
    1  : Result := sMenuItem2;
  end;
end;

procedure TOPCTagListEditor.ExecuteVerb(Index : Integer);
begin
  //inherited ExecuteVerb(Index);
  case Index of
    0  :  //Просмотр OPC тэгов компонета
        if (Component as TOPCClient).ServerName <> ''
           then
             with TViewTag.Create(Application) do
               try
                 (Component as TOPCClient).Conect;
                  OPCComponent := Component as TOPCClient;
                  ShowModal;
               finally
                 Free;
                 (Component as TOPCClient).Disconect;
               end
           else
             MessageDlg(msgCompView, mtWarning, [mbOK], 0);
    1  ://Редактирование OPC тэгов компонета
        if not ((Component as TOPCClient).Active) and
           ((Component as TOPCClient).ServerName <> '')
          then
            with TTagEdit.Create(Application) do
              try
                OPCComponent := Component as TOPCClient;
                SetTagList;
                if ShowModal = mrOk then
                  begin
                    GetTagList;
                    Modified;
                  end;
              finally
                Free;
              end
          else
            MessageDlg(msgCompEdit, mtWarning, [mbOK], 0);
    end;
end;

procedure TOPCTagListEditor.Edit;
begin
  //inherited Edit;
  ExecuteVerb(0);
end;

end.
