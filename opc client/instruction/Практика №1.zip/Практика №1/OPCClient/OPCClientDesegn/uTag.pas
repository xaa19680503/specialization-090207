{*************************************************
 Окно для редактирования Тэга
 Copyright (C) 2013 Чигрин В.Н. vchigrin@mail.ru
**************************************************}

unit uTag;

{$mode objfpc}{$H+}

interface

uses
  Forms, StdCtrls, ExtCtrls, uTagList;

resourcestring
  rsTag = 'Имя Тэга не уникально!';

type

  { TTagProprty }

  TTagProprty = class(TForm)
    bOk  :     TButton;
    bCancel  : TButton;
    eName  :   TLabeledEdit;
    ePath  :   TLabeledEdit;
    eTyp  :    TLabeledEdit;
    eAcces  :  TLabeledEdit;
    procedure FormCloseQuery(Sender : TObject; var CanClose : boolean);
  public
    { public declarations }
    procedure GetTagProperty(const aTag : TTagItem;
                             const LocList:TTagList; const aGG, aTT:Integer);
    procedure SetTagProperty(const aTag : TTagItem);
  private
    GG, TT:Integer;{Номер Группы(GG) Тэга(TT)}
    LL:TTagList;
  end;


implementation

uses
  Controls, Dialogs, uTagEdit;

{$R *.lfm}

{ TTagProprty }

procedure TTagProprty.FormCloseQuery(Sender : TObject; var CanClose : boolean);
begin
  //CanClose = True - выход!
  CanClose := (ModalResult = mrCancel) or (LL[GG].GetNTagName(eName.Text,TT) = -1);
  if not CanClose then MessageDlg(rsTag, mtInformation, [mbOK], 0);
end;

procedure TTagProprty.GetTagProperty(const aTag : TTagItem;
  const LocList : TTagList; const aGG, aTT : Integer);
begin
  LL := LocList; GG := aGG; TT := aTT;
  {eName - Имя тэга (Название - итправляется)}
  {ePath - Путь к тэгу внутри сервера (Фиксированный)}
  {eTyp - Тип тэга (Фиксированный)}
  {eAcces - Доступ к тэгу (Фиксированный)}
  with aTag do
  begin
    eName.Text  := TagName;
    ePath.Text  := TagPath;
    eTyp.Text   := Value.GetTypName;
    eAcces.Text := StrRight(Access);
  end;
end;

procedure TTagProprty.SetTagProperty(const aTag : TTagItem);
begin
  aTag.SetTagProp(eName.Text, ePath.Text);
end;


end.

