{**************************************************
  Список Тэгов из OPC сервера. Для TTagEdit.
  Copyright (C) 2013 Чигрин В.Н. vchigrin@mail.ru
***************************************************}

unit uOPCTagList;

{$mode objfpc}{$H+}

interface

uses
  Classes, uTagList;

type
  { TOPCTag }

  TOPCTag = class(TObject)
  private
    FNameTag  : string;
    FPathTag  : string;
    FTyp  :     TVarType; {Тип тэга, а не сам тэг}
    FAccess  :  tAccess;  {чтение/запись}
  public
    constructor Create(const aName, aPath : string; const aTyp : TVarType;
      const aAccess : tAccess);
    property NameTag  : string read FNameTag;
    property PathTag  : string read FPathTag;
    property Typ  : TVarType read FTyp; {Тип тэга, а не сам тэг}
    property Access  : tAccess read FAccess; {чтение/запись}
  end;

  { TOPCTagList }

  TOPCTagList = class(TObject)
  private
    ListTag  : TList;
    function GetCount : integer;
    function GetTag(Index : integer) : TOPCTag;
  public
    property Count  : integer read GetCount;
    property TagList[Index  : integer]  : TOPCTag read GetTag;
    constructor Create;
    destructor Destroy; override;
    function AddTag(const aTag : TOPCTag) : integer;
    procedure Clear;
  end;

implementation

uses
  ActiveX;

{ TOPCTag }

constructor TOPCTag.Create(const aName, aPath : string; const aTyp : TVarType;
  const aAccess : tAccess);
begin
  FNameTag := aName;
  FPathTag := aPath;
  FTyp     := aTyp;
  FAccess  := aAccess;
end;

{ TOPCTagList }

function TOPCTagList.GetCount : integer;
begin
  Result := ListTag.Count;
end;

function TOPCTagList.GetTag(Index : integer) : TOPCTag;
begin
  try
    Result := TOPCTag(ListTag[Index]);
  except
    Result := nil;
    raise EListError.CreateFmt(eIndex,[msgGetTag]);
  end;
end;

constructor TOPCTagList.Create;
begin
  ListTag := TList.Create;
end;

destructor TOPCTagList.Destroy;
begin
  Clear;
  ListTag.Free;
end;

function TOPCTagList.AddTag(const aTag : TOPCTag) : integer;
begin
  Result := ListTag.Add(aTag);
end;

procedure TOPCTagList.Clear;
var
  i : integer;
begin
  for i := 0 to ListTag.Count - 1 do
    TOPCTag(ListTag[i]).Free;
  ListTag.Clear;
end;

end.
