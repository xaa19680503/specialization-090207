{*******************************************************************************
  Перечень OPC серверов.

  (Сканируем какие OPC серверы установлены в системе и показываем их перечень)
  Copyright (C) 2013 Чигрин В.Н. vchigrin@mail.ru
********************************************************************************}

unit OPCServName;

{$mode objfpc}{$H+}

interface

uses
  PropEdits, Classes;

type
  {Строка Имени сервера}
  TServerNameProperty = class(TStringProperty)
  public
    function GetAttributes : TPropertyAttributes; override;
    procedure GetValues(Proc : TGetStrProc); override;
    //procedure Edit;override;
  end;

procedure Register;

implementation

uses
{$IFnDEF FPC}
  Windows,
{$ELSE}
  LCLType,
{$ENDIF}
  ActiveX, ComObj, OPCCOMN, OPCDA, OPCClient;

procedure Register;
begin
  RegisterPropertyEditor(TypeInfo(string),
    TOPCClient, 'ServerName', TServerNameProperty);
end;


{ TServerNameProperty }

{procedure TServerNameProperty.Edit;
begin
  inherited;
end;}

function TServerNameProperty.GetAttributes : TPropertyAttributes;
begin
  Result := [{paDialog,} paValueList];
end;

procedure TServerNameProperty.GetValues(Proc : TGetStrProc);
var
  OPCServerList : IOPCServerList;
  AID : array [0..1] of TGUID;
  Buf : TGUID;
  EnumGUID : IEnumGUID;
  n : UINT;
  wProgID, wUserType : WideString;
  pwProgID, pwUserType : PWideChar;
begin
  inherited;
  //
  try
    OPCServerList := CreateComObject(CLSID_OPCServerList) as IOPCServerList;
    AID[0] := CATID_OPCDAServer10;
    AID[1] := CATID_OPCDAServer20;
    if OPCServerList.EnumClassesOfCategories(2, @AID, 0, nil, EnumGUID) = S_OK then
    begin
      wProgID    := '';
      wUserType  := '';
      pwProgID   := PWideChar(wProgID);
      pwUserType := PWideChar(wUserType);
      while EnumGUID.Next(1, Buf, @n) = S_OK do
        if OPCServerList.GetClassDetails(Buf, pwProgID, pwUserType) = S_OK then
          Proc(WideString(pwProgID));
    end;
  except
    //raise EOPCError.Create(msgNoOPC);
    Mes(msgNoOPC);
  end;
end;


end.
