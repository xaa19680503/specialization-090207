{ This file was automatically created by Lazarus. Do not edit!
  This source is only used to compile and install the package.
 }

unit OPCDesignPak;

interface

uses
  uOPCTagList, uGroup, uTag, uTagEdit, uViewTag, OPCTagListDsg, OPCServName, 
  LazarusPackageIntf;

implementation

procedure Register;
begin
  RegisterUnit('OPCTagListDsg', @OPCTagListDsg.Register);
  RegisterUnit('OPCServName', @OPCServName.Register);
end;

initialization
  RegisterPackage('OPCDesignPak', @Register);
end.
