{*************************************************
 Окно для редактирования списка Тэгов
 Copyright (C) 2013 Чигрин В.Н. vchigrin@mail.ru
**************************************************}

unit uTagEdit;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, StdCtrls, Grids, ExtCtrls, ComCtrls,
  uTagList, uOPCTagList, OPCClient, OPCDA;

resourcestring
  {Функция StrRight}
  accRead   = 'Чтение';
  accWrite  = 'Запись';
  accReadWrite = 'Чтение и Запись';
  accNone   = 'Нет прав!!!';
  {TTagEdit.BrowseOPCServer}
  fmtTagString = 'Тэг: %s, Тип:%s, Права: %s';
  fmtDir    = 'Папка: %s';
  errServer = 'Сервер, с таким именем, не найден...';
  fmtRoot   = 'Корень';
  {TTagEdit.GetUnicalNameGroup}
  fmtGtoup  = 'Группа%d';
  rsTag1 = 'Имя Тэга (%s) не уникально!';


const
  sListGroup = 'ListGroup';
  sListTag   = 'ListTag';

type

  { TTagEdit }

  TTagEdit = class(TForm)
    bDownGroup  : TButton;
    Bevel1  :   TBevel;
    bOk  :      TButton;
    bCancel  :  TButton;
    bAddGroup  : TButton;
    bEditGroup  : TButton;
    bDelGroup  : TButton;
    bAddTag  :  TButton;
    bEditTag  : TButton;
    bDelTag  :  TButton;
    bUpTag  :   TButton;
    bDownTag  : TButton;
    bUpGroup  : TButton;
    ListGroup  : TDrawGrid;
    ListTag  :  TDrawGrid;
    SplitterOPC  : TSplitter;
    SplitterGT  : TSplitter;
    tvOPCTags  : TTreeView;
    lListTag  : TLabel;
    lListGroup  : TLabel;
    lListOPC  : TLabel;
    procedure FormActivate(Sender : TObject);
    procedure FormResize(Sender : TObject);
    ///
    procedure bAddGroupClick(Sender : TObject);
    procedure bAddTagClick(Sender : TObject);
    ///
    procedure bDelGroupClick(Sender : TObject);
    procedure bDelTagClick(Sender : TObject);
    ///
    procedure bUpGroupClick(Sender : TObject);
    procedure bUpTagClick(Sender : TObject);
    procedure bDownGroupClick(Sender : TObject);
    procedure bDownTagClick(Sender : TObject);
    ///
    procedure bEditGroupClick(Sender : TObject);
    procedure bEditTagClick(Sender : TObject);
    ///
    procedure ListSelection(Sender : TObject; {%H-}aCol, aRow : integer);
    ///
    procedure ListGroupDrawCell(Sender : TObject; aCol, aRow : integer;
      aRect : TRect; aState : TGridDrawState);
    procedure ListTagDrawCell(Sender : TObject; aCol, aRow : integer;
      aRect : TRect; aState : TGridDrawState);
    procedure ListHeaderSized(Sender : TObject; {%H-}IsColumn : boolean;
      {%H-}Index : integer);
    procedure SplitterGTChangeBounds(Sender : TObject);
    procedure SplitterOPCChangeBounds(Sender : TObject);
  private
    { private declarations }
    LocTagList  : TTagList; {Структура построенная из Групп и Тэгов}
    OPCTagList  : TOPCTagList; {Структура из OPC сервера}
    function GetUnicalNameGroup : string;
    procedure OPCListSetRow;
    ///
    procedure ListSetRow(const Grid : TDrawGrid);
    procedure SelGrid(const Grid : TDrawGrid; const aRow : integer);//Выделить строку
    procedure BrowseOPCServer;
  public
    { public declarations }
    OPCComponent  : TOPCClient;
    constructor Create(AOwner : TComponent); override;
    destructor Destroy; override;
    procedure SetTagList;
    procedure GetTagList;
  end;


function StrRight(const Right : tAccess) : string;

implementation

uses
  Windows, Dialogs, uGroup, uTag, OPCTypes, ComObj, ActiveX, Variants;

{$R *.lfm}

{ TTagEdit }

constructor TTagEdit.Create(AOwner : TComponent);
begin
  inherited Create(AOwner);
  LocTagList := TTagList.Create;
  OPCTagList := TOPCTagList.Create;
end;

destructor TTagEdit.Destroy;
begin
  OPCTagList.Free;
  LocTagList.Free;
  inherited Destroy;
end;

procedure TTagEdit.bAddGroupClick(Sender : TObject);
var
  Gr :     TGroup;
  iGr :    Integer;
begin
  Gr     := TGroup.Create(GetUnicalNameGroup, 500, 0);
  iGr    := ListGroup.Row - 1;
  with TGroupProperty.Create(Self) do
    try
      GetGroupProperty(Gr,LocTagList, -1);
      if ShowModal = mrOk then
        begin
          SetGroupProperty(Gr);
          if iGr < 0 then LocTagList.AddGroup(Gr)
                     else LocTagList.Insert(iGr, Gr);
          SelGrid(ListGroup, iGr + 1);
        end
      else Gr.Free;
    finally
      Free;
    end;
  ListSetRow(ListGroup);
  ListSetRow(ListTag);
end;

procedure TTagEdit.bAddTagClick(Sender : TObject);
var
  i, iRow :  integer;
begin
  iRow := ListTag.Row;
  for i := 0 to tvOPCTags.SelectionCount - 1 do
    if tvOPCTags.Selections[i].Count = 0 then
      with TOPCTag(tvOPCTags.Selections[i].Data) do
        if LocTagList[ListGroup.Row - 1].GetNTagName(NameTag) = -1
          then LocTagList[ListGroup.Row - 1].Insert(iRow + i,
                              TTagItem.Create(NameTag, PathTag, Typ, Access))
          else MessageDlg(Format(rsTag1,[NameTag]), mtInformation, [mbOK], 0);
  ListSetRow(ListTag);
  SelGrid(ListTag, iRow + 1);
end;

procedure TTagEdit.bDelGroupClick(Sender : TObject);
begin
  LocTagList.DeleteGroup(ListGroup.Row - 1);
  ListSetRow(ListGroup);
  ListSetRow(ListTag);
end;

procedure TTagEdit.bDelTagClick(Sender : TObject);
var
  iRow : integer;
begin
  iRow := ListTag.Row;
  LocTagList[ListGroup.Row - 1].DeleteTag(iRow - 1);
  ListSetRow(ListTag);
  SelGrid(ListTag, iRow - 1);
end;

procedure TTagEdit.bUpTagClick(Sender : TObject);
var
  iRow : integer;
begin
  // Поменять местами
  iRow := ListTag.Row;
  LocTagList[ListGroup.Row - 1].Swap(iRow - 1, iRow - 2);
  SelGrid(ListTag, iRow - 1);
  ListTag.Invalidate;
end;

procedure TTagEdit.bDownTagClick(Sender : TObject);
var
  iRow : integer;
begin
  // Поменять местами
  iRow := ListTag.Row;
  LocTagList[ListGroup.Row - 1].Swap(iRow, iRow - 1);
  SelGrid(ListTag, iRow + 1);
  ListTag.Invalidate;
end;

procedure TTagEdit.bEditGroupClick(Sender : TObject);
var
  Gr : TGroup;
begin
  Gr := LocTagList[ListGroup.Row - 1];
  with TGroupProperty.Create(Self) do
    try
      GetGroupProperty(Gr, LocTagList, ListGroup.Row - 1);
      if ShowModal = mrOk then SetGroupProperty(Gr);
    finally
      Free;
    end;
  ListGroup.Invalidate;
end;

procedure TTagEdit.bEditTagClick(Sender : TObject);
var
  myTag :      TTagItem;
begin
  myTag := LocTagList[ListGroup.Row - 1][ListTag.Row - 1];
  with  TTagProprty.Create(Self) do
    try
      GetTagProperty(myTag, LocTagList, ListGroup.Row - 1, ListTag.Row - 1);
      if ShowModal = mrOk then SetTagProperty(myTag);
    finally
      Free;
    end;
  ListTag.Invalidate;
end;

procedure TTagEdit.bUpGroupClick(Sender : TObject);
var
  iRow : integer;
begin
  // Поменять местами
  iRow := ListGroup.Row;
  LocTagList.Swap(iRow - 1, iRow - 2);
  SelGrid(ListGroup, iRow - 1);
  ListGroup.Invalidate;
end;

procedure TTagEdit.bDownGroupClick(Sender : TObject);
var
  iRow : integer;
begin
  // Поменять местами
  iRow := ListGroup.Row;
  LocTagList.Swap(iRow - 1, iRow);
  SelGrid(ListGroup, iRow + 1);
  ListGroup.Invalidate;
end;

procedure TTagEdit.FormActivate(Sender : TObject);
begin
  FormResize(Self);
  ListSetRow(ListGroup);
end;

procedure TTagEdit.FormResize(Sender : TObject);
begin
  {tvOPCTags - дерево OPC}
  {ListGroup - таблица групп}
  {ListTag - таблица Тэгов}
  SplitterGTChangeBounds(nil);
  SplitterOPCChangeBounds(nil);
  ListHeaderSized(ListGroup, False, -1);
  ListHeaderSized(ListTag, False, -1);
end;

procedure TTagEdit.ListHeaderSized(Sender : TObject; IsColumn : boolean;
  Index : integer);
var
  i, Co :     integer;
  flag :  boolean;
  W, WR : integer; // Ширина таблицы списка групп
begin
  with Sender as TDrawGrid do
    begin
      W := Width - 20; Co := 0;
      repeat
        WR := 0; Inc(Co);
        for i := 0 to ColCount - 1 do WR += ColWidths[i];
        flag := True;
        for i := 0 to ColCount - 1 do
          if WR <> 0.0 then
            ColWidths[i] := round(ColWidths[i] / WR * W);
        //
        for i := 0 to ColCount - 1 do
          with Columns[i] do
            if Width < MinSize then
              begin
                Width := MinSize;
                flag  := False;
              end;
      until flag or (Co > 20);
    end;
end;

procedure TTagEdit.ListGroupDrawCell(Sender : TObject; aCol, aRow : integer;
  aRect : TRect; aState : TGridDrawState);
var
  myGroup : TGroup;
begin
  if not (gdFixed in aState) then
    with Sender as TDrawGrid do
      if Assigned(LocTagList) then
        begin
          myGroup := LocTagList[aRow - 1];
          if Assigned(myGroup) then
            with Canvas, aRect, myGroup do
              case aCol of
                0  : TextOut(Left + 3, Top + 3, GroopName);
                1  : TextOut(Left + 3, Top + 3, IntToStr(UpdateRate));
                2  : TextOut(Left + 3, Top + 3, FloatToStr(PercentDeadBand));
              end;
        end;
end;

procedure TTagEdit.ListSelection(Sender : TObject; aCol, aRow : integer);
var
  EnUp, EnDn : boolean;
begin
  EnUp := (aRow > 1);
  if (Sender as TComponent).Name = sListGroup then
    begin
      ListSetRow(ListTag);
      EnDn := (aRow < LocTagList.Count);
      bUpGroup.Enabled := EnUp;
      bDownGroup.Enabled := EnDn;
    end;
  if (Sender as TComponent).Name = sListTag then
    begin
      if LocTagList.Count <> 0 then
          EnDn := (aRow < LocTagList[ListGroup.Row - 1].Count)
        else
          EnDn := False;
      bUpTag.Enabled := EnUp;
      bDownTag.Enabled := EnDn;
    end;
end;

procedure TTagEdit.ListTagDrawCell(Sender : TObject; aCol, aRow : integer;
  aRect : TRect; aState : TGridDrawState);
var
  myTag : TTagItem;
begin
  if not (gdFixed in aState) then
    with Sender as TDrawGrid do
      if (ListGroup.Row > 0) and (LocTagList[ListGroup.Row - 1].Count > 0) then
        begin
          myTag := LocTagList[ListGroup.Row - 1][aRow - 1];
          if Assigned(myTag) then
            with Canvas, aRect, myTag do
              case aCol of
                0  : TextOut(Left + 3, Top + 3, TagName);
                1  : TextOut(Left + 3, Top + 3, TagPath);
                2  : TextOut(Left + 3, Top + 3, Value.GetTypName);
                3  : TextOut(Left + 3, Top + 3, StrRight(Access));
              end;
        end;
end;

procedure TTagEdit.SplitterGTChangeBounds(Sender : TObject);
const
  SLeft = 8; //Положение Сплитера от ListGroup
  MinListGroupWidth = 256 + SLeft; //
  MinListTagWidth = 313 + SLeft + 3; //
var
  WW : integer;
begin
  if SplitterGT.Left < MinListGroupWidth then SplitterGT.Left := MinListGroupWidth;
  WW := Width - MinListTagWidth;
  if SplitterGT.Left > WW then SplitterGT.Left := WW;
  ListHeaderSized(ListGroup, False, -1);
  ListHeaderSized(ListTag, False, -1);
end;

procedure TTagEdit.SplitterOPCChangeBounds(Sender : TObject);
const
  MinListOPCTag = 23 + 160;
  MaxListOPCTag = 200;
var
  WW : integer;
begin
  if SplitterOPC.Top < MinListOPCTag then SplitterOPC.Top := MinListOPCTag;
  WW := Height - MaxListOPCTag;
  if SplitterOPC.Top > WW then SplitterOPC.Top := WW;
end;

procedure TTagEdit.BrowseOPCServer;
var
  Server : TGUID;
  B :      IOPCBrowseServerAddressSpace;
  ItProp : IOPCItemProperties;
  Ser :    IOPCServer;
  SS :     OPCNAMESPACETYPE; {Это Integer}
  Node :   TTreeNode;

  procedure BrowseLin(var Node : TTreeNode);
  var
    R :     HRESULT;
    S, S1 : POleStr;
    L :     longint;
    pEnum : IEnumString;
    Co :    cardinal;
    PropertyIDs : PDWORDARRAY;
    Descriptions : POleStrList;
    vtDataTypes : PVarTypeList;
    mOPC :  TOPCTag;
    v :     POleVariantArray;
    err :   PResultList;
    myTyp : TVarType;

    function GetPropNum(const Num : cardinal) : OleVariant;
    var
      i : integer;
    begin
      Result := 0;
      for i := 0 to Co - 1 do
        if (err^[i] = S_OK) and (PropertyIDs^[i] = Num) then
        begin
          Result := v^[i];
          Break;
        end;
    end;

  begin
    //Для тегов
    R := B.BrowseOPCItemIDs(OPC_LEAF, '', VT_EMPTY, 0, pEnum);
    if not Failed(R) then
    begin
      pEnum.Next(1, S, ULong(L));
      while L <> 0 do
      begin
        B.GetItemID(S, S1);
        ///////////////////////////////////////////////////////////////////////////
        //OutputDebugString(PChar(Format('Name Item :%s', [S1])));
        ItProp.QueryAvailableProperties(S1, Co, PropertyIDs, Descriptions, vtDataTypes);
        try
          ItProp.GetItemProperties(S1, Co, PropertyIDs, v, err);
          try
            // S - Имя тэга
            // S1 - Путь (Расположение тэга в OPC - сервере)
            // GetPropNum(1) - Тип OPC тэга  (OPC_PROPERTY_DATATYPE)
            // GetPropNum(5) - Доступ до тэга (OPC_PROPERTY_ACCESS_RIGHTS)
            // GetPropNum(2) - Значение тэга (OPC_PROPERTY_VALUE)

          (*OutputDebugString(PChar(Format('Тэг %s: Количество %d',[S1,Co])));
          for i:=0 to Co - 1 do
            OutputDebugString(PChar(Format('-- %s',[VarToStr(GetPropNum(i))])));
          *)
            myTyp := GetPropNum(OPC_PROPERTY_DATATYPE);
            if myTyp in [VT_BOOL, VT_I2, VT_I4, VT_I1, VT_I8,
              VT_UI1, VT_UI2, VT_UI4, VT_UI8, VT_UINT, VT_INT, VT_CY, VT_R4,
              VT_R8, VT_DATE, VT_BSTR, VT_LPSTR, VT_LPWSTR]
            //Здесь ограничивается тип отображаемых Тэгов
            then
            begin
              mOPC := TOPCTag.Create(S, S1, myTyp, GetPropNum(OPC_PROPERTY_ACCESS_RIGHTS));
              OPCTagList.AddTag(mOPC);
              tvOPCTags.Items.AddChildObject(Node,
                Format(fmtTagString, [mOPC.NameTag, VarTypeAsText(mOPC.Typ),
                StrRight(mOPC.Access)]), mOPC);
            end;
          finally
            CoTaskMemFree(v);
            CoTaskMemFree(err);
          end;
        finally
          CoTaskMemFree(PropertyIDs);
          CoTaskMemFree(Descriptions);
          CoTaskMemFree(vtDataTypes);
        end;
        pEnum.Next(1, S, ULong(L));
      end;
    end;
    pEnum := nil;
  end;

  procedure BrowseDir(var Node : TTreeNode);
  var
    R :     HRESULT;
    S :     POleStr;
    L :     longint;
    pEnum : IEnumString;
    Node1 : TTreeNode;
    //
  begin
    //Для Папок
    R := B.BrowseOPCItemIDs(OPC_BRANCH, '', VT_EMPTY, 0, pEnum);
    if not Failed(R) then
    begin
      pEnum.Next(1, S, ULong(L));
      while L <> 0 do
      begin
        Node1 := tvOPCTags.Items.AddChild(Node, Format(fmtDir, [S]));
        Node1.ImageIndex := 1;
        Node1.SelectedIndex := 2;
        B.ChangeBrowsePosition(OPC_BROWSE_DOWN, S);
        BrowseDir(Node1);
        B.ChangeBrowsePosition(OPC_BROWSE_UP, '');
        pEnum.Next(1, S, ULong(L));
      end;
    end;
    pEnum := nil;
    //Для тегов
    BrowseLin(Node);
  end;

begin
  tvOPCTags.Items.Clear;
  if not Assigned(OPCComponent) then
    Exit;
  if OPCComponent.ServerName <> '' then
  begin
    try
      Server := ProgIDToClassID(OPCComponent.ServerName);
    except
      on EOleSysError do
        raise EOPCError.Create(errServer);
    end;
    Ser := CreateComObject(Server) as IOPCServer;
    try
      if Ser = nil then
        Exit;
      Ser.QueryInterface(IID_IOPCBrowseServerAddressSpace, B);
      try
        Ser.QueryInterface(IID_IOPCItemProperties, ItProp);
        try
          B.ChangeBrowsePosition(OPC_BROWSE_TO, '');
          tvOPCTags.Items.BeginUpdate;
          Node := tvOPCTags.Items.Add(nil, fmtRoot);
          Node.ImageIndex := 1;
          Node.SelectedIndex := 2;
          B.QueryOrganization(SS);
          if SS = OPC_NS_HIERARCHIAL then
            BrowseDir(Node)
          else
            BrowseLin(Node);
          tvOPCTags.Items.EndUpdate;
        finally
          B := nil;
        end;
      finally
        ItProp := nil;
      end;
    finally
      Ser := nil;
    end;
  end;
end;

function TTagEdit.GetUnicalNameGroup : string;
var
  i, n : integer;
  flag : boolean;
begin
  n := 1;
  repeat
    Result := Format(fmtGtoup, [n]);
    flag   := True;
    for i := 0 to LocTagList.Count - 1 do
      if LocTagList[i].GroopName = Result then flag := False;
    Inc(n);
  until flag;
end;

procedure TTagEdit.OPCListSetRow;
begin
  tvOPCTags.Invalidate;
  bAddTag.Enabled := OPCTagList.Count > 0;
end;

procedure TTagEdit.ListSetRow(const Grid : TDrawGrid);
var
  RowGroup, ListTagRowCount : integer;
  En : boolean;
begin
  if Grid.Name = sListGroup then
    begin
      ListGroup.RowCount := LocTagList.Count + 1;
      En := LocTagList.Count > 0;
      bEditGroup.Enabled := En;
      bDelGroup.Enabled := En;
      bAddTag.Enabled := En;
    end;
  if Grid.Name = sListTag then
    begin
      ListTagRowCount := 1;
      RowGroup := ListGroup.Row - 1;
      if (RowGroup >= 0) and (RowGroup < LocTagList.Count) then
        ListTagRowCount := LocTagList[RowGroup].Count + 1;
      ListTag.RowCount  := ListTagRowCount;
      if LocTagList.Count > 0 then
        En := LocTagList[RowGroup].Count > 0
      else
        En := False;
      bEditTag.Enabled := En;
      bDelTag.Enabled := En;
    end;
  Grid.Invalidate;
  ListSelection(Grid, 0, Grid.Row);
end;

procedure TTagEdit.SelGrid(const Grid : TDrawGrid; const aRow : integer);
var
  SRect : TGridRect;
begin
  with SRect do
    begin
      Top    := aRow;
      Bottom := aRow;
    end;
  with Grid do
    begin
      SetFocus;
      Row := aRow;
      Selection := SRect;
    end;
end;

procedure TTagEdit.SetTagList;
begin
  if Assigned(OPCComponent) then
    begin
      BrowseOPCServer;
      LocTagList.Assign(OPCComponent.TagList);
    end;
  OPCListSetRow;
  ListSetRow(ListGroup);
  ListSetRow(ListTag);
end;

procedure TTagEdit.GetTagList;
begin
  if Assigned(OPCComponent) then OPCComponent.TagList.Assign(LocTagList);
end;

function StrRight(const Right : tAccess) : string;
begin
  case Right of
      acRead  : Result      := accRead;
      acWrite  : Result     := accWrite;
      acReadWrite  : Result := accReadWrite;
    else
      Result := accNone;
  end;
end;

end.
