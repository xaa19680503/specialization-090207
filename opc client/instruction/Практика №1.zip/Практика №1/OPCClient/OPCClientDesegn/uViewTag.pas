{*************************************************
 Окно для просмотра значений Тэгов
 Copyright (C) 2013 Чигрин В.Н. vchigrin@mail.ru
**************************************************}

unit uViewTag;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Graphics, Grids, ExtCtrls, StdCtrls, OPCClient;

type

  { TViewTag }

  TViewTag = class(TForm)
    bOk  :     TButton;
    ListTag  : TDrawGrid;
    Timer  :   TTimer;
    procedure FormActivate(Sender : TObject);
    procedure FormDestroy(Sender : TObject);
    procedure FormResize(Sender : TObject);
    procedure ListTagDrawCell(Sender : TObject; aCol, aRow : integer;
      aRect : TRect; aState : TGridDrawState);
    procedure ListTagHeaderSized(Sender : TObject; IsColumn : boolean;
      Index : integer);
    procedure TimerTimer(Sender : TObject);
  private
    { private declarations }
    ListItems  : array of TObject;
  public
    { public declarations }
    OPCComponent  : TOPCClient;
  end;


implementation

uses
  uTagList, Windows;

{$R *.lfm}

{ TViewTag }

procedure TViewTag.FormResize(Sender : TObject);
begin
  ListTagHeaderSized(ListTag, False, -1);
end;

procedure TViewTag.ListTagDrawCell(Sender : TObject; aCol, aRow : integer;
  aRect : TRect; aState : TGridDrawState);
begin
  if not (gdFixed in aState) then
    with (Sender as TDrawGrid), aRect, Canvas do
      if Length(ListItems) <> 0 then
        case aCol of
          0 : begin
                if (ListItems[aRow - 1] is TGroup) then
                  begin
                    Font.Style := Font.Style + [fsBold];
                    TextOut(Left + 3, Top + 3,
                            IntToStr((ListItems[aRow - 1] as TGroup).hSGroup));
                  end;
                if (ListItems[aRow - 1] is TTagItem) then
                  TextOut(Left + 3, Top + 3,
                          IntToStr((ListItems[aRow - 1] as TTagItem).hClient));
              end;
          1 : begin
                if (ListItems[aRow - 1] is TGroup) then
                  begin
                    Font.Style := Font.Style + [fsBold];
                    TextOut(Left + 3, Top + 3,
                           (ListItems[aRow - 1] as TGroup).GroopName);
                  end;
                if (ListItems[aRow - 1] is TTagItem) then
                  TextOut(Left + 3, Top + 3,
                         (ListItems[aRow - 1] as TTagItem).TagName);
              end;
          2  : if (ListItems[aRow - 1] is TTagItem) then
                  TextOut(Left + 3, Top + 3,
                         (ListItems[aRow - 1] as TTagItem).Value.GetTypName);
          3  : if (ListItems[aRow - 1] is TTagItem) then
                  TextOut(Left + 3, Top + 3,
                         (ListItems[aRow - 1] as TTagItem).TagPath);
          4  : if (ListItems[aRow - 1] is TTagItem) then
                  TextOut(Left + 3, Top + 3,
                         (ListItems[aRow - 1] as TTagItem).GetValueAsString);
          5  : if (ListItems[aRow - 1] is TTagItem) then
                  TextOut(Left + 3, Top + 3,
                         (ListItems[aRow - 1] as TTagItem).GetQualitySrting);
          6  : if (ListItems[aRow - 1] is TTagItem) then
                  TextOut(Left + 3, Top + 3,
                         (ListItems[aRow - 1] as TTagItem).GetErrorSrting);
        end;
end;

procedure TViewTag.ListTagHeaderSized(Sender : TObject; IsColumn : boolean;
  Index : integer);
var
  i, Co :     integer;
  flag :  boolean;
  W, WR : integer; // Ширина таблицы списка групп
begin
  with Sender as TDrawGrid do
    begin
      W := Width - 20; Co := 0;
      repeat
        WR := 0; inc(Co);
        for i := 0 to ColCount - 1 do
          WR += ColWidths[i];
        flag := True;
        for i := 0 to ColCount - 1 do
          if WR <> 0.0 then
            ColWidths[i] := round(ColWidths[i] / WR * W);
        //
        for i := 0 to ColCount - 1 do
          with Columns[i] do
            if Width < MinSize then
            begin
              Width := MinSize;
              flag  := False;
            end;
      until flag or (Co > 20);
    end;
end;

procedure TViewTag.TimerTimer(Sender : TObject);
begin
  ListTag.Invalidate;
end;

procedure TViewTag.FormActivate(Sender : TObject);
var
  i, j, RowCount : integer;
begin
  if Assigned(OPCComponent) then
  begin
    RowCount := 1;
    with (OPCComponent as TOPCClient) do
      begin
        RowCount += TagList.Count;
        for i := 0 to TagList.Count - 1 do RowCount += TagList[i].Count;
      end;
    ListTag.RowCount := RowCount;
    SetLength(ListItems, RowCount - 1);
    RowCount := 0;
    with (OPCComponent as TOPCClient) do
      for i := 0 to TagList.Count - 1 do
        begin
          ListItems[RowCount] := TagList[i];
          Inc(RowCount);
          for j := 0 to TagList[i].Count - 1 do
            begin
              ListItems[RowCount] := TagList[i][j];
              Inc(RowCount);
            end;
        end;
  end;
end;

procedure TViewTag.FormDestroy(Sender : TObject);
begin
  SetLength(ListItems, 0);
end;

end.
