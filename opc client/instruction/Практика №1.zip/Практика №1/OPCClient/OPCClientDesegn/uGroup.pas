{*************************************************
 Окно для редактирования Группы
 Copyright (C) 2013 Чигрин В.Н. vchigrin@mail.ru
**************************************************}

unit uGroup;

{$mode objfpc}{$H+}

interface

uses
  Forms, StdCtrls, ExtCtrls, uTagList;

resourcestring
  rsGroup = 'Имя Группы не уникально!';

const
  UR  = 'eUpdateRate';
  PDB = 'ePercDeadBand';

type

  { TGroupProperty }

  TGroupProperty = class(TForm)
    bOk  :     TButton;
    bCancel  : TButton;
    eName  :   TLabeledEdit;
    eUpdateRate  : TLabeledEdit;
    ePercDeadBand  : TLabeledEdit;
    procedure eKeyPress(Sender : TObject; var Key : char);
    procedure FormCloseQuery(Sender : TObject; var CanClose : boolean);
  public
    procedure GetGroupProperty(const aGroup : TGroup;
                            const LocList:TTagList; const iCur:Integer);
    procedure SetGroupProperty(const aGroup : TGroup);
  private
    i:Integer;{Номер Группы}
    LL:TTagList;
  end;


implementation

uses
  SysUtils, Classes, Dialogs, Controls;

{$R *.lfm}

{ TGroupProperty }

procedure TGroupProperty.eKeyPress(Sender : TObject; var Key : char);
var
  CharSet : set of char;
begin
  CharSet := ['0'..'9', #8];
  if (Sender as TComponent).Name = PDB then
    Include(CharSet, '.');
  if not (Key in CharSet) then
    Key := #0;
end;

procedure TGroupProperty.FormCloseQuery(Sender : TObject; var CanClose : boolean);
begin
  //CanClose = True - выход!
  CanClose := (ModalResult = mrCancel) or (LL.GetNGroupName(eName.Text,i) = -1);
  if not CanClose then MessageDlg(rsGroup, mtInformation, [mbOK], 0); ;
end;

procedure TGroupProperty.GetGroupProperty(const aGroup : TGroup;
                        const LocList:TTagList; const iCur:Integer);
var
  Sign : TFormatSettings;
begin
  LL := LocList; i := iCur;
  //myGr:= aGroup;
  eName.Text := aGroup.GroopName;
  eUpdateRate.Text := IntToStr(aGroup.UpdateRate);
  Sign.DecimalSeparator := '.';
  ePercDeadBand.Text := FloatToStr(aGroup.PercentDeadBand, Sign);
end;

procedure TGroupProperty.SetGroupProperty(const aGroup : TGroup);
var
  aUpdateRate : integer;
  aPercDeadBand : single;
  Sign : TFormatSettings;
begin
  Sign.DecimalSeparator := '.';
  try
    aUpdateRate := StrToInt(eUpdateRate.Text);
  except
    on EConvertError do
      aUpdateRate := 500;
  end;
  try
    aPercDeadBand := StrToFloat(ePercDeadBand.Text, Sign);
  except
    on EConvertError do
      aPercDeadBand := 0.0;
  end;
  aGroup.SetGrooupProp(eName.Text, aUpdateRate, aPercDeadBand);
end;

end.
