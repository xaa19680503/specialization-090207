unit Unit1;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, FileUtil, Forms, Controls, Graphics, Dialogs, StdCtrls,
  OPCClient, uTagList;

type

  { TForm1 }

  TForm1 = class(TForm)
    Edit1 : TEdit;
    Edit2 : TEdit;
    Edit3 : TEdit;
    Edit4 : TEdit;
    OPCClient1 : TOPCClient;
    procedure FormActivate(Sender : TObject);
    procedure FormClose(Sender : TObject; var CloseAction : TCloseAction);
    procedure OPCClient1ChangeTag(const Sender : TObject;
      const aTagPosition : TTagPosition; const aTagChange : TTagItem);
  private
    { private declarations }
    StringPos:TTagPosition;
    BooleanPos:TTagPosition;
    Int1Pos:TTagPosition;
    MoneyPos:TTagPosition;
  public
    { public declarations }
  end;

var
  Form1 : TForm1;

implementation

{$R *.lfm}

{ TForm1 }

procedure TForm1.FormClose(Sender : TObject; var CloseAction : TCloseAction);
begin
  OPCClient1.Disconect;
end;

procedure TForm1.OPCClient1ChangeTag(const Sender : TObject;
  const aTagPosition : TTagPosition; const aTagChange : TTagItem);
begin
  if aTagPosition = BooleanPos then
    begin
      if OPCClient1.GetTagBoolean(BooleanPos)
         then Edit1.Caption := 'Истина'
         else Edit1.Caption := 'Ложь';
      Exit;
    end {else Edit1.Caption := '-1';};
  if aTagPosition = StringPos then
    begin
      Edit2.Caption := OPCClient1.GetTagString(StringPos);
      Exit;
    end;
  if aTagPosition = Int1Pos then
    begin
      Edit3.Caption := IntToStr(OPCClient1.GetTagShortInt(Int1Pos));
      Exit;
    end;
  if aTagPosition = MoneyPos then
    begin
      Edit4.Caption := FloatToStr(OPCClient1.GetTagCurrency(MoneyPos));
      Exit;
    end;
end;

procedure TForm1.FormActivate(Sender : TObject);
begin
  OPCClient1.Conect;
  StringPos  := OPCClient1.FindSGroupSTag('Группа','String');
  BooleanPos := OPCClient1.FindSGroupSTag('Группа','Boolean');//BooleanPos.NGroup := -1;
  Int1Pos    := OPCClient1.FindSGroupSTag('Группа','Int1');
  MoneyPos   := OPCClient1.FindSGroupSTag('Группа','Money');
end;

end.

