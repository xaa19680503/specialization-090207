{ This file was automatically created by Lazarus. Do not edit!
  This source is only used to compile and install the package.
 }

unit OPCClientPak;

interface

uses
  uValue, uTagList, OPCCallback, OPCClient, LazarusPackageIntf;

implementation

procedure Register;
begin
  RegisterUnit('OPCClient', @OPCClient.Register);
end;

initialization
  RegisterPackage('OPCClientPak', @Register);
end.
