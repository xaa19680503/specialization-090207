unit Unit2;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls, LazHelpHTML,
  LazHelpCHM;

type

  { TForm2 }

  TForm2 = class(TForm)
    Button1: TButton;
    CHMHelpDatabase1: TCHMHelpDatabase;
    Label1: TLabel;
    Label2: TLabel;
    Label3: TLabel;
    Label4: TLabel;
    LHelpConnector1: TLHelpConnector;
    procedure Button1Click(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure  LaunchHelp;
  private

  public

  end;

var
  Form2: TForm2;

implementation
  uses UTF8Process;
{$R *.lfm}

{ TForm2 }
 

procedure TForm2.LaunchHelp;
{launches the help file}
var
  AProcess: TProcessUTF8;
begin
  try
    AProcess := TProcessUTF8.Create(nil);
    AProcess.CommandLine := 'hh.exe' + ' "' + Application.HelpFile + '"';
    AProcess.Execute;
    AProcess.Free;
  except
    MessageDlg('Проблема с открытием CHM-файла',mtError,[mbOK],0);
  end;
end;
procedure TForm2.FormCreate(Sender: TObject);
begin
    BiDiMode := bdLeftToRight;
  Application.HelpFile := ExtractFilePath(ParamStr(0)) + 'for html.chm';
end;

procedure TForm2.Button1Click(Sender: TObject);
begin
    LaunchHelp;
end;

end.

