unit Unit1;
{$mode objfpc}{$H+}
interface
uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, Menus, ExtCtrls, Spin,
  StdCtrls, OPCClient, uTagList;
type
  { TForm1 }
  TForm1 = class(TForm)
    CheckGroup1: TCheckGroup;
    CheckGroup2: TCheckGroup;
    Edit1: TEdit;
    Edit2: TEdit;
    Edit3: TEdit;
    MainMenu1: TMainMenu;
    MenuItem1: TMenuItem;
    MenuItem2: TMenuItem;
    OPCClient1: TOPCClient;
    procedure Button1Click(Sender: TObject);
    procedure CheckGroup1Click(Sender: TObject);
    procedure CheckGroup2ChangeBounds(Sender: TObject);
    procedure CheckGroup2Click(Sender: TObject);
    procedure CheckGroup2ItemClick(Sender: TObject; Index: integer);
    procedure CheckGroup2SizeConstraintsChange(Sender: TObject);
    procedure Edit1Change(Sender: TObject);
    procedure Edit2Change(Sender: TObject);
    procedure Edit3Change(Sender: TObject);
    procedure FormClose(Sender: TObject; var CloseAction: TCloseAction);

    procedure MenuItem2Click(Sender: TObject);
    procedure OPCClient1ChangeTag(const Sender: TObject;
      const aTagPosition: TTagPosition; const aTagChange: TTagItem);
  private

  public
    TempPos:TTagPosition; {Переменная в памяти ПЛК}
  end;
var
  Form1: TForm1;
implementation
{$R *.lfm}
{ TForm1 }
   procedure save_str(e:string);
var s,s0,s1:string;    d:tstringlist;
begin  d:=tstringlist.create();  d.Add('<dialog open>');
  d.Add(e);
     d.Add('</dialog>');
   d.SaveToFile('C:\OSPanel\home\aax1-2\public\s.html');
   d.Free;
end;
procedure save_inp(e:word);
var s,s0,s1:string;    d:tstringlist;
begin  d:=tstringlist.create();  d.Add('<dialog open>');
      s0:='<a><input type="checkbox" disabled checked> выход ';
      s1:='<a><input type="checkbox" disabled> вход ';s:=' 1 </a>';
   if((e and 1)=1   ) then  d.add(s0+s)else d.add(s1+s);s:=' 2 </a>';
   if((e and 2)=2   ) then  d.add(s0+s)else d.add(s1+s);s:=' 3 </a>';
   if((e and 4)=4   ) then d.add(s0+s)else d.add(s1+s); s:=' 4 </a>';
   if((e and 8)=8   ) then d.add(s0+s)else d.add(s1+s); s:=' 5 </a>';
   if((e and 16)=16 ) then d.add(s0+s)else d.add(s1+s);s:=' 6 </a>';
   if((e and 32)=32 ) then d.add(s0+s)else d.add(s1+s); s:='7</a>';
   if((e and 64)=64 ) then d.add(s0+s)else d.add(s1+s); s:='8 </a>';
   if((e and 128)=128)then  d.add(s0+s)else d.add(s1+s);
     d.Add('</dialog>');
   d.SaveToFile('C:\OSPanel\home\aax1-2\public\b.html');
   d.Free;
end;
procedure save_out(e:word);
var s,s0,s1:string;  d:tstringlist;
begin  d:=tstringlist.create();  d.Add('<dialog open>');
      s0:='<a><input type="checkbox" disabled checked> выход ';
      s1:='<a><input type="checkbox" disabled> выход ';    s:=' 1 </a>';
   if ((e and 1)=1 )   then  d.add(s0+s)else d.add(s1+s); s:=' 2 </a>';
   if ((e and 2)=2 )   then  d.add(s0+s)else d.add(s1+s); s:=' 3 </a>';
   if ((e and 4)=4 )   then d.add(s0+s)else d.add(s1+s);  s:=' 4 </a>';
   if ((e and 8)=8 )   then d.add(s0+s)else d.add(s1+s);  s:=' 5 </a>';
   if ((e and 16)=16 ) then d.add(s0+s)else d.add(s1+s);  s:=' 6 </a>';
   if ((e and 32)=32 ) then d.add(s0+s)else d.add(s1+s);  s:=' 7 </a>';
   if ((e and 64)=64 ) then d.add(s0+s)else d.add(s1+s);  s:=' 8 </a>';
   if ((e and 128)=128 ) then  d.add(s0+s)else d.add(s1+s);
     d.Add('</dialog>');
   d.SaveToFile('C:\OSPanel\home\aax1-2\public\a.html');
    d.Free;
end;

procedure TForm1.CheckGroup1Click(Sender: TObject);
begin

end;

procedure TForm1.Button1Click(Sender: TObject);
begin
end;

procedure TForm1.CheckGroup2ChangeBounds(Sender: TObject);
begin
end;

procedure TForm1.CheckGroup2Click(Sender: TObject);
begin
end;

procedure TForm1.CheckGroup2ItemClick(Sender: TObject; Index: integer);
var e:word;
begin   e:=0;
     if CheckGroup2.Checked[0] then e:=e+1;
     if CheckGroup2.Checked[1] then e:=e+2;
     if CheckGroup2.Checked[2] then e:=e+4;
     if CheckGroup2.Checked[3] then e:=e+8;
     if CheckGroup2.Checked[4] then e:=e+16;
     OPCClient1.SetTagWord(TempPos, e);
end;

procedure TForm1.CheckGroup2SizeConstraintsChange(Sender: TObject);

begin

end;

procedure TForm1.Edit1Change(Sender: TObject);
var e:word;
begin
   e:=OPCClient1.TagList.GroopList[0].ItList[0].Value.GetVT_UI2;
   if ((e and 1)=1 ) then
      CheckGroup1.Checked[0]:=true else checkGroup1.Checked[0]:=false;
   if ((e and 2)=2 ) then
      CheckGroup1.Checked[1]:=true else checkGroup1.Checked[1]:=false;
   if ((e and 4)=4 ) then
      CheckGroup1.Checked[2]:=true else checkGroup1.Checked[2]:=false;
  if ((e and 8)=8 ) then
      CheckGroup1.Checked[3]:=true else checkGroup1.Checked[3]:=false;
  if ((e and 16)=16 ) then
     CheckGroup1.Checked[4]:=true else checkGroup1.Checked[4]:=false;
  if ((e and 32)=32 ) then
     CheckGroup1.Checked[5]:=true else checkGroup1.Checked[5]:=false;
  if ((e and 64)=64 ) then
     CheckGroup1.Checked[6]:=true else checkGroup1.Checked[6]:=false;
  if ((e and 128)=128 ) then
     CheckGroup1.Checked[7]:=true else checkGroup1.Checked[7]:=false;
     save_inp(e);
 end;

procedure TForm1.Edit2Change(Sender: TObject);
begin
  save_str(edit2.Text);
end;

procedure TForm1.Edit3Change(Sender: TObject);
var e:word;
begin
   e:=OPCClient1.TagList.GroopList[0].ItList[2].Value.GetVT_UI2;
   if ((e and 1)=1 ) then     CheckGroup2.Checked[0]:=true else checkGroup2.Checked[0]:=false;
   if ((e and 2)=2 ) then     CheckGroup2.Checked[1]:=true else checkGroup2.Checked[1]:=false;
   if ((e and 4)=4 ) then     CheckGroup2.Checked[2]:=true else checkGroup2.Checked[2]:=false;
  if ((e and 8)=8 ) then      CheckGroup1.Checked[3]:=true else checkGroup2.Checked[3]:=false;
  if ((e and 16)=16 ) then    CheckGroup2.Checked[4]:=true else checkGroup2.Checked[4]:=false;
  if ((e and 32)=32 ) then  CheckGroup2.Checked[5]:=true else checkGroup2.Checked[5]:=false;
  if ((e and 64)=64 ) then   CheckGroup2.Checked[6]:=true else checkGroup2.Checked[6]:=false;
  if ((e and 128)=128 ) then   CheckGroup2.Checked[7]:=true else checkGroup2.Checked[7]:=false;
   save_out(e);
 end;

procedure TForm1.FormClose(Sender: TObject; var CloseAction: TCloseAction);
begin
    opcclient1.Disconect;
end;

procedure TForm1.MenuItem2Click(Sender: TObject);
begin
    MenuItem2.Checked:=not MenuItem2.Checked;
    if MenuItem2.Checked then
       opcclient1.Conect else
       opcclient1.Disconect;
    if MenuItem2.Checked then
        form1.Caption:='active' else
        form1.Caption:='no active';
    if opcclient1.Active then
        form1.Caption:=form1.Caption+' ok' ;
    TempPos.NGroup:=0;
        TempPos.NTag:=2;
end;

procedure TForm1.OPCClient1ChangeTag(const Sender: TObject;
  const aTagPosition: TTagPosition; const aTagChange: TTagItem);
begin
  edit1.Text:=OPCClient1.TagList.GroopList[0].ItList[0].GetValueAsString;
  edit2.Text:=OPCClient1.TagList.GroopList[0].ItList[1].GetValueAsString;
  edit3.Text:=OPCClient1.TagList.GroopList[0].ItList[2].GetValueAsString;
end;

end.

