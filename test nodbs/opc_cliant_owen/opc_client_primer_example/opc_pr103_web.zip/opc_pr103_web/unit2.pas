unit Unit2;
{$mode objfpc}{$H+}
interface
  uses
  Classes, SysUtils, fphttpserver, fphttpclient, RegexPr;
   type
  //======================================  // Server
  TThreadServer = class(TThread)
  protected
    procedure Execute; override;
  public
    FPHttpServer1: TFPHttpServer;
    constructor Create(Port: Integer; OnQuery: THTTPServerRequestHandler);
    destructor Destroy; override;
  end;
 implementation
// =========== Server ===========
constructor TThreadServer.Create(Port: Integer; OnQuery: THTTPServerRequestHandler);
begin    Self.FreeOnTerminate := true;
  FPHttpServer1 := TFPHttpServer.Create(nil);
  FPHttpServer1.Port := Port;
  FPHttpServer1.OnRequest := OnQuery;
  FPHttpServer1.LookupHostNames:=False;
  inherited Create(False);
end;

destructor TThreadServer.Destroy;
begin    FPHttpServer1.Free;  end;

procedure TThreadServer.Execute;
begin    try    FPHttpServer1.Active := True;
             except    on E: Exception do    begin      Exit;    end;
            end;
end;
end.


