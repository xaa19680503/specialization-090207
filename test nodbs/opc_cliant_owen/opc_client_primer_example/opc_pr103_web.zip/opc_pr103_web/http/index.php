<!DOCTYPE html>
<html> <head> <meta charset="utf-8">
        <meta name="viewport" content="width=device-width" />
         <meta http-equiv="refresh" content="3"> <title> АСУ ТП </title>  
      <style>  *{        box-sizing: border-box;            }
            html, body { padding: 0;   margin: 0;
                font-family: verdana, arial, sans-serif;         }
             body {  color: #0Ff;  font-size: 1.1em; padding: 1em;
                display: flex;   flex-direction: column;         }
            main {        display: flex;    flex-direction: column;        }
            article {    background-color: #546e7a;  flex: 2 2 12em; padding: 1em; }
            nav, aside {  flex: 1;  background-color: #455a64;           }
             nav { order: -1;  }          
            header, footer {  flex: 0 0 5em;  background-color: #37474f;   }           
            @media screen and (min-width: 600px) {   body{ min-height: 100vh; }
                main { flex-direction: row; min-height: 100%; flex: 1 1 auto; }
                                                 }
        </style>  </head>
<body>   <header>   <a>
    <?php include "s.html" ?>
                       </a>   </header>
        <main>  <article>  </article>
               <nav>  <p>Navigation</p> <p>
                     <?php include "b.html" ?>
                                       </p> </nav>
           <aside> <p>Sidebar</p>  </aside>
     </main>  <footer>  <p>
    <?php include "r.html" ?>
    <?php include "a.html" ?>
                  </p>  <p>Footer</p> </footer>
</body> </html>