unit Unit1;
{$mode objfpc}{$H+}
interface
uses   unit2, Process, WinSock, IdGlobal, IdIPWatch, LazUTF8, Classes, SysUtils,
  Forms, Controls, Graphics, Dialogs, StdCtrls, Spin, Menus, ComCtrls, ExtCtrls,
  Grids, Buttons, IdTCPClient, IdTCPServer, IdCustomTCPServer, IdContext,
  IdCmdTCPClient, IdIcmpClient, IdTraceRoute, IdComponent, crc_16, Types,unit3;

type
  { TForm1 }
  TForm1 = class(TForm)
    BitBtn1: TBitBtn;
    Button1: TButton;
    Button10: TButton;
    Button11: TButton;
    Button12: TButton;
    Button13: TButton;
    Button14: TButton;
    Button15: TButton;
    Button16: TButton;
    Button17: TButton;
    Button18: TButton;
    Button19: TButton;
      Button2: TButton;
      Button20: TButton;
      Button21: TButton;
      Button22: TButton;
      Button23: TButton;
      Button24: TButton;
      Button25: TButton;
      Button26: TButton;
      Button27: TButton;
      Button28: TButton;
      Button29: TButton;
    Button3: TButton;
    Button30: TButton;
    Button31: TButton;
    Button32: TButton;
    Button4: TButton;    Button5: TButton;    Button6: TButton;
    Button7: TButton;
    Button8: TButton;
    Button9: TButton;
    CheckBox1: TCheckBox;    CheckBox2: TCheckBox;
    CheckBox3: TCheckBox;
    CheckBox4: TCheckBox;
    CheckBox5: TCheckBox;
    CheckBox6: TCheckBox;
    CheckBox7: TCheckBox;
    ComboBox5: TComboBox;
    Edit1: TEdit;
Edit2: TEdit;    Edit3: TEdit;    Edit4: TEdit;
    Edit5: TEdit;
    FloatSpinEdit1: TFloatSpinEdit;
    FloatSpinEdit2: TFloatSpinEdit;
    GroupBox1: TGroupBox;
    GroupBox2: TGroupBox;
    IdTCPClient1: TIdTCPClient;
    IdTCPServer1: TIdTCPServer;
    Label10: TLabel;
    Label11: TLabel;
    Label12: TLabel;
    Label13: TLabel;
    Label14: TLabel;
    Label15: TLabel;
    Label16: TLabel;
    Label17: TLabel;
    Label2: TLabel;
    Label3: TLabel;
    Label4: TLabel;
    Label8: TLabel;
    Label9: TLabel;
    MainMenu1: TMainMenu;
    Memo1: TMemo;     Memo2: TMemo;
    MenuItem1: TMenuItem;
    MenuItem10: TMenuItem;
    MenuItem11: TMenuItem;
    MenuItem12: TMenuItem;
    MenuItem13: TMenuItem;
    MenuItem14: TMenuItem;
    MenuItem15: TMenuItem;
     MenuItem2: TMenuItem;
    MenuItem3: TMenuItem;    MenuItem4: TMenuItem;
    MenuItem5: TMenuItem;    MenuItem6: TMenuItem;
    MenuItem7: TMenuItem;
    MenuItem8: TMenuItem;
    MenuItem9: TMenuItem;
    Notebook1: TNotebook;
    Page1: TPage;
    Page2: TPage;
    Page3: TPage;
    Page4: TPage;
    Page5: TPage;
    Page6: TPage;
    Page7: TPage;
    Page8: TPage;
    PageControl1: TPageControl;
    Panel1: TPanel;
    PopupMenu1: TPopupMenu;
    PopupMenu2: TPopupMenu;
    PopupMenu3: TPopupMenu;
    ProgressBar1: TProgressBar;    RadioGroup1: TRadioGroup;
    SpinEdit1: TSpinEdit;
    SpinEdit10: TSpinEdit;
SpinEdit2: TSpinEdit;
    SpinEdit3: TSpinEdit;
    SpinEdit4: TSpinEdit;
    SpinEdit5: TSpinEdit;
    SpinEdit6: TSpinEdit;
    SpinEdit7: TSpinEdit;
    SpinEdit8: TSpinEdit;
    SpinEdit9: TSpinEdit;
    StringGrid1: TStringGrid;
    StringGrid2: TStringGrid;
    StringGrid3: TStringGrid;
    StringGrid4: TStringGrid;
    StringGrid5: TStringGrid;
    StringGrid6: TStringGrid;
    StringGrid7: TStringGrid;
    TabSheet1: TTabSheet;
    TabSheet2: TTabSheet;
    TabSheet3: TTabSheet;
    TabSheet4: TTabSheet;
    Timer1: TTimer;
    TrackBar1: TTrackBar;
    procedure BitBtn1Click(Sender: TObject);
    procedure Button10Click(Sender: TObject);
    procedure Button11Click(Sender: TObject);
    procedure Button12Click(Sender: TObject);
    procedure Button13Click(Sender: TObject);
    procedure Button14Click(Sender: TObject);
    procedure Button15Click(Sender: TObject);
    procedure Button16Click(Sender: TObject);
    procedure Button17Click(Sender: TObject);
    procedure Button18Click(Sender: TObject);
    procedure Button19Click(Sender: TObject);
    procedure Button1Click(Sender: TObject);
    procedure Button20Click(Sender: TObject);
    procedure Button21Click(Sender: TObject);
    procedure Button22Click(Sender: TObject);
    procedure Button23Click(Sender: TObject);
    procedure Button24Click(Sender: TObject);
    procedure Button25Click(Sender: TObject);
    procedure Button26Click(Sender: TObject);
    procedure Button27Click(Sender: TObject);
    procedure Button28Click(Sender: TObject);
    procedure Button29Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure Button30Click(Sender: TObject);
    procedure Button31Click(Sender: TObject);
    procedure Button32Click(Sender: TObject);
    procedure Button3Click(Sender: TObject);
    procedure Button4Click(Sender: TObject);
    procedure Button5Click(Sender: TObject);
    procedure Button6Click(Sender: TObject);
    procedure Button7Click(Sender: TObject);
    procedure Button8Click(Sender: TObject);
    procedure Button9Click(Sender: TObject);
    procedure CheckBox1Change(Sender: TObject);
    procedure CheckBox2Change(Sender: TObject);
    procedure CheckBox3Change(Sender: TObject);
    procedure CheckBox4Change(Sender: TObject);
    procedure CheckBox5Change(Sender: TObject);
    procedure CheckBox6Change(Sender: TObject);
    procedure ComboBox5Change(Sender: TObject);
    procedure Edit1Change(Sender: TObject);
    procedure Edit2Change(Sender: TObject);
    procedure Edit2EditingDone(Sender: TObject);
    procedure Edit2EndDrag(Sender, Target: TObject; X, Y: Integer);
    procedure Edit2Enter(Sender: TObject);
    procedure Edit2Exit(Sender: TObject);
    procedure Edit5Change(Sender: TObject);
    procedure FloatSpinEdit1Change(Sender: TObject);
    procedure FloatSpinEdit2Change(Sender: TObject);
    procedure FormActivate(Sender: TObject);
    procedure FormClose(Sender: TObject; var CloseAction: TCloseAction);
    procedure FormCreate(Sender: TObject);
    procedure IdTCPClient1AfterBind(Sender: TObject);
    procedure IdTCPClient1BeforeBind(Sender: TObject);
    procedure IdTCPClient1Connected(Sender: TObject);
    procedure IdTCPClient1SocketAllocated(Sender: TObject);
    procedure IdTCPClient1Work(ASender: TObject; AWorkMode: TWorkMode;
      AWorkCount: Int64);
    procedure IdTCPClient1WorkEnd(ASender: TObject; AWorkMode: TWorkMode);
    procedure IdTCPServer1AfterBind(Sender: TObject);
    procedure IdTCPServer1Status(ASender: TObject; const AStatus: TIdStatus;
      const AStatusText: string);
    procedure IdTraceRoute1Reply(ASender: TComponent;
      const AReplyStatus: TReplyStatus);
    procedure Memo2Change(Sender: TObject);
    procedure MenuItem10Click(Sender: TObject);
    procedure MenuItem11Click(Sender: TObject);
    procedure MenuItem12Click(Sender: TObject);
    procedure MenuItem13Click(Sender: TObject);
    procedure MenuItem15Click(Sender: TObject);
    procedure MenuItem9Click(Sender: TObject);

    procedure OnClientResponse(ThreadClient: TThreadClient);
    procedure OnClientError(ThreadClient: TThreadClient; E: Exception);

    procedure IdTCPServer1Connect(AContext: TIdContext);
    procedure IdTCPServer1Disconnect(AContext: TIdContext);
    procedure IdTCPServer1Execute(AContext: TIdContext);
    procedure MenuItem2Click(Sender: TObject);
    procedure MenuItem3Click(Sender: TObject);
    procedure MenuItem4Click(Sender: TObject);
    procedure MenuItem5Click(Sender: TObject);
    procedure MenuItem6Click(Sender: TObject);
    procedure MenuItem7Click(Sender: TObject);
    procedure MenuItem8Click(Sender: TObject);
    procedure Page1BeforeShow(ASender: TObject; ANewPage: TPage;
      ANewIndex: Integer);
    procedure RadioGroup1Click(Sender: TObject);
    PROCEDURE  SendMessageToServer(const AServerIP: string; const Port: word;
         const AclientIP: string;   const ClientPort: word;      const INF: string);
   PROCEDURE SendallbyteToServer(const AServerIP: string; const Port: word;
        INF: string);
   procedure SpinEdit10Change(Sender: TObject);
    procedure SpinEdit1_1Change(Sender: TObject);
    procedure SpinEdit2Change(Sender: TObject);
    procedure SpinEdit4Change(Sender: TObject);
    procedure SpinEdit5Change(Sender: TObject);
    procedure SpinEdit6Change(Sender: TObject);
    procedure SpinEdit7Change(Sender: TObject);
    procedure SpinEdit8Change(Sender: TObject);
    procedure SpinEdit9Change(Sender: TObject);
    procedure StringGrid2Click(Sender: TObject);
    procedure StringGrid2DblClick(Sender: TObject);
    procedure StringGrid2Selection(Sender: TObject; aCol, aRow: Integer);
    procedure StringGrid3KeyPress(Sender: TObject; var Key: char);
    procedure StringGrid4Click(Sender: TObject);
    procedure StringGrid4DblClick(Sender: TObject);
    procedure StringGrid4Selection(Sender: TObject; aCol, aRow: Integer);
    procedure StringGrid5BeforeSelection(Sender: TObject; aCol, aRow: Integer);
    procedure StringGrid5Click(Sender: TObject);
    procedure StringGrid7Click(Sender: TObject);
    procedure TabSheet1ContextPopup(Sender: TObject; MousePos: TPoint;
      var Handled: Boolean);
    procedure TabSheet3ContextPopup(Sender: TObject; MousePos: TPoint;
      var Handled: Boolean);
    procedure Timer1Timer(Sender: TObject);
    procedure TrackBar1Change(Sender: TObject);

    procedure TrackBar1EndDrag(Sender, Target: TObject; X, Y: Integer);
    procedure TrackBar1MouseUp(Sender: TObject; Button: TMouseButton; Shift: TShiftState; X, Y: Integer);
    function found_buf(buf:array of byte;    tt:tstringgrid ):integer;
    function save_buf(buf:array of byte; var tt:tstringgrid ):integer;

    function move_out(var buf:array of byte; tt:tstringgrid;n:integer  ):integer;
    function out_move(var buf:array of byte; tt:tstringgrid;n,m:integer  ):integer;
    PROCEDURE str_org;
  private
    rw:integer;
    nm:word;
  public
     hreadClient:TThreadClient;
  end;

var  Form1: TForm1;
         tim_ok:boolean=false;

//  Socket: TSocket;
implementation
{$R *.lfm}


function PingWithSystem(hostname: string): Boolean;
var
  cmd: TStringList;
  process: TProcess;
begin
  cmd := TStringList.Create;
  cmd.Add('ping');
  cmd.Add(hostname);
  // Добавьте другие параметры, если нужно (например, -t для непрерывного режима в Windows)

 // process := TProcess.Create(nul);
  try
    process.Executable := 'ping.exe'; // Или 'ping' в зависимости от ОС
 //   process.Arguments := cmd;
    process.Options := process.Options + [poWaitOnExit];
    process.Execute;

    // Читаем вывод и анализируем его
    Result := process.ExitCode = 0; // 0 — успех (ответ получен), иначе — ошибка/таймаут
  finally
    process.Free;
  end;
end;



PROCEDURE TFORM1.str_org;
VAR i:integer; s,r:string;
begin s:='';
  for i:=1 to StringGrid5.rowcount-3 do
      begin
       r:=StringGrid5.Cells[1 ,i]; if r='' then r:='00';
      s:=s+r+'/';
      end;
      StringGrid4.Cells[10,StringGrid4.row]:=s;
end;

function clear_str(s:string):string;
    var  d:string;      n:byte;

  begin  n:=1;      d:=s;
   while n<=length(d) do
      begin
      if d[n] in ['+','-','1','2','3','4','5','6','7','8','9','0','.',','] then
         begin
         if d[n]='.' then  d[n]:=',';
         if d[n]=',' then //-заменим на запятую точку
         if   n =1   then
             begin               d:='0'+d;
             if length(d)=2 then d:=d+'0';
             inc(n); continue;
             end else
          if   n =length(d)   then
              begin d:=d+'0';
              inc(n); continue;
              end ;
         if d[n]='-' then
         if   n >1   then
             begin  delete(d,n,1); continue; end;
         inc(n);  continue;
         end ;      delete(d,n,1);
      end;
  if length(d)<2 then       d:='0'+d;
     clear_str:=d;
 end;

{ TForm1 }
function tform1.save_buf(buf: array of byte; var tt :tstringgrid ):integer;
var i,e,n:integer;     y,p:byte;
begin    tt.RowCount:=tt.RowCount+1;
     if  tt.colCount<(length(buf)+1-6) then
         tt.colCount:=length(buf)+1-6;
      n:=tt.RowCount-1; e:=1;
      for i:=6 to length(buf)-1 do
         begin
         tt.cells[e,n]:=inttostr(buf[i]); inc(e);
         end;                     result:=0;
end;

function tform1.found_buf(buf: array of byte; tt :tstringgrid ):integer;
var i,e,n:integer;     y,p:byte;
begin        e:=-1;    n:=-1;      result:=n;
     if  length(buf)>11 then  else exit;
     for i:=1 to tt.RowCount-1 do
         begin if e<5 then  e:=-1;
         if e<0 then begin  if tt.Cells[1,i]='' then
                               tt.Cells[1,i]:='0';
         p:=buf[6 ]; y:=strtoint(tt.Cells[1,i]); if p=y then
         inc(e);            if tt.Cells[2,i]='' then
                               tt.Cells[2,i]:='0';
         p:=buf[7 ]; y:=strtoint(tt.Cells[2,i]); if p=y then
         inc(e);            if tt.Cells[3,i]='' then
                               tt.Cells[3,i]:='0';
         p:=buf[8 ]; y:=strtoint(tt.Cells[3,i]); if p=y then
         inc(e);           if tt.Cells[4,i]='' then
                              tt.Cells[4,i]:='0';
         p:=buf[9 ]; y:=strtoint(tt.Cells[4,i]); if p=y then  inc(e);
                            if tt.Cells[5,i]='' then
                               tt.Cells[5,i]:='0';
         p:=buf[10 ]; y:=strtoint(tt.Cells[5,i]); if p=y then inc(e);
                            if tt.Cells[6,i]='' then
                               tt.Cells[6,i]:='0';
         p:=buf[11 ]; y:=strtoint(tt.Cells[6,i]); if p=y then inc(e);
         end;
         if e=5 then begin  inc(e); n:=i; end;
         end;
         result:=n;
end;

  PROCEDURE TFORM1.SendallbyteToServer(
   const AServerIP: string;
        const Port: word;
    INF:String
   );
  VAR   TCPClient: TIdTCPClient;
      rbs: RawByteString;
    S:STRING;
    f:array of byte;
    i:integer;
begin
  TCPClient := TIdTCPClient.Create(nil);
    TCPClient.Host := AServerIP;
    TCPClient.Port := Port;
    try
      TCPClient.Connect;     // Отправляем данные серверу через поток вывода
  //  TCPClient.IOHandler.WriteLn('HELL0! ->'+INF);
           s:=SysToUTF8(INF);
           setlength(f,length(s));
           for i:=1 to length(s) do
             f[i-1]:=ord(s[i]);

   //  rbs := EncryptString('HELL0! ->'+INF, DEFAULT_ENCRYPTION_KEY);
  // TCPClient.IOHandler.Write(Int32(Length(S)));
 // TCPClient.IOHandler.Write(S);
  TCPClient.IOHandler.WriteDirect( f);
    MEMO1.Lines.Add('Сообщение получено сервером');
  finally
      TCPClient.Free;
  end;
end;

procedure TForm1.SpinEdit10Change(Sender: TObject);
var v2, v1:int32;  a1,a2,a3,a4:byte ;   x:^byte;
begin  //v1:=hi(SpinEdit10.Value); //v2:=lo(SpinEdit10.Value);
 v2:=SpinEdit10.Value;
    x:=@v2;  a1:=x^;    x:=x+1;
             a2:=x^;    x:=x+1;
             a3:=x^;    x:=x+1;
             a4:=x^;
     stringgrid5.Cells[1,1]:=inttostr(a4);
     stringgrid5.Cells[1,2]:=inttostr(a3);
       stringgrid5.Cells[1,3]:=inttostr(a2);
     stringgrid5.Cells[1,4]:=inttostr(a1);       str_org;
end;


    function getLocalIP: string;
var
   IPW: TIdIPWatch;
begin
  IpW := TIdIPWatch.Create(nil);
  try
    if IpW.LocalIP <> '' then
      Result := IpW.LocalIP;
    ShowMessage('IP: ' + Result);
  finally
    IpW.Free;
  end;
end;

 procedure TFORM1.SendMessageToServer(
   const AServerIP: string;
        const Port: word;
   const AclientIP: string;
   const ClientPort: word;
   const INF: string
   );
  VAR   TCPClient: TIdTCPClient;
    VAR
    S:STRING;
begin
  TCPClient := TIdTCPClient.Create(nil);
    TCPClient.Host := AServerIP;
    TCPClient.Port := Port;

    TCPClient.ReadTimeout:=1000;

if CheckBox2.Checked then begin
    TCPClient.BoundIP:=AClientIP;
    TCPClient.BoundPort:=clientport; end;
  //   TCPClient.OnConnected:=TCPClient1Connected;

    try
      TCPClient.Connect;     // Отправляем данные серверу через поток вывода
   TCPClient.IOHandler.WriteLn('HELL0! ->'+INF);

  sleep(400);
   if TCPClient.IOHandler.InputBuffer.Size>0 then
     s:=TCPClient.IOHandler.ReadLn;

    MEMO1.Lines.Add('Сообщение получено сервером --'+ s);
  finally
      TCPClient.Free;
  end;
end;

procedure TForm1.SpinEdit1_1Change(Sender: TObject);
begin

end;

procedure TForm1.SpinEdit2Change(Sender: TObject);
begin
    //   stringgrid5.Cells[1,1]:=inttostr(SpinEdit2.Value);
//        str_org;
end;

procedure TForm1.SpinEdit4Change(Sender: TObject);
begin
  timer1.Interval:=spinedit4.Value;
end;

procedure TForm1.SpinEdit5Change(Sender: TObject);
begin

end;

procedure TForm1.SpinEdit6Change(Sender: TObject);
begin
     stringgrid5.Cells[1,1]:=inttostr(SpinEdit6.Value);
        str_org;
end;

procedure TForm1.SpinEdit7Change(Sender: TObject);
   var v:word;
begin  v:=SpinEdit7.Value;
        stringgrid5.Cells[1,1]:=inttostr(hi(v));
        stringgrid5.Cells[1,2]:=inttostr(lo(v));     str_org;
end;

procedure TForm1.SpinEdit8Change(Sender: TObject);
   var v1,v2:word; v:word;
   begin  v:=SpinEdit8.Value;
        v1:=hi(v);     v2:=lo(v);
        stringgrid5.Cells[1,1]:=inttostr(hi(v1));
        stringgrid5.Cells[1,2]:=inttostr(lo(v1));
        stringgrid5.Cells[1,3]:=inttostr(hi(v2));
        stringgrid5.Cells[1,4]:=inttostr(lo(v2));    str_org;
end;

procedure TForm1.SpinEdit9Change(Sender: TObject);
   var  v:int16;
   begin  v:=SpinEdit9.Value;

        stringgrid5.Cells[1,1]:=inttostr(hi(v));
        stringgrid5.Cells[1,2]:=inttostr(lo(v));    str_org;
end;

procedure TForm1.StringGrid2Click(Sender: TObject);
   VAR s,R:STRING; j,i:integer;
    begin
  if   StringGrid2.Col=1 then else exit;
  if   StringGrid2.row in [1,4,3,2,5,6] then else exit; s:='не больше 255!';
  if   StringGrid2.row =2 then s:='не больше 255!'+#13+
        '01 Чтение DO'+#13 +
        '02 Чтение DI'+#13 +
        '03 Чтение AO'+#13 +
        '04 Чтение AI'+#13 +
        '05 Запись D0'+#13 +
        '06 Запись A0'+#13 ;
      r:= InputBox('байт ввести',s,
      StringGrid2.Cells[StringGrid2.Col, StringGrid2.row]);
    if r='' then r:='0';
      StringGrid2.Cells[StringGrid2.Col,StringGrid2.row]:=clear_str(r);
    s:=inttohex(strtoint(r));
    StringGrid2.Cells[StringGrid2.Col+1,StringGrid2.row]:=s ;
    Button9Click(Sender);
end;

procedure TForm1.StringGrid2DblClick(Sender: TObject);
   VAR s,R:STRING; j,i:integer;
   begin
 if   StringGrid2.Col=1 then else exit;
 if   StringGrid2.row in [1,4,3,2,5,6] then else exit; s:='не больше 255!';
  if   StringGrid2.row =2 then s:='не больше 255!'+#13+
       '01 Чтение DO'+#13 +
       '02 Чтение DI'+#13 +
       '03 Чтение AO'+#13 +
       '04 Чтение AI'+#13 +
       '05 Запись D0'+#13 +
       '06 Запись A0'+#13 ;
     r:= InputBox('байт ввести',s,
     StringGrid2.Cells[StringGrid2.Col,
                       StringGrid2.row]);
   if r='' then r:='0';
     StringGrid2.Cells[StringGrid2.Col,
                       StringGrid2.row]:=clear_str(r);
   s:=inttohex(strtoint(r));
   StringGrid2.Cells[StringGrid2.Col+1,
                     StringGrid2.row]:=s ;
   Button9Click(Sender);
end;

procedure TForm1.StringGrid2Selection(Sender: TObject; aCol, aRow: Integer);
begin
   if (StringGrid2.Cells[1,2]='06') or
      (StringGrid2.Cells[1,2]='05') then begin
       StringGrid2.Cells[3,5]:='Значение byte HI';
       StringGrid2.Cells[3,6]:='Значение byte LO'; end else
      begin
            StringGrid2.Cells[3,5]:='кол. регисров HI';
            StringGrid2.Cells[3,6]:='кол. регистров LO'; end ;
end;

procedure TForm1.StringGrid3KeyPress(Sender: TObject; var Key: char);
begin
  if ord(key)=32 then if stringgrid3.Cells[0,stringgrid3.Row]<>'0ff' then
                         stringgrid3.Cells[0,stringgrid3.Row]:='0ff' else
                         stringgrid3.Cells[0,stringgrid3.Row]:='';
end;

procedure TForm1.StringGrid4Click(Sender: TObject);
   var q,r,i:word; e:boolean;
   begin  e:=false;
     memo1.Lines.Add('click'+inttostr(StringGrid4.row));
   if stringgrid4.Cells[9,stringgrid4.row]='' then exit;
     stringgrid5.RowCount:=strtoint( stringgrid4.Cells[9,stringgrid4.row])+3;
     r:=stringgrid5.RowCount; q:=stringgrid5.colCount;
   for i:=1 to r-3  do
      begin stringgrid5.Cells[q-1,i]:='--';
      if (stringgrid4.Cells[2,stringgrid4.row]='01' )or
         (stringgrid4.Cells[2,stringgrid4.row]='02' )or
         (stringgrid4.Cells[2,stringgrid4.row]='' )
         then continue;
      if (stringgrid4.Cells[2,stringgrid4.row]='06' )or
         (stringgrid4.Cells[2,stringgrid4.row]='05' )or
         (stringgrid4.Cells[2,stringgrid4.row]='' )
         then begin
         if i=1 then stringgrid5.Cells[q-1,i]:='adress HI';
         if i=1 then stringgrid5.Cells[  1,i]:=stringgrid4.Cells[3,stringgrid4.row];
         if i=2 then stringgrid5.Cells[q-1,i]:='adress LO';
         if i=2 then stringgrid5.Cells[  1,i]:=stringgrid4.Cells[4,stringgrid4.row];
         if i=3 then stringgrid5.Cells[q-1,i]:='значение HI';
         if i=3 then stringgrid5.Cells[  1,i]:=stringgrid4.Cells[5,stringgrid4.row];
         if i=4 then stringgrid5.Cells[q-1,i]:='значение LO';
         if i=4 then stringgrid5.Cells[  1,i]:=stringgrid4.Cells[6,stringgrid4.row];
         end;
      if (stringgrid4.Cells[2,stringgrid4.row]='03' )or
         (stringgrid4.Cells[2,stringgrid4.row]='04' )
           then
      if not e then stringgrid5.Cells[q-1,i]:='byte HI'
               else stringgrid5.Cells[q-1,i]:='byte LO';
       e:= not e;
      end;
     stringgrid5.Cells[q-1,R-2]:='CRC HI';
     stringgrid5.Cells[q-1,R-1]:='CRC LO';
end;

procedure TForm1.StringGrid4DblClick(Sender: TObject);
   VAR s,R:STRING; j,i:integer;
  begin
    if   StringGrid4.Col=9 then else exit;       s:='не больше 255!';
      r:=StringGrid4.Cells[9,StringGrid4.row]; if r='' then r:='0';
      r:= InputBox('ввести длину данных',s,r);
        StringGrid4.Cells[9, StringGrid4.row]:=clear_str(r);
        StringGrid4Click(Sender);
end;

procedure TForm1.StringGrid4Selection(Sender: TObject; aCol, aRow: Integer);
   var g,w:word;s5,s6:string; r,i:integer; n,z,s:string;
begin   StringGrid4Click(Sender); //УКАЖЕМ ДЛИНУ
      g:=AROW; //StringGrid3.row; // memo1.Lines.add('<>'+inttostr(StringGrid4.row));
      s:=stringgrid4.Cells[10,G]; z:=s;
      for i:=1 to  StringGrid5.rowcount-1 do stringgrid5.Cells[1,i]:='';
      for i:=1 to  StringGrid5.rowcount-1 do stringgrid5.Cells[2,i]:='';
   //   for i:=1 to  length(s)  do begin
   ///       z:=inttostr(ord(s[i]));
   //       if i>stringgrid4.RowCount-3 then continue;
   ///       stringgrid4.Cells[1,i]:=z;
   ///       stringgrid4.Cells[2,i]:=inttohex(strtoint(z));
   //   end;
      i:=1;
      while length(z)>0 do
         begin r:=pos('/',z);
         if r<=0 then begin z:=''; continue; end;
         if i>stringgrid5.RowCount-3 then begin z:=''; continue; end;
         n:=copy(z,0,r-1); delete(z,1,r);;
         stringgrid5.Cells[1,i]:=n;
         stringgrid5.Cells[2,i]:=inttohex(strtoint(n));
         inc(i);
         end;
      stringgrid4.Cells[10,g]:=s;
   if stringgrid4.Cells[9,arow]='' then    else exit;
    s5:=stringgrid4.Cells[5,arow];
    s6:=stringgrid4.Cells[6,arow];  // memo1.Lines.Add(inttostr(arow));
    if length(s5)=0 then exit;   if length(s6)=0 then exit;
     w:=strtoint(s5)*255+strtoint(s6);
    if '01'=stringgrid4.Cells[2,arow] then g:=round(w/8+0.5);
    if '02'=stringgrid4.Cells[2,arow] then g:=round(w/8+0.5);
    if '03'=stringgrid4.Cells[2,arow] then g:=round(w*2);
    if '04'=stringgrid4.Cells[2,arow] then g:=round(w*2);
    if '05'=stringgrid4.Cells[2,arow] then g:=4;
    if '06'=stringgrid4.Cells[2,arow] then g:=4;
            stringgrid4.Cells[9,arow]:=inttostr(g);
end;

procedure TForm1.StringGrid5BeforeSelection(Sender: TObject; aCol, aRow: Integer
  );
   var r,i:integer;n,z,s:string;
   begin  r:=StringGrid4.row;
      memo1.Lines.add('afte'+inttostr(+StringGrid5.row));
      s:=stringgrid4.Cells[10,r];  z:=s;
    //  for i:=1 to  length(s)-1 do begin
   //       z:=inttostr(ord(s[i]));
   //       stringgrid4.Cells[1,i]:=z;
   //   end;
   i:=1;
   while length(z)>0 do
      begin r:=pos('/',z);
      if r<=0 then begin z:=''; continue; end;
      if i>=stringgrid5.RowCount-3 then begin z:=''; continue; end;
      n:=copy(z,0,r-1); delete(z,1,r);
      stringgrid5.Cells[1,i]:=n;
      inc(i);
      end;
end;

procedure TForm1.StringGrid5Click(Sender: TObject);
   VAR s,R:STRING; j,i:integer;
   begin
   if StringGrid5.row>=StringGrid5.rowcount-2 then exit;
   if StringGrid5.Col=1 then else exit;        s:='не больше 255!';
   r:=StringGrid5.Cells[1,StringGrid5.row]; if r='' then r:='0';
   r:= clear_str(InputBox('ввести данные',s,r));
   if strtoint(r)>255 then r:='255';
     StringGrid5.Cells[1, StringGrid5.row]:=r;
     StringGrid5.Cells[2, StringGrid5.row]:=inttohex(strtoint(r)); s:='';
     for i:=1 to StringGrid5.rowcount-3 do
         begin
          r:=StringGrid5.Cells[1 ,i]; if r='' then r:='00';
         s:=s+r+'/';
         end;
         StringGrid4.Cells[10,StringGrid4.row]:=s;
end;

procedure TForm1.StringGrid7Click(Sender: TObject);
begin
    if stringgrid7.Rowcount>0 then
  if stringgrid7.Row>0      then
     begin
       button17.enabled:=true;
       button18.enabled:=true;
     end;
end;

procedure TForm1.TabSheet1ContextPopup(Sender: TObject; MousePos: TPoint;
  var Handled: Boolean);
begin

end;

procedure TForm1.TabSheet3ContextPopup(Sender: TObject; MousePos: TPoint;
  var Handled: Boolean);
begin

end;

procedure TForm1.Timer1Timer(Sender: TObject);
   var  e,  i,q:integer; z,s:string;
          id,j,w:word;  ff,s4, s2:string;
buf: array of byte;
begin    // if   tim_ok=true then
 //  begin tim_ok:=false;hreadClient.Terminate;// exit;
 //  end;
w:=spinedit1.value;   j:=spinedit3.value;    s2:=edit1.Text;     s4:=edit4.Text;

           q:=stringgrid3.Rowcount-1;   if q<=0 then exit;
            if rw<1 then rw:=0;
            if rw<q then rw:=rw+1 else   rw:=1;
            if pos('ff',stringgrid3.Cells[0,rw])>0 then
            exit;


            timer1.Enabled:=false;            hreadClient:=NIL;
     form1.Caption:=inttostr(rw);
                      z:='';
                         spinedit5.value:=spinedit5.value+1;
                     id:=spinedit5.value;
                     s:=  chr(hi(id));
                     s:=s+chr(lo(id));
                     s:=s+chr(0);
                     s:=s+chr(0);
           setlength(buf,stringgrid3.ColCount-1-2+6);
            buf[0]:=hi(id);
            buf[1]:=lo(id);
            buf[2]:=0;
            buf[3]:=0;
         for i:=1 to stringgrid3.ColCount-1-2 do
           begin
           if stringgrid3.Cells[i,rw]='' then
                 z:=z+chr(0) else
                 z:=z+chr(strtoint(stringgrid3.Cells[i,rw]));
           if stringgrid3.Cells[i,rw]='' then
                buf[i-1+6]:=0 else
                buf[i-1+6]:=strtoint(stringgrid3.Cells[i,rw]);
           end;

                    id:=length(z);
         buf[4]:=hi(id);
         buf[5]:=lo(id);

         s:=s+chr(hi(id));
         s:=s+chr(lo(id));
         z:=s+z;
//        z:=chr(48);  // транзакця
//        z:=z+chr(49);  // транзакця
//        z:=z+chr(50);  // транзакця
//        z:=z+chr(51);  // транзакця
//        z:=z+chr(53);  // транзакця
//        z:=z+chr(52);  // транзакця
//        z:=z+chr(128);  // транзакця
//        z:=z+chr(54);  // транзакця
//        z:=z+chr(55);  // транзакця
//        z:=z+chr(56);  // транзакця
//        hreadClient:=TThreadClient.Create(z,@OnClientResponse, @OnClientError,'',s4,0,w);
   if CheckBox4.Checked then begin
   if checkbox2.Checked then
   TThreadClient.Create(z,buf,@OnClientResponse, @OnClientError,s4,s2,j,w) else
   TThreadClient.Create(z,buf,@OnClientResponse, @OnClientError,'',s2,0,w);
   tim_ok:=true;  timer1.Enabled:=true; end;

   if IdTCPClient1.Connected then
   if CheckBox6.Checked then begin

  IdTCPClient1.IOHandler.Write(buf, length(buf));

  e:=0;
     ff:='';
While e<1500 do
begin
if IdTCPClient1.IOHandler.InputBuffer.Size<11 then
if not IdTCPClient1.IOHandler.InputBufferIsEmpty then
   begin   inc(e); if e<1500 then continue;  end;
      e:=2000;
  if IdTCPClient1.IOHandler.CheckForDataOnSource(300) then
     IdTCPClient1.IOHandler.ReadBytes(buf,-1,false );
     for i:=0 to length(buf) -1 do
       begin
       ff:=ff+' - '+inttostr(buf[i]);

       end;
end;
memo2.Lines.Add('strings'+ff);
  tim_ok:=true;  timer1.Enabled:=true;
               end;
end;

procedure TForm1.TrackBar1Change(Sender: TObject);
begin

end;

procedure TForm1.TrackBar1EndDrag(Sender, Target: TObject; X, Y: Integer);
begin
  SendMessageToServer(EDIT1.TEXT,
                  SPINEDIT1.Value,
                  '' ,//EDIT4.TEXT,
                  0 , //SPINEDIT3.Value,
                  '<trbk>'+inttostr(TrackBar1.Position)+ '/trbk>');
end;

procedure TForm1.TrackBar1MouseUp(Sender: TObject; Button: TMouseButton;
  Shift: TShiftState; X, Y: Integer);
begin
     SendMessageToServer(EDIT1.TEXT,
                  SPINEDIT1.Value,
                  EDIT4.TEXT,
                  SPINEDIT3.Value,
                  '<trbk>'+inttostr(TrackBar1.Position)+ '/trbk>');
end;


procedure TForm1.IdTCPServer1Execute(AContext: TIdContext);
VAR z,S:STRING; p,y, n,e,i:integer;
buf: ARRAY OF ByTE;
f:array of byte;
x:integer=0;
begin  IF NOT IdTCPServer1.Active THEN EXIT;
       IF NOT  AContext.Connection.Connected THEN EXIT;
  //     AContext.Connection.IOHandler.Host:=label2.caption;
 //      AContext.Connection.IOHandler.Port:=strtoint(label3.caption);
 while x<5 do
   begin        if x>6 then break;      inc(x);
    if  AContext.Connection.IOHandler.InputBuffer.Size=0 then continue  else x:=6;
 // if  AContext.Connection.IOHandler.InputBufferIsEmpty then continue  else x:=6  ;
   if not CheckBox1.Checked then begin

   //  s:= AContext.Connection.IOHandler.ReadLn;z:=''; //(#10,100);

       AContext.Connection.IOHandler.ReadBytes(buf, -1, false) ;
      //  AContext.Connection.IOHandler.InputBuffer.Destroy;
   //   for e:=1 to  length(s) do
   //      begin   z:=z+'-'+inttostr(ord(s[e]));end;
     for e:=0 to  length(buf)-1 do
        begin   z:=z+'-'+inttostr(buf[e]);end;
     n:=0; e:=0;

   n:=found_buf(buf, stringgrid6 ); if n<0 then
   e:=found_buf(buf, stringgrid7 ); if e<0 then  if e<0 then
      save_buf(buf, stringgrid7 );


   if buf[7]=15 then begin    e:=length(Buf);             end else
   if buf[7]=16 then begin    e:=length(Buf);             end else
   if buf[7]=5 then begin    e:=length(Buf);               end else
   if buf[7]=6 then begin    e:=length(Buf);              end else
   begin     SetLength(Buf, 255);
   e:=move_out(buf, stringgrid6 ,n );  SetLength(Buf, e);
   end;


 AContext.Connection.IOHandler.Write(Buf,e);
  AContext.Connection.IOHandler.WriteBufferFlush;
   AContext.Connection.IOHandler.WriteBufferClose;
//  AContext.Connection.IOHandler.Destroy;

     memo2.Lines.Add(z);
     if memo2.Lines.Count>10 then
        begin  memo2.Lines.Clear;
               memo1.Lines.Clear;
               Button6Click(Self);
        end;
   s:='';
   end else
     begin   AContext.Connection.IOHandler.ReadBytes(buf, -1) ;

        setlength(f,11);
                 f[0]:=buf[0];  // транзакця
          f[1]:=buf[1]; // транзакця
          f[2]:=buf[2];  // id
          f[3]:=buf[3];  // id
          f[4]:=0;  //остаток
          f[5]:=5;  //остаток
          f[6]:=buf[6]; //адрес
         f[7]:=buf[7]; //функция
         f[8]:=2; //кол  байт
         f[9]:=1; //кол  байт
         f[10]:=2; //кол  байт
        AContext.Connection.IOHandler.WriteDirect(f); z:='';
       s:='';for i:=0 to  length(buf)-1 do
       s:=s+' - '+inttostr(buf[i]);
       for i:=0 to  length(buf)-1 do
       z:=z+chr(buf[i]);
       memo1.Lines.Add(s);       memo1.Lines.Add(z);
        s:=z;
    end ;

   end;


  if S <>'' then
  begin
 //  AContext.Connection.IOHandler.Write('Получено! ->'+S);
   MEMO2.LINES.Add(S);
   if pos('ON',s)>0  then begin form1.Caption:='ON'; exit; end;
   if pos('OFF',s)>0 then begin form1.Caption:='OFF';exit; end;
 //  if pos('line',s)>0  then begin label1.Caption:='line'; exit; end;
 //  if pos('clear',s)>0 then begin label1.Caption:='clear';exit; end;
   if pos('save',s)>0  then begin memo1.Lines.SaveToFile('eee'); exit; end;
   if pos('load',s)>0 then begin memo1.Lines.loadfromFile('eee'); exit; end;
   if pos('out',s)>0  then begin memo1.Lines.SaveToFile('kkk'); exit; end;
   if pos('inp',s)>0 then begin memo1.Lines.loadfromFile('kkk'); exit; end;
   if pos('clr_m1',s)>0 then begin memo1.Lines.clear; exit; end;
   if pos('clr_m2',s)>0 then begin memo2.Lines.clear; exit; end;

if pos('frm0',s)>0 then begin panel1.color:=clblue; exit;end;
if pos('frm1',s)>0 then begin panel1.color:=clgreen; exit; end;
if pos('frm2',s)>0 then begin panel1.color:=clred; exit; end;
if pos('frm3',s)>0 then begin panel1.color:=cldefault;exit; end;

   if pos('edt0',s)>0 then begin edit3.color:=clblue; exit;end;
   if pos('edt1',s)>0 then begin edit3.color:=clgreen; exit; end;
   if pos('edt2',s)>0 then begin edit3.color:=clred; exit; end;
   if pos('edt3',s)>0 then begin edit3.color:=cldefault;exit; end;
   i:=pos('<trbk>',s);
   if i>0 then begin i:=i+6;
                     z:=copy(s,i,length(s)-i-7);
                     progressbar1.Position :=strtoint(z);
               end;
  end;

 // SLEEP(400);
end;

procedure TForm1.MenuItem2Click(Sender: TObject);
begin
 PageControl1.TabIndex:=0;
    MenuItem2.Checked:=  NOT MenuItem2.Checked;
  IdTCPServer1.Active:=  NOT MenuItem2.Checked;
IF MenuItem2.Checked THEN
   MenuItem2.Caption:='В НАСТРОЙКИ' ELSE
   MenuItem2.Caption:='В РАБОТУ';
  Button21.Visible:=MenuItem2.Checked;
  Button22.Visible:=MenuItem2.Checked;
  Button5.Visible:=MenuItem2.Checked;
   SpinEdit1.Enabled:=MenuItem2.Checked;
       Edit1.ENABLED:=MenuItem2.Checked;
    SPINEDIT2.ENABLED:=MenuItem2.Checked;
        EDIT2.ENABLED:=MenuItem2.Checked;
   SPINEDIT3.ENABLED:=MenuItem2.Checked;
        EDIT4.ENABLED:=MenuItem2.Checked;

      Button1.ENABLED:=NOT MenuItem2.Checked;
//  IdTCPServer1.Active:=NOT MenuItem2.Checked;

IF  IdTCPServer1.Active THEN  BEGIN
  IdTCPServer1.Active:=FALSE;
  IdTCPServer1.DefaultPort:=SpinEdit2.Value;
  IdTCPServer1.Bindings.Clear;
//  IdTCPServer1.Bindings.Add.IP:=Edit2.Text;
 // IdTCPServer1.Bindings.Items[0].IP:=Edit2.Text;
 // IdTCPServer1.Bindings.Items[0].Port:=SpinEdit2.Value;
  SLEEP(600);
  IdTCPServer1.Active:=TRUE;
  END else begin
    IdTCPServer1.DefaultPort:=SpinEdit2.Value;
  //  IdTCPServer1.Bindings.Items[0].IP:=Edit2.Text;
 //   IdTCPServer1.Bindings.Items[0].Port:=SpinEdit2.Value;
    SLEEP(600);
  end;
 CheckBox5.Checked:=IdTCPServer1.Active;
end;

procedure TForm1.MenuItem3Click(Sender: TObject);
begin
     SendMessageToServer(EDIT1.TEXT, SPINEDIT1.Value,
     EDIT4.TEXT,
     SPINEDIT3.Value     ,'save');
end;

procedure TForm1.MenuItem4Click(Sender: TObject);
begin
    SendMessageToServer(EDIT1.TEXT, SPINEDIT1.Value,
                      EDIT4.TEXT,
                  SPINEDIT3.Value,
'load');
end;

procedure TForm1.MenuItem5Click(Sender: TObject);
begin
SendMessageToServer(EDIT1.TEXT, SPINEDIT1.Value,
EDIT4.TEXT,
SPINEDIT3.Value,
'line');
end;

procedure TForm1.MenuItem6Click(Sender: TObject);
begin
  SendMessageToServer(EDIT1.TEXT, SPINEDIT1.Value,
                    EDIT4.TEXT,
                  SPINEDIT3.Value,
'clear');
end;

procedure TForm1.MenuItem7Click(Sender: TObject);
begin
stringgrid2.SaveToFile('tcp_str');
end;


procedure TForm1.MenuItem8Click(Sender: TObject);
begin
stringgrid2.loadfromFile('tcp_str');

end;

procedure TForm1.Page1BeforeShow(ASender: TObject; ANewPage: TPage;
  ANewIndex: Integer);
begin

end;

procedure TForm1.RadioGroup1Click(Sender: TObject);
begin
     SendMessageToServer(EDIT1.TEXT, SPINEDIT1.Value,
                     '',// EDIT4.TEXT,
                 0, //SPINEDIT3.Value,
                  'frm'+
     inttostr(radiogroup1.ItemIndex));

end;
procedure TForm1.FormActivate(Sender: TObject);
begin
IdTCPServer1.Active:=FALSE;
IdTCPServer1.Bindings.Clear;
IdTCPServer1.Bindings.Add;
IdTCPServer1.Bindings.Items[0].IP:=Edit2.Text;
IdTCPServer1.Bindings.Items[0].Port:=SpinEdit2.Value;
IdTCPServer1.DefaultPort:=SpinEdit2.Value;
IdTCPServer1.Active:=TRUE;
CheckBox5.Checked:=IdTCPServer1.Active;
end;

procedure TForm1.FormClose(Sender: TObject; var CloseAction: TCloseAction);
begin       SLEEP(100);
           IdTCPServer1.Active:=FALSE;
           IdTCPServer1.Free;
                 hreadClient.Free;
end;

procedure TForm1.FormCreate(Sender: TObject);
begin
  MenuItem8Click(Sender );
  MenuItem10Click(Sender);
  MenuItem12Click(Sender);
  Button15Click(Sender);
  nm:=0;
 label16.caption:=IdTCPClient1.host;
 label17.caption:=inttostr(IdTCPClient1.port);

end;

procedure TForm1.IdTCPClient1AfterBind(Sender: TObject);
begin

end;

procedure TForm1.IdTCPClient1BeforeBind(Sender: TObject);
begin

end;

procedure TForm1.IdTCPClient1Connected(Sender: TObject);
begin

end;

procedure TForm1.IdTCPClient1SocketAllocated(Sender: TObject);
begin

end;

procedure TForm1.IdTCPClient1Work(ASender: TObject; AWorkMode: TWorkMode;
  AWorkCount: Int64);
begin

end;

procedure TForm1.IdTCPClient1WorkEnd(ASender: TObject; AWorkMode: TWorkMode);
begin

end;

procedure TForm1.IdTCPServer1AfterBind(Sender: TObject);
begin

end;

procedure TForm1.IdTCPServer1Status(ASender: TObject; const AStatus: TIdStatus;
  const AStatusText: string);
begin
         //Label7.Caption:=AStatusText;
end;

procedure TForm1.IdTraceRoute1Reply(ASender: TComponent;
  const AReplyStatus: TReplyStatus);
begin

end;

procedure TForm1.Memo2Change(Sender: TObject);
begin

end;

procedure TForm1.MenuItem10Click(Sender: TObject);
var j,i:integer;
begin
  stringgrid3.RowCount:=1001;
  stringgrid3.loadfromFile('tcp_mas');
  for i:=1 to 1000 do if length(stringgrid3.Cells[1,i])>0 then j:=i;
        stringgrid3.RowCount:=j+1;
end;

procedure TForm1.MenuItem11Click(Sender: TObject);
begin
  stringgrid4.SaveToFile('tcp_inp');
end;

procedure TForm1.MenuItem12Click(Sender: TObject);
var j,i:integer;
begin

    stringgrid4.RowCount:=1001;
    stringgrid4.LoadFromFile('tcp_inp');
      for i:=1 to 1000 do if length(stringgrid4.Cells[1,i])>0 then j:=i;
            stringgrid4.RowCount:=j+1;

end;

procedure TForm1.MenuItem13Click(Sender: TObject);
var j,i:integer;
begin
  if stringgrid4.RowCount>1 then
     stringgrid4.DeleteRow(stringgrid4.Row);
end;

procedure TForm1.MenuItem15Click(Sender: TObject);
begin
  form2.Show;
end;

procedure TForm1.MenuItem9Click(Sender: TObject);
begin
  stringgrid3.SaveToFile('tcp_mas');
end;

procedure TForm1.IdTCPServer1Connect(AContext: TIdContext);
  var row,count:integer;
begin     count:=stringgrid1.RowCount;  row:=-1;
   label2.caption:=AContext.Connection.Socket.Binding.PeerIP;
   label3.caption:=inttostr(AContext.Connection.Socket.Binding.PeerPort);

  //   IdTCPServer1Execute(AContext);
end;

procedure TForm1.IdTCPServer1Disconnect(AContext: TIdContext);
var row,count,i:integer;
begin            count:=stringgrid1.RowCount;  row:=-1;

for i:=1 to count-1 do
//   if stringgrid1.Cells[1,i]=label2.caption then
if stringgrid1.Cells[2,i]=label3.caption then row:=i;
                                          if row=-1 then
begin  stringgrid1.RowCount:=stringgrid1.RowCount+1;
i:=stringgrid1.RowCount-1;end else i:=row;
   stringgrid1.Cells[0,i]:=inttostr(0);
   stringgrid1.Cells[1,i]:=label2.caption ;
   stringgrid1.Cells[2,i]:=label3.caption;
   stringgrid1.Cells[3,i]:='true';
if   length(stringgrid1.Cells[5,i])=0 then
   stringgrid1.Cells[5,i]:=datetimetostr(date)+':'+timetostr(time);


count:=stringgrid1.RowCount;  row:=-1;

    for i:=1 to count-1 do
      if stringgrid1.Cells[2,i]=label3.caption then row:=i;
                                                 if row=-1 then  exit;
 i:=row;  stringgrid1.Cells[0,i]:=inttostr(0);
          stringgrid1.Cells[3,i]:='false';
          stringgrid1.Cells[4,i]:=datetimetostr(date)+':'+timetostr(time);
end;

procedure TForm1.Button1Click(Sender: TObject);
begin
  SendMessageToServer(EDIT1.TEXT, SPINEDIT1.Value,
                    EDIT4.TEXT,
                  SPINEDIT3.Value,
  EDIT3.TEXT);
end;

procedure TForm1.Button20Click(Sender: TObject);
begin
  Timer1Timer(Sender);
end;

procedure TForm1.Button21Click(Sender: TObject);
var sv:tstringlist;
begin
  sv:=tstringlist.Create;
  sv.Add(Edit2.text);
  sv.Add(edit1.text);
  sv.Add(edit3.text);
  sv.Add(edit4.text);
  sv.Add(inttostr(SpinEdit1.value));
  sv.Add(inttostr(spinedit2.value));
  sv.Add(inttostr(spinedit3.value));
  sv.SaveToFile('ip_tcp');
  sv.free;
end;

procedure TForm1.Button22Click(Sender: TObject);
var sv:tstringlist;   s:string;
begin
  sv:=tstringlist.Create;
  sv.LoadFromFile('ip_tcp');
  Edit2.text:=sv.Strings[0];
  edit1.text:=sv.Strings[1];
  edit3.text:=sv.Strings[2];
  edit4.text:=sv.Strings[3];
  SpinEdit1.Value:=strtoint(sv.Strings[4]);
  spinedit2.Value:=strtoint(sv.Strings[5]);
  spinedit3.Value:=strtoint(sv.Strings[6]);

  sv.free;
end;

procedure TForm1.Button23Click(Sender: TObject);
begin
if stringgrid4.Row<stringgrid4.RowCount then
if stringgrid4.Row>0 then
if stringgrid4.RowCount>1 then
       stringgrid4.DeleteRow(stringgrid4.Row);
end;

procedure TForm1.Button24Click(Sender: TObject);

var
//Pingsend: TPINGSend;
i: integer;
ip,KFZ: string;
begin
i:=0;
  while i < 11 do
   begin
i:=i+1;
ip:= '192.168.100.' + IntToStr(i);
KFZ:='KFZ' + IntToStr(i);
//Label1.caption:= (ip);
Label2.caption:= (kfz);
//pingSend := TPINGSend.Create;
     Try
//PingSend.Timeout :=750;
 //      if PingSend.Ping(ip) = True then KFZ1.Font.Color:=($00AA00) Else KFZ1.Font.Color:=($0000FF);
     finally
//PingSend.Free;
     end;
   end;
end;

procedure TForm1.Button25Click(Sender: TObject);
var err:boolean;
 client:TIdTcpClient;
begin
//label3.caption:=getLocalIP;
     memo1.Lines.Add('control  connect....');
    client:=TIdTcpClient.Create();
    client.Host:=edit1.text;
//    client.ReadTimeout:=100;
    client.port:=spinedit1.value;
    try
       try
      // client.ConnectTimeout:=1000;
   //    client.Connect;
       if    client.Connected then
           begin
           memo1.Lines.Add('ok connect!!!');
           IdTCPClient1.Disconnect;
           IdTCPClient1.Host:=edit1.Text;
           IdTCPClient1.Port:=spinedit1.value;
           IdTCPClient1.Connect;
           end else
           begin
           IdTCPClient1.Host:=edit1.Text;
           IdTCPClient1.Port:=spinedit1.value;
           end;
       except
           memo1.Lines.Add('err connect!!!');
    //       Edit1.text:=getLocalIP;
       end  ;
    finally
        client.Disconnect;
      CheckBox3.Checked:=false;
        client.Free;
    end;
     label16.Caption:=IdTCPClient1.Host;
     label17.Caption:=inttostr(IdTCPClient1.Port);

end;

procedure TForm1.Button26Click(Sender: TObject);
var j,q:word;        s4, s2:string; buf: array of byte;  e:^byte;
begin q:=spinedit1.value;   j:=spinedit3.value;    s2:=edit1.Text;     s4:=edit4.Text;

SetLength(Buf, 6+6);    e:=@nm;

Buf[0 ]:=e^; e:=e+1; Buf[1 ]:=e^;   Buf[2 ]:=$0; Buf[2 ]:=$0; Buf[3 ]:=$51; Buf[4 ]:=$0;
                    Buf[5 ]:=$5; Buf[6 ]:=$49; Buf[7 ]:=$50; Buf[8 ]:=$51; Buf[9 ]:=$52;
                    Buf[10]:=$01; Buf[11]:=$49; //Buf[12]:=$50; Buf[13]:=$51; Buf[14]:=$52;

          //                f[0]:=buf[0];  // транзакця
//                           f[1]:=buf[1]; // транзакця
//                           f[2]:=buf[2];  // id
//                           f[3]:=buf[3];  // id
//                           f[4]:=0;  //остаток
//                           f[5]:=5;  //остаток
//                           f[6]:=buf[6]; //адрес
//                          f[7]:=buf[7]; //функция
//                          f[8]:=2; //кол  байт
//                          f[9]:=1; //кол  байт
//                          f[10]:=2; //кол  байт


  if checkbox2.Checked then
   TThreadClient.Create('uu888999',buf,@OnClientResponse, @OnClientError,s2,s4,j,q)
   else
   TThreadClient.Create('888999', buf ,@OnClientResponse, @OnClientError,'',s2,0,q);
end;

procedure TForm1.Button27Click(Sender: TObject);
   var    i,q:integer; z,s:string;
          id,j,w:word;  s4, s2:string; rrw:word;
buf: array of byte;
begin
w:=spinedit1.value;   j:=spinedit3.value;    s2:=edit1.Text;     s4:=edit4.Text;
           hreadClient:=NIL;
         q:=stringgrid3.Rowcount-1;   if q<1 then exit;
//            if rw<1 then rw:=0;
//            if rw<q then rw:=rw+1 else   rw:=1;

             if q<1 then exit;
             rrw:=stringgrid3.Row;
             if rrw<1 then rrw:=1;
             if rrw>q then rrw:=1;

             z:='';
                         spinedit5.value:=spinedit5.value+1;
                     id:=spinedit5.value;
                     s:=  chr(hi(id));
                     s:=s+chr(lo(id));
                     s:=s+chr(0);
                     s:=s+chr(0);
           setlength(buf,stringgrid3.ColCount-1-2+6);
            buf[0]:=hi(id);
            buf[1]:=lo(id);
            buf[2]:=0;
            buf[3]:=0;
         for i:=1 to stringgrid3.ColCount-1-2 do
           begin
           if stringgrid3.Cells[i,rrw]='' then
                 z:=z+chr(0) else
                 z:=z+chr(strtoint(stringgrid3.Cells[i,rrw]));
           if stringgrid3.Cells[i,rrw]='' then
                buf[i-1+6]:=0 else
                buf[i-1+6]:=strtoint(stringgrid3.Cells[i,rrw]);
           end;

                    id:=length(z);
         buf[4]:=hi(id);
         buf[5]:=lo(id);

         s:=s+chr(hi(id));
         s:=s+chr(lo(id));
         z:=s+z;


   if checkbox2.Checked then
   TThreadClient.Create(z,buf,@OnClientResponse, @OnClientError,s4,s2,j,w) else
   TThreadClient.Create(z,buf,@OnClientResponse, @OnClientError,'',s2,0,w);

end;

procedure TForm1.Button28Click(Sender: TObject);
   var    e,i,q:integer; ff, z,s:string;
            id,j,w:word;  s4, s2:string; rrw:word;
  buf: array of byte;
  begin     if   IdTCPClient1.Connected then else
  begin ShowMessage('no connected'); exit; end;

  w:=spinedit1.value;   j:=spinedit3.value;    s2:=edit1.Text;     s4:=edit4.Text;
             hreadClient:=NIL;
           q:=stringgrid3.Rowcount-1;   if q<1 then exit;
  //            if rw<1 then rw:=0;
  //            if rw<q then rw:=rw+1 else   rw:=1;

               if q<1 then exit;
               rrw:=stringgrid3.Row;
               if rrw<1 then rrw:=1;
               if rrw>q then rrw:=1;

               z:='';
                           spinedit5.value:=spinedit5.value+1;
                       id:=spinedit5.value;
                       s:=  chr(hi(id));
                       s:=s+chr(lo(id));
                       s:=s+chr(0);
                       s:=s+chr(0);
             setlength(buf,stringgrid3.ColCount-1-2+6);
              buf[0]:=hi(id);
              buf[1]:=lo(id);
              buf[2]:=0;
              buf[3]:=0;
           for i:=1 to stringgrid3.ColCount-1-2 do
             begin
             if stringgrid3.Cells[i,rrw]='' then
                   z:=z+chr(0) else
                   z:=z+chr(strtoint(stringgrid3.Cells[i,rrw]));
             if stringgrid3.Cells[i,rrw]='' then
                  buf[i-1+6]:=0 else
                  buf[i-1+6]:=strtoint(stringgrid3.Cells[i,rrw]);
             end;

                      id:=length(z);
           buf[4]:=hi(id);
           buf[5]:=lo(id);

           s:=s+chr(hi(id));
           s:=s+chr(lo(id));
           z:=s+z;
             IdTCPClient1.IOHandler.Write(buf, length(buf));
        e:=0;
        ff:='';
While e<1500 do
   begin
   if IdTCPClient1.IOHandler.InputBuffer.Size<11 then
   if not IdTCPClient1.IOHandler.InputBufferIsEmpty then
      begin   inc(e); if e<1500 then continue;  end;
         e:=2000;
     if IdTCPClient1.IOHandler.CheckForDataOnSource(300) then
        IdTCPClient1.IOHandler.ReadBytes(buf,-1,false );
        for i:=0 to length(buf) -1 do
          begin
          ff:=ff+' - '+inttostr(buf[i]);
          end;
   end;
   memo2.Lines.Add('strings'+ff);

end;

procedure TForm1.Button29Click(Sender: TObject);
begin

     Button27Click(Sender);
end;

procedure TForm1.Button10Click(Sender: TObject);
var i,j:integer;
begin  i:=stringgrid3.row;
       Button9Click(Sender); // пересчитаем контрольнуюсумму--
for j:=1 to 8 do
   stringgrid3.Cells[j,i]:=stringgrid2.Cells[1,j];
end;

procedure TForm1.BitBtn1Click(Sender: TObject);
var g,w,j,i:integer; s5,s6:string;
begin
   stringgrid4.RowCount:=1001;
   stringgrid4.LoadFromFile('tcp_inp');
   for i:=1 to 1000 do
      if length(stringgrid4.Cells[1,i])>0 then j:=i;
   stringgrid4.RowCount:=j+1;

   for i:=1 to stringgrid4.RowCount-1 do begin
    s5:=stringgrid4.Cells[5,i];
    s6:=stringgrid4.Cells[6,i];  // memo1.Lines.Add(inttostr(arow));
    if length(s5)=0 then ;   if length(s6)=0 then exit;
     w:=strtoint(s5)*255+strtoint(s6);
    if '01'=stringgrid4.Cells[2,i] then g:=round(w/8+0.5);
    if '02'=stringgrid4.Cells[2,i] then g:=round(w/8+0.5);
    if '03'=stringgrid4.Cells[2,i] then g:=round(w*2);
    if '04'=stringgrid4.Cells[2,i] then g:=round(w*2);
    if '05'=stringgrid4.Cells[2,i] then g:=4;
    if '06'=stringgrid4.Cells[2,i] then g:=4;
            stringgrid4.Cells[9,i]:=inttostr(g);
   end;
   StringGrid4Click(Sender);
end;

procedure TForm1.Button11Click(Sender: TObject);
var i,j:integer;
begin  i:=stringgrid3.row;
for j:=1 to 8 do
   stringgrid2.Cells[1,j]:=stringgrid3.Cells[j,i];
end;

procedure TForm1.Button12Click(Sender: TObject);
begin
  if stringgrid3.RowCount>1 then
  stringgrid3.DeleteRow(stringgrid3.Row);
end;

procedure TForm1.Button13Click(Sender: TObject);
begin
StringGrid3.Rowcount:=StringGrid3.Rowcount+1;
end;

procedure TForm1.Button14Click(Sender: TObject);
VAR s2,s4,z,S:STRING; p,y, n,e,i:integer; w,j,id:word;
buf: ARRAY OF ByTE;
f:array of byte;
x:integer=0;
begin
w:=spinedit1.value;   j:=spinedit3.value;    s2:=edit1.Text;     s4:=edit4.Text;
           hreadClient:=NIL;

       n:=stringgrid4.row;
    if n>=stringgrid4.RowCount then
       n:=stringgrid4.RowCount-1;
    if n<1 then exit;
     SetLength(Buf, 255);
     spinedit5.value:=spinedit5.value+1;
     id:=spinedit5.value;
//      setlength(buf,stringgrid4.ColCount-1-2+6);
      buf[0]:=hi(id);
      buf[1]:=lo(id);
      buf[2]:=0;
      buf[3]:=0;

    e:=out_move(buf, stringgrid4 ,n ,12);
    SetLength(Buf, e);


for i:=1 to 6 do  begin
         s:=stringgrid4.Cells[i,n];  if s='' then s:='0';
         buf[5+i]:=strtoint(s);
         end  ;

         for i:=0 to length(buf)-1 do   begin
           s:=s+chr(buf[i]);;
           z:=z+'/'+inttostr(buf[i]);
         end;

 //  memo1.Lines.Add(z);

   if checkbox2.Checked then
   TThreadClient.Create(s,buf,@OnClientResponse, @OnClientError,s4,s2,j,w) else
   TThreadClient.Create(s,buf,@OnClientResponse, @OnClientError,'',s2,0,w);

end;

procedure TForm1.Button15Click(Sender: TObject);
var i,j:integer;
begin
  stringgrid6.RowCount:=  stringgrid4.RowCount;
  stringgrid6.colCount:=  stringgrid4.colCount;
  for i:=0 to stringgrid6.RowCount-1 do
  for j:=0 to stringgrid6.colCount-1 do
    stringgrid6.Cells[j,i]:=stringgrid4.Cells[j,i];
end;

procedure TForm1.Button16Click(Sender: TObject);
var j,i:integer;
begin
               stringgrid4.RowCount:=stringgrid3.RowCount;
               stringgrid4.colCount:=stringgrid3.colCount+2;
   for i:=1 to stringgrid3.RowCount-1 do
   if length(stringgrid3.Cells[1,i])=0 then  stringgrid4.Cells[j,i]:='0' else
   for j:=1 to stringgrid3.colCount-1 do
               stringgrid4.Cells[j,i]:=stringgrid3.Cells[j,i];
end;

procedure TForm1.Button17Click(Sender: TObject);
var i:integer;
begin
    if stringgrid7.Row<1 then exit;
stringgrid3.rowcount:=stringgrid3.rowcount+1;

for i:=1  to 8  do
  stringgrid3.Cells[i,stringgrid3.RowCount-1]:=
  stringgrid7.Cells[i,stringgrid7.Row       ];
end;

procedure TForm1.Button18Click(Sender: TObject);
var i:integer;
begin
if stringgrid7.Row<1 then exit;
stringgrid4.rowcount:=stringgrid4.rowcount+1;

for i:=1  to 8 do
  stringgrid4.Cells[i,stringgrid4.RowCount-1]:=
  stringgrid7.Cells[i,stringgrid7.Row       ];

end;

procedure TForm1.Button19Click(Sender: TObject);
begin
stringgrid7.DeleteRow(stringgrid7.Row);
end;

procedure TForm1.Button2Click(Sender: TObject);
begin
    SendMessageToServer(EDIT1.TEXT, SPINEDIT1.Value,
                      EDIT4.TEXT,
                  SPINEDIT3.Value,'ON');
end;

procedure TForm1.Button30Click(Sender: TObject);
begin
     Button28Click(Sender);
end;

procedure TForm1.Button31Click(Sender: TObject);
VAR ff,  z,S:STRING; p,y, n,e,i:integer; w,j,id:word;
buf: ARRAY OF ByTE;

x:integer=0;
begin
n:=stringgrid4.row;
if n>=stringgrid4.RowCount then
 n:=stringgrid4.RowCount-1;
if n<1 then exit;
SetLength(Buf, 255);
spinedit5.value:=spinedit5.value+1;
id:=spinedit5.value;
//      setlength(buf,stringgrid4.ColCount-1-2+6);
buf[0]:=hi(id);
buf[1]:=lo(id);
buf[2]:=0;
buf[3]:=0;

e:=out_move(buf, stringgrid4 ,n ,12);
SetLength(Buf, e);


for i:=1 to 6 do  begin
   s:=stringgrid4.Cells[i,n];  if s='' then s:='0';
   buf[5+i]:=strtoint(s);
   end  ;

   for i:=0 to length(buf)-1 do   begin
     s:=s+chr(buf[i]);;
     z:=z+'/'+inttostr(buf[i]);
   end;

            memo1.Lines.Add(z);
             IdTCPClient1.IOHandler.Write(buf, length(buf));
        e:=0;
        ff:='';
While e<1500 do
   begin
   if IdTCPClient1.IOHandler.InputBuffer.Size<11 then
   if not IdTCPClient1.IOHandler.InputBufferIsEmpty then
      begin   inc(e); if e<1500 then continue;  end;
         e:=2000;
     if IdTCPClient1.IOHandler.CheckForDataOnSource(300) then
        IdTCPClient1.IOHandler.ReadBytes(buf,-1,false );
        for i:=0 to length(buf) -1 do
          begin
          ff:=ff+' - '+inttostr(buf[i]);
          end;
   end;
   memo2.Lines.Add('strings'+ff);

end;

procedure TForm1.Button32Click(Sender: TObject);
begin
  stringgrid6.DeleteRow(stringgrid6.Row);
end;

procedure TForm1.Button3Click(Sender: TObject);
begin
    SendMessageToServer(EDIT1.TEXT, SPINEDIT1.Value,
                      EDIT4.TEXT,
                  SPINEDIT3.Value,'OFF');
end;

procedure TForm1.Button4Click(Sender: TObject);
begin
   SendMessageToServer(EDIT1.TEXT, SPINEDIT1.Value,
                     EDIT4.TEXT,
                  SPINEDIT3.Value,
'clr_m1');
end;

procedure TForm1.Button5Click(Sender: TObject);
var err:boolean;
begin     err:=IdTCPServer1.Active;
   Edit2.text:=getLocalIP;
   IdTCPServer1.Active:=FALSE;
   IdTCPServer1.DefaultPort:=SpinEdit2.Value;
// IdTCPServer1.Bindings.Items[0].IP:=Edit2.Text;
// IdTCPServer1.Bindings.Items[0].Port:=SpinEdit2.Value;
   SLEEP(600);
   IdTCPServer1.Active:=err;
end;

procedure TForm1.Button6Click(Sender: TObject);
begin  stringgrid1.RowCount:=1;
memo1.Clear;
memo2.clear;
end;

procedure TForm1.Button7Click(Sender: TObject);
var q:word;     s2:string;     buf: array of byte;
begin q:=spinedit1.value;     s2:=edit1.Text;

SetLength(Buf, 15); Buf[0 ]:=$01; Buf[1 ]:=$49; Buf[2 ]:=$50; Buf[3 ]:=$51; Buf[4 ]:=$52;
                    Buf[5 ]:=$01; Buf[6 ]:=$49; Buf[7 ]:=$50; Buf[8 ]:=$51; Buf[9 ]:=$52;
                    Buf[10]:=$01; Buf[11]:=$49; Buf[12]:=$50; Buf[13]:=$51; Buf[14]:=$52;
   TThreadClient.Create('1234',buf,@OnClientResponse, @OnClientError,'',s2,0,q);
end;

procedure TForm1.Button8Click(Sender: TObject);
var j,q:word;        s4, s2:string; buf: array of byte;
begin q:=spinedit1.value;   j:=spinedit3.value;    s2:=edit1.Text;     s4:=edit4.Text;

SetLength(Buf, 15); Buf[0 ]:=$01; Buf[1 ]:=$49; Buf[2 ]:=$50; Buf[3 ]:=$51; Buf[4 ]:=$52;
                    Buf[5 ]:=$01; Buf[6 ]:=$49; Buf[7 ]:=$50; Buf[8 ]:=$51; Buf[9 ]:=$52;
                    Buf[10]:=$01; Buf[11]:=$49; Buf[12]:=$50; Buf[13]:=$51; Buf[14]:=$52;
  if checkbox2.Checked then
   TThreadClient.Create('uu888999',buf,@OnClientResponse, @OnClientError,s4,s2,j,q)
   else
   TThreadClient.Create('888999', buf ,@OnClientResponse, @OnClientError,'',s2,0,q);

end;

procedure TForm1.Button9Click(Sender: TObject);
var z,s:string; r:integer; i:word;
begin
    s:='';
for i:=1 to stringgrid2.RowCount-3 do
    begin                    z:=stringgrid2.Cells[1,i];
    if length(z)=0 then z:='0'; stringgrid2.Cells[1,i]:=z;
                  r:=strtoint(z);
    if r>255 then r:=255; s:=s+chr(r);
    end;  z:=crc16string(s);
StringGrid2.Cells[2,StringGrid2.rowcount-2]:=inttohex(ORD(Z[1]));
StringGrid2.Cells[2,StringGrid2.rowcount-1]:=inttohex(ORD(Z[2]));
stringgrid2.Cells[1,stringgrid2.rowcount-2]:=inttostr(ORD(Z[1]));
stringgrid2.Cells[1,stringgrid2.rowcount-1]:=inttostr(ORD(Z[2]));
memo2.Lines.Add('-'+inttostr(ORD(Z[1]) )+'-'+inttostr(ORD(Z[2])));
end;



procedure TForm1.CheckBox1Change(Sender: TObject);
begin
 if not  CheckBox1.Checked then CheckBox1.Caption:='байты' else
                           CheckBox1.Caption:='строки';
  end;

procedure TForm1.CheckBox2Change(Sender: TObject);
begin

end;

procedure TForm1.CheckBox3Change(Sender: TObject);
begin
if CheckBox3.Checked then  begin
   try
  IdTCPClient1.Connect;

  except
  IdTCPClient1.Disconnect;
  showmessage('connect error');
  CheckBox3.Checked:=false;
   end ;  end else
   IdTCPClient1.Disconnect;

end;

procedure TForm1.CheckBox4Change(Sender: TObject);
begin
  timer1.Enabled:=CheckBox4.Checked;
if  CheckBox4.Checked then CheckBox6.Checked:=false;
if  CheckBox6.Checked then CheckBox6.Caption:='on'
                      else CheckBox6.Caption:='off';


  tim_ok:=false;
end;

procedure TForm1.CheckBox5Change(Sender: TObject);
begin
  IdTCPServer1.Active:=CheckBox5.Checked;
end;

procedure TForm1.CheckBox6Change(Sender: TObject);
begin   timer1.Enabled:=CheckBox6.Checked;
  if  CheckBox6.Checked then CheckBox6.Caption:='on'
                        else CheckBox6.Caption:='off';
  if  CheckBox6.Checked then CheckBox4.Checked:=false;
end;

procedure TForm1.ComboBox5Change(Sender: TObject);
begin
  Notebook1.PageIndex:=ComboBox5.ItemIndex;
end;

procedure TForm1.Edit1Change(Sender: TObject);
begin

end;

procedure TForm1.Edit2Change(Sender: TObject);
begin

end;

procedure TForm1.Edit2EditingDone(Sender: TObject);
begin
  //ShowMessage('Текст gggg 555сообщения');
 // Button25Click(Sender);
end;

procedure TForm1.Edit2EndDrag(Sender, Target: TObject; X, Y: Integer);
begin
 // ShowMessage('Текст 11111hhhhhhсообщения');
end;

procedure TForm1.Edit2Enter(Sender: TObject);
begin

end;

procedure TForm1.Edit2Exit(Sender: TObject);
begin
  //ShowMessage('33333333 ggggния');
 // Button25Click(Sender);
end;

procedure TForm1.Edit5Change(Sender: TObject);
var s:string; i:integer;
begin  s:=Edit5.Text;
for i:=1 to length(s) do
  if i<stringgrid5.rowcount then
       stringgrid5.Cells[1,i]:=inttostr(ord(s[i])); str_org;
end;

procedure TForm1.FloatSpinEdit1Change(Sender: TObject);
var e1,e2,e3,e4:byte; d:^byte;   v:single;
begin  v:=FloatSpinEdit1.Value;        d:=@v;
e1:=d^; d:=d+1; e2:=d^; d:=d+1;  e3:=d^; d:=d+1; e4:=d^;

     stringgrid5.Cells[1,1]:=inttostr(e4);
     stringgrid5.Cells[1,2]:=inttostr(e3);
     stringgrid5.Cells[1,3]:=inttostr(e2);
     stringgrid5.Cells[1,4]:=inttostr(e1);

      if CheckBox7.Checked then
             begin
          stringgrid5.Cells[1,1]:=inttostr(e2);
          stringgrid5.Cells[1,2]:=inttostr(e1);
          stringgrid5.Cells[1,3]:=inttostr(e4);
          stringgrid5.Cells[1,4]:=inttostr(e3);  end
      else   begin
          stringgrid5.Cells[1,1]:=inttostr(e4);
          stringgrid5.Cells[1,2]:=inttostr(e3);
          stringgrid5.Cells[1,3]:=inttostr(e2);
          stringgrid5.Cells[1,4]:=inttostr(e1);  end;
      str_org;

     str_org;
end;

procedure TForm1.FloatSpinEdit2Change(Sender: TObject);
var e1,e2,e3,e4,e5,e6,e7,e8:byte; d:^byte;   v:real;
begin  v:=FloatSpinEdit2.Value;        d:=@v;
e1:=d^; d:=d+1; e2:=d^; d:=d+1;  e3:=d^; d:=d+1; e4:=d^;  d:=d+1;
e5:=d^; d:=d+1; e6:=d^; d:=d+1;  e7:=d^; d:=d+1; e8:=d^;
if stringgrid5.RowCount<7 then exit;
     stringgrid5.Cells[1,1]:=inttostr(e8);
     stringgrid5.Cells[1,2]:=inttostr(e7);
     stringgrid5.Cells[1,3]:=inttostr(e6);
     stringgrid5.Cells[1,4]:=inttostr(e5);
     stringgrid5.Cells[1,5]:=inttostr(e4);
     stringgrid5.Cells[1,6]:=inttostr(e3);
     stringgrid5.Cells[1,7]:=inttostr(e2);
     stringgrid5.Cells[1,8]:=inttostr(e1); str_org;
end;

  
//=========================
// Client - client response
procedure TForm1.OnClientResponse(ThreadClient: TThreadClient);
var s:string;
begin s:=ThreadClient.Response;
Memo1.lines.Add('OnClientResponse='+s);     tim_ok:=false;


//hreadClient:=NIL;
//if checkbox4.Checked then
//  Timer1Timer(self);
end;
//=========================
// Client - client error
procedure TForm1.OnClientError(ThreadClient: TThreadClient; E: Exception);
var s:string;
begin   s:=ThreadClient.Response;                      tim_ok:=false;
Memo1.lines.Add(s+'URL: Error:'+ E.Message);
end;

function TForm1.out_move(var buf:array of byte; tt:tstringgrid; n,m:integer ):integer;
var a,q,r,i:integer; u,s,z:string;
begin out_move:=8; if n<1  then exit;
      Z:=tt.Cells[10,n];     //формируем пакет
         q:=length(buf);

            a:=0;
            i:=0; Z:=tt.Cells[10,n];     //формируем пакет
            if  tt.Cells[9,n]<>'' then a:=strtoint(tt.Cells[9,n]);
            while length(z)>0 do  begin r:=pos('/',z); //формируем пакет
               if r<=0 then begin z:=''; continue; end;//формируем пакет
               U:=copy(z,0,r-1); delete(z,1,r);  S:=S+chr(strtoint(U));
               inc(i); IF I>254 THEN Z:='';       //формируем пакет
                       IF I>q-1 THEN Z:='';       //формируем пакет
               buf[i+m]:=strtoint(U);
            end;                               //Z:=''; z:=crc16string(s); s:=s+z; //формируем пакет
            buf[4]:=hi(i+m-5);
            buf[5]:=lo(i+m-5);
            buf[m]:=a;
out_move:=i+m+1;
end;

function TForm1.move_out(var buf:array of byte; tt:tstringgrid; n:integer ):integer;
var a,q,r,i:integer; u,s,z:string;
begin move_out:=8; if n<1  then exit;
      Z:=tt.Cells[10,n];     //формируем пакет
         q:=length(buf);

            a:=0;
            i:=0; Z:=tt.Cells[10,n];     //формируем пакет
            if  tt.Cells[9,n]<>'' then a:=strtoint(tt.Cells[9,n]);
            while length(z)>0 do  begin r:=pos('/',z); //формируем пакет
               if r<=0 then begin z:=''; continue; end;//формируем пакет
               U:=copy(z,0,r-1); delete(z,1,r);  S:=S+chr(strtoint(U));
               inc(i); IF I>254 THEN Z:='';       //формируем пакет
                       IF I>q-1 THEN Z:='';       //формируем пакет
               buf[i+8]:=strtoint(U);
            end;                               //Z:=''; z:=crc16string(s); s:=s+z; //формируем пакет
            buf[4]:=hi(i+3);
            buf[5]:=lo(i+3);
            buf[8]:=a;
move_out:=i+9;
end;

end.

  procedure TForm1.Button1Click(Sender: TObject);
var
  Response: string;
begin
  // Инициализация компонента
  IdTCPClient1.Host := '127.0.0.1'; // Адрес сервера
  IdTCPClient1.Port := 12345; // Порт сервера

  // Подключение к серверу
  IdTCPClient1.Connect;

  // Отправка команды
  IdTCPClient1.IOHandler.WriteLn('Hello, server!');

  // Получение ответа
  Response := IdTCPClient1.IOHandler.ReadLn;
  ShowMessage('Сервер ответил: ' + Response);

  // Отключение
  IdTCPClient1.Disconnect;
end;
