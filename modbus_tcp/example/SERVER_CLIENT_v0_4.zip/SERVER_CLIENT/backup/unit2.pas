unit Unit2;


{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, IdTCPClient,   RegexPr;

type
  //======================================
  // Client
  TThreadClient = class(TThread)
    type
      TClientread = procedure (ThreadClient: TThreadClient) of object;Register;  //TClientResponseFunction
      TClientErrorFunction = procedure (ThreadClient: TThreadClient; E: Exception) of object;Register;
    var   client:TIdTcpClient;
      isResponse:Boolean;
      isError:Boolean;
      Response: String;
      buf_inp: String;
      buf_inf: array of byte;
        Error: Exception;
      PClientResponseFunction: TClientread;
      PClientErrorFunction: TClientErrorFunction;
      PThreadMethod: TThreadMethod;
  protected
    procedure Execute; override;
    procedure OnClientResponse;
    procedure OnClientError;
  public
    constructor Create(link: String;
                    inf_inp:array of byte;
                    PClient: TClientread;
                     PError: TClientErrorFunction;
               host_ip,host: string;
               port_ip,port: word
                                     );
    function get(var url:String):String;
  end;


implementation
// =========== Client ===========
constructor TThreadClient.Create(link: String;
                       inf_inp:array of byte;
                PClient: TClientread;
                                      PError: TClientErrorFunction;
                                host_ip,host: string;
                                port_ip,port: word
                                     );
var i:integer;
begin
//  client.IOHandler.WaitFor();
  //sleep(100)   ;
//  FreeOnTerminate := True;
 PClientResponseFunction := PClient;
PClientErrorFunction := PError;
isResponse := False;
   isError := False;
   buf_inp:=link;
   client:=TIdTcpClient.Create();
    client.Host:=host;
    client.ReadTimeout:=1000;
    client.port:=port;
 if port_ip>0   then
    client.BoundPort:=port_ip;
    if host_ip<>'' then
       client.BoundIP:=host_ip;
  setlength(buf_inf,length(inf_inp));
         for i:=0 to length(inf_inp)-1 do
                buf_inf[i]:=inf_inp[i];

 inherited Create(False);
    FreeOnTerminate := True;



  start;
end;

procedure TThreadClient.Execute;
begin
 try
 client.Connect;
  client.IOHandler.Write(buf_inf, length(buf_inf));
 //client.IOHandler.Write(buf_inp, length(buf_inp));
 client.IOHandler.WriteBufferFlush;
 client.IOHandler.WriteBufferClose;
 try
  Response :=  get(Response) ;
  finally
    //    Client.Free;
   Synchronize(@OnClientResponse);
   //    suspend;
     doTerminate;
    inherited Destroy;
//   free;
   end;
  except on E: Exception do
  begin isError := True;
        Response:='ошибка !!!!';
    //    Client.Free;
          Error := E;
     Synchronize(@OnClientError);
           // suspend;
         doTerminate;
    inherited Destroy;
  //     free;

 end;
 end;
 //     inherited Destroy;
end;



procedure TThreadClient.OnClientResponse;
begin
  if Assigned(PClientResponseFunction) then
     PClientResponseFunction(Self);
end;
procedure TThreadClient.OnClientError;
begin
  if Assigned(PClientErrorFunction) then
     PClientErrorFunction(Self, Error);
end;

function TThreadClient.get(var url:String):String;
var mystr:string;e, i:integer;
  buf:array of byte;
begin  result := 'по нулям!';  mystr:='';   e:=0;

   While Client.Connected and not Terminated do
   begin
 // if Client.IOHandler.InputBuffer.Size=0 then
   if not Client.IOHandler.InputBufferIsEmpty then
      begin   inc(e); if e<1500 then continue  else
              begin client.Disconnect; continue; end; end  else
      begin
     //      myStr :=myStr+ client.IOHandler.ReadLn(#10,100); // i:=500;
     if Client.IOHandler.CheckForDataOnSource(300) then
       client.IOHandler.ReadBytes(buf,-1,false );
          //client.IOHandler.InputBuffer.Clear;
      for i:=0 to length(buf) -1 do
          begin
          mystr:=mystr+' - '+inttostr(buf[i]);
          end;
          Client.IOHandler.InputBuffer.Destroy;
      //    Client.IOHandler.InputBuffer.Free;
          Client.Disconnect;//  Terminate;
       end ; // url:=    mystr+'--'+inttostr(i);// Response :=url;
if length(mystr)>0 then
       result:=mystr  +'-/-'+inttostr(e);
 end;

end;
////




end.
          if ord(s[2])=15 then begin
        e:=copy(s,1,6); z:=crc16string(e); e:=e+z;
               LazSerial2.WriteData(e);  //посылвем готовый ответ
                        exit;
                 end else
  if ord(s[2])=16 then begin
        e:=copy(s,1,6); z:=crc16string(e); e:=e+z;
               LazSerial2.WriteData(e);  //посылвем готовый ответ
                        exit;
                 end else
  if ord(s[2])=5 then begin
       LazSerial2.WriteData(s);  //посылвем готовый ответ
                          exit; end else
  if ord(s[2])=6 then begin
       LazSerial2.WriteData(s);  //посылвем готовый ответ
                          exit; end;
